# ******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : Verlaengerung_N_Haltephase_Timer4.py
# Title   : Verlaengerung N Haltephase Timer4
# Task    : Test Verlaengerung der N-Haltephase Timer4
#
# Author  : Mohammed Abdul Karim
# Date    : 03.11.2021
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 03.11.2021 | Mohammed | initial
# 1.1  | 03.11.2021 | Mohammed | initial
# 1.2  | 15.12.2021 | Devangbhai | Chanded the velocity timer from 0.04ms to infinite, adjusted the timing
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from ttk_checks import basic_tests
import functions_gearselection
import functions_common
import functions_nm
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)
    func_nm = functions_nm.FunctionsNM(testenv)

    # Initialize variables ####################################################
    test_variable = hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value
    test_variable.alias = "Waehlhebel_04:WH_Zustand_N_Haltephase_2"

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_117")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    testresult.append(["[.]Initialisierungsphase abgeschlossen und Waehlhebelposition D aktiviert", ""])
    descr, verdict = func_gs.changeDrivePosition('D')
    testresult.append(["\xa0" + descr, verdict])

    # TEST PROCESS ############################################################
    testresult.append([" Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["\x0a1. Lese Signal Waehlhebel_04:WH_Zustand_N_Haltephase_2", ""])
    testresult.append([" Pr�fe WH_Zustand_N_Haltephase_2 = 0", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=0,
            descr="Pr�fe, dass Wert 0 (inaktiv) ist",
        )
    )
    testresult.append(["\xa02: 2.1 Setze SiShift_FlgStrtNeutHldPha = 1,2.2 VDSO_Vx3d = 32766 (0 km/h),2.3 SIShift_StLghtDrvPosn = 6, und Kl15 aus ","INFO"])
    hil.SiShift_01__SIShift_FlgStrtNeutHldPha__value.set(1)

    descr, verdict = func_gs.setVelocity_kmph(0)
    testresult.append(["\xa0" + descr, verdict])

    descr, verdict = func_gs.changeDrivePosition('N')
    testresult.append(["\xa0" + descr, verdict])

    testresult.append(["Kl.15 = 0 senden, warte 150ms", "INFO"])
    hil.cl15_on__.set(0)
    time.sleep(0.15)

    testresult.append(["\x0a2.5 Schalte Senden von RX Signalen (HiL --> ECU) aus", "INFO"])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0aPr�fe WH_Zustand_N_Haltephase_2 = 1 ", "INFO"])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 (aktiv_Timer_laeuft) ist",
        )
    )

    testresult.append(["\x0a5. Warte 1 Minute und Pr�fe Kommunikation", ""])
    time.sleep(60)

    testresult.append(["\x0aPr�fe, Kein Senden und Empfangen von Botschaften (WH im lokalen Nachlauf", ""])
    time_1 = time.time()
    descr, verdict = func_gs.checkBusruhe(daq, 1)
    testresult.append([descr, verdict])

    time_2 = time.time()
    time_difference = time_2 - time_1

    testresult.append(["Pr�fe Strommonitoring (2 mA<I<100mA)", ""])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.002,  # 2mA
            max_value=0.100,  # 100mA
            descr="Pr�fe, dass Strom zwischen 2mA und 100mA liegt"
        )
    )

    testresult.append(["\x0a6. Warte bis 1 Minute bevor Timer 1 (25 min) abl�uft und Pr�fe erneut Kommunikation", ""])
    time.sleep(60)

    testresult.append(["\x0a6.1 Warte 23 min (p_t_NHalte_Dauer - 1 min (von Schritt 5.1) - 1 min)", ""])
    time.sleep(1380 - time_difference)
    # for time_sleep in [60, ((60 * 23.367)-time_difference)]:
    #    testresult.append(["\x0aPr�fe nach %s Minute Busruhe und Strommonitoring" % (time_sleep / 60), ""])
    #    func_com.waitSecondsWithResponse(time_sleep)
    testresult.append(["\x0a3. Pr�fe, Kein Senden und Empfangen von Botschaften (WH im lokalen Nachlauf)", ""])
    time_5 = time.time()
    descr, verdict = func_gs.checkBusruhe(daq, 1)
    time_6 = time.time()
    time_difference3 = time_6 - time_5
    testresult.append([descr, verdict])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.002,  # 2mA
            max_value=0.100,  # 100mA
            descr="Pr�fe, dass Strom zwischen 2mA und 100mA liegt"
        )
    )
    testresult.append(["\x0a7. Warte bis Timer 1 abgelaufen ist (und Timer 2 startet) und pr�fe Signale:", ""])
    time.sleep(60 - time_difference3)

    testresult.append(["\x0aPr�fe, dass NM_Waehlhebel Botschaft empfangen wurde", ""])
    testresult += [
        basic_tests.checkStatus(hil.NM_Waehlhebel__NM_Waehlhebel_CBV_AWB__value, 1,
                                descr="NM_Waehlhebel_CBV_AWB: Aktiver_WakeUp"),
        basic_tests.checkStatus(hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value, 1,
                                descr="WH_Zustand_N_Haltephase_2: aktiv_Timer_laeuft"),
        func_nm.checkFcabBitwise(hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value.get(), [1], [],
                                 descr="NM_Waehlhebel_FCAB:12_GearSelector"),
        basic_tests.checkStatus(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Tmin__value, 1,
                                descr="NM_Waehlhebel_NM_aktiv_Tmin:Mindestaktivzeit")
    ]
    ##
    testresult.append(["\x0a7.6 Schalte Senden von RX Signalen (HiL --> ECU) an ", ""])
    func_nm.hil_ecu_tx_off_state("an")

    testresult.append(["\x0a8. Warte bis Timer 2 abgelaufen ist (und Timer 3 startet) und pr�fe Signale", ""])
    testresult.append(["\x0a8.1 Warte 1 min (p_t_NHalte_v_Check)", ""])
    time.sleep(60)

    testresult.append(["\x0aPr�fe WH_Zustand_N_Haltephase_2 = 1 ", "INFO"])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 (aktiv_Timer_laeuft) ist",
        )
    )

    testresult.append(["\x0a8.3 Schalte Senden von RX Signalen (HiL --> ECU) aus", "INFO"])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0a9. Warte bis 2 Minute bevor Timer 3 (3 min) abl�uft und Pr�fe Kommunikation", "INFO"])
    time.sleep(120)

    testresult.append(["\x0a9.1 Warte 1 min (p_t_NHalte_verl - 2 min)", ""])
    time.sleep(60)

    testresult.append(["\x0aPr�fe, Kein Senden und Empfangen von Botschaften (WH im lokalen Nachlauf", ""])
    time_6 = time.time()
    descr, verdict = func_gs.checkBusruhe(daq, 1)
    time_7 = time.time()
    testresult.append([descr, verdict])
    time_difference4 = time_7 - time_6

    testresult.append(["Pr�fe Strommonitoring (2 mA<I<100mA)", ""])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.002,  # 2mA
            max_value=0.100,  # 100mA
            descr="Pr�fe, dass Strom zwischen 2mA und 100mA liegt"
        )
    )

    testresult.append(["\x0a10. Warte bis Timer 3 abgelaufen ist (und Timer 4 startet) und pr�fe Signale:", ""])
    testresult.append(["\x0a10.1 Warte 2 min ", ""])
    time.sleep(120- time_difference4)

    testresult.append(["\x0aPr�fe, dass NM_Waehlhebel Botschaft empfangen wurde", ""])
    testresult += [
        basic_tests.checkStatus(hil.NM_Waehlhebel__NM_Waehlhebel_CBV_AWB__value, 1,
                                descr="01_CarWakeUp: 0"),
        basic_tests.checkStatus(hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value, 1,
                                descr="WH_Zustand_N_Haltephase_2: aktiv_Timer_laeuft"),
        basic_tests.checkStatus(hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value, 0,
                                descr="NM_Waehlhebel_FCAB:12_GearSelector"),
        basic_tests.checkStatus(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Tmin__value, 1,
                                descr="NM_Waehlhebel_NM_aktiv_Tmin:Mindestaktivzeit"),
    ]

    testresult.append(["\x0a10.7 Schalte Senden von RX Signalen (HiL --> ECU) an", ""])
    func_nm.hil_ecu_tx_off_state("an")

    testresult.append(["\x0a11. N-Haltephase Timer 4 wird verl�ngert", ""])
    testresult.append(["\x0a11.1 Warte 500ms", ""])
    time.sleep(.500)

    testresult.append(["\x0a11.1 Pr�fe Waehlhebel_04:WH_Zustand_N_Haltephase_2", ""])
    testresult.append(basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=5,
            descr="Pr�fe, dass Wert 5 (aktiv_Hinweismeldung) ist",))

    testresult.append(["\x0a11.2 Pr�fe NM_Waehlhebel:NM_Waehlhebel_FCAB ", ""])
    descr, verdict = func_nm.checkFcabBitwise(hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value.get(), [1], [],
                                              "Pr�fe, Bit 1 (01_CarWakeUp) == 1 ist")
    testresult.append([descr, verdict])

    testresult.append(["\x0a11.3 VDSO_05:VDSO_Vx3d = 32838 (1,008 km/h) senden ", ""])
    # cycle_vdso = hil.VDSO_05__period.value_lookup['an']
    # descr, verdict = func_gs.setVelocity_kmph(1.008, True, (cycle_vdso * 1 / 1000))
    descr, verdict = func_gs.setVelocity_kmph(1.008, True)
    testresult.append([descr, verdict])
    testresult.append(["\x0a11.4 Warte 1 min ", ""])
    time.sleep(60)

    testresult.append(["\x0a11.5 Pr�fe Waehlhebel_04:WH_Zustand_N_Haltephase_2", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    testresult.append(["\x0a11.6 Pr�fe NM_Waehlhebel:NM_Waehlhebel_FCAB ", ""])
    descr, verdict = func_nm.checkFcabBitwise(hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value.get(), [1], [],
                                              "Pr�fe, Bit 1 (01_CarWakeUp) == 1 ist")
    testresult.append([descr, verdict])

    testresult.append(["\x0a11.7 VDSO_05:VDSO_Vx3d = 32838 (1,008 km/h) senden", ""])
    # descr, verdict = func_gs.setVelocity_kmph(0, True, (cycle_vdso * 2 / 1000))
    descr, verdict = func_gs.setVelocity_kmph(0, True)
    testresult.append([descr, verdict])

    testresult.append(["\x0a11.8 Warte 10ms (2*Zykluszeit VDSO_05))", ""])
    time.sleep(0.010) #TODO check the cycle time

    testresult.append(["\x0a11.9 Pr�fe Waehlhebel_04:WH_Zustand_N_Haltephase_2", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=5,
            descr="Pr�fe, dass Wert 5 (aktiv_Hinweismeldung) ist",))

    testresult.append(["\x0a11.10 Pr�fe NM_Waehlhebel:NM_Waehlhebel_FCAB ", ""])
    descr, verdict = func_nm.checkFcabBitwise(hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value.get(), [1], [],
                                              "Pr�fe, Bit 1 (01_CarWakeUp) == 1 ist")
    testresult.append([descr, verdict])

    testresult.append(["\x0a11.11 Warte 1 min (p_t_NHalte_v_Check)", ""])
    time.sleep(60)

    testresult.append(["\x0a12. Pr�fe, dass Timer 4 verlassen wurde und N-Haltephase beendet wird", ""])
    testresult.append(["\x0a12.1 Pr�fe Waehlhebel_04:WH_Zustand_N_Haltephase_2", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value,
            nominal_status=2,
            descr="Pr�fe, dass Wert 1 (beendet_Timer_abgelaufen) ist",
        )
    )

    testresult.append(["\x0a12.2 Pr�fe NM_Waehlhebel:NM_Waehlhebel_FCAB ", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value,
            nominal_status=0,
            descr="Pr�fe, dass Wert Bit 1 (01_CarWakeUp) == 0",
        )
    )
    testresult.append(["\x0a12.3 Setze SiShiftStLghtDrvPosn = 'P', und Warte 1 min", ""])
    descr, verdict = func_gs.changeDrivePosition('P')
    time.sleep(60)
    testresult.append(["\xa0" + descr, verdict])

    testresult.append(["\x0a12.5 Pr�fe Busruhe (0<I<2mA)", ""])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.0,  # 0mA
            max_value=0.002,  # 2mA
            descr="Pr�fe, dass Strom zwischen 0mA und 2mA liegt"
        )
    )

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)
