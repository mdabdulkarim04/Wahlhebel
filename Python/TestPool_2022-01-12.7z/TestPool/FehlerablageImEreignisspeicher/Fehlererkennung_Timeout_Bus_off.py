#*******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : Fehlererkennung_Timeout_Bus_off.py
# Title   : Fehlererkennung Timeout Bus Off
# Task    : Timeouttest of HIL-Tx => ECU-Rx Signals of CAN Message Timeout Bus Off

# Author  : Mohammed Abdul Karim
# Date    : 24.08.2021
# # Copyright 2021 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************** Version ***********************************
#******************************************************************************
# Rev. | Date        | Name       | Description
#------------------------------------------------------------------------------
# 1.0  | 24.08.2021  | Mohammed | initial
# 1.1  | 04.11.2021  | Mohammed | Rework
# 1.2  | 21.12.2021 | Mohammed     | Added Fehler Id
#******************************************************************************

from _automation_wrapper_ import TestEnv
testenv = TestEnv()

# Imports #####################################################################
from simplified_bus_tests import getMaxValidPeriod, setTestcaseId
import time
import data_common as dc
import functions_gearselection
import functions_nm

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    testenv.startupECU()  # startup before cal vars are called
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    canape_diag = testenv.getCanapeDiagnostic()
    func_nm = functions_nm.FunctionsNM(testenv)

    # Initialize variables ####################################################
    wait_time = 5000  # CAN_3244
    #exp_dtc = 0x200100   #

    send_messages = func_gs.getAllTimestamps("TX", 'cycletime')
    #meas_vars = send_messages + [hil.vbat_cl30__V]

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_207")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Lese Fehlerspeicher (muss leer sein)", ""])

    testresult.append(["[-] Pr�fe, dass Fehler l�schbar ist", ""])
    testresult.append(canape_diag.resetEventMemory(wait=True))
    testresult.append(canape_diag.checkEventMemoryEmpty())

    # hil.Systeminfo_01__SI_NWDF__value.set(1)
    # hil.Systeminfo_01__SI_NWDF_30__value.set(1)

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split(".py")[0], ""])

    testresult.append(["\x0a1. Starte zyklisches Senden von Botschaften" , "INFO"])
    # func_gs.getAllTimestamps("TX", 'cycletime')
    hil.can0_HIL__HIL_TX__enable.set(0)
    # func_nm.hil_ecu_tx_off_state("an")


    testresult.append(["\x0a2. Lese Fehlerspeicher aus", ""])
    testresult.append(["Pr�fe, dass Fehler l�schbar ist", ""])
    testresult.append(canape_diag.checkEventMemoryEmpty())

    testresult.append(["\x0a4 Schalte Senden von RX Signalen (HiL --> ECU) aus", ""])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0a5.Warte 500ms (Initial Timeout) (%sms)" % (wait_time), ""])
    time.sleep(0.500)
    # time.sleep(float(wait_time) / 1000)
    testresult.append(["\x0a6. Lese Fehlerspeicher aus ", ""])
    testresult.append(["\x0aPr�fe DTC Nummer 0x200100 aktiv im Fehlerspeicher ist", ""])
    active_dtcs = [(0xE00100, 0x27)]
    testresult.append(canape_diag.checkEventMemory(active_dtcs, ticket_id='Fehler Id:139'))

    testresult.append(["\x0a7. Sende erneut zyklisch Botschaften", "INFO"])
    # func_gs.getAllTimestamps("TX", 'cycletime')
    # func_nm.hil_ecu_tx_off_state("an")
    hil.can0_HIL__HIL_TX__enable.set(1)



    testresult.append(["\x0a8. Warte 500 ms (Initial Timeout) (%sms)" % (wait_time), ""])
    time.sleep(0.500)
    # time.sleep(float(wait_time) / 1000)
    testresult.append(["\x0a9. Lese Fehlerspeicher aus", ""])
    testresult.append(["\x0aPr�fe DTC Nummer 0x200100 passiv im Fehlerspeicher ist", ""])
    passive_dtcs = [(0xE00100, 0x27)]
    testresult.append(canape_diag.checkEventMemory(passive_dtcs, ticket_id='Fehler Id:139'))

    testresult.append(["\x0a10. Fehlerspeicher l�schen", ""])
    testresult.append(canape_diag.resetEventMemory(wait=True))

    testresult.append(["\x0a11. Warte 1000ms", "INFO"])
    time.sleep(1)

    testresult.append(["\x0aPr�fe Fehlerspeicher leer ist", ""])
    testresult.append(canape_diag.checkEventMemoryEmpty())

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["Shutdown ECU", ""])
    testenv.shutdownECU()

    # cleanup
    cal = None
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()

