# *******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : CAN_EI_Rx_Signals_SiShift_01_Timeout.py
# Title   : CAN_EI_Rx_Signals_SiShift_01_Timeout
# Task    : Timeouttest of HIL-Tx => ECU-Rx Signals of CAN Message SiShift_01

# Author  : A.Neumann
# Date    : 28.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
# ******************************************************************************
# ********************************** Version ***********************************
# ******************************************************************************
# Rev. | Date        | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 28.05.2021  | A. Neumann | initial created Timeout Test
# 1.1  | 07.07.2021  | A. Neumann | adapted for Waehlhebel_04 Errorreaction
# 1.2  | 27.07.2021 | Mohammed | Added TestSpec_ID
# 1.3  | 22.11.2021 | Mohammed | Rework
# 1.4  | 21.12.2021 | Mohammed     | Added Fehler Id
# ******************************************************************************

from _automation_wrapper_ import TestEnv

testenv = TestEnv()

# Imports #####################################################################
from simplified_bus_tests import getMaxValidPeriod, setTestcaseId
import time
import data_common as dc
from ttk_daq import eval_signal

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    testenv.startupECU()  # startup before cal vars are called
    canape_diag = testenv.getCanapeDiagnostic()
    daq = testenv.getGammaDAQ()

    # Initialize variables ####################################################
    period_var = hil.SiShift_01__period
    cycle_time = period_var.value_lookup["an"]
    max_valid_cycletime = getMaxValidPeriod(cycletime_ms=cycle_time)
    wait_time = 5000  # CAN_3244
    ftti_ms = 50
    #exp_dtc = 0x200101  # cdd 001009: U200101
    failure_reac_var = hil.Waehlhebel_04__WH_Fahrstufe__value
    fehlerwert = 15
    meas_vars = [failure_reac_var, hil.SiShift_01__period]

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_61")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Lese Fehlerspeicher (muss leer sein)", ""])

    testresult.append(["[-] Pr�fe, dass Fehler l�schbar ist", ""])
    testresult.append(canape_diag.resetEventMemory(wait=True))
    testresult.append(canape_diag.checkEventMemoryEmpty())

    hil.Systeminfo_01__SI_NWDF__value.set(1)
    hil.Systeminfo_01__SI_NWDF_30__value.set(1)
    # hil.VDSO_05__period.setState("aus")

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split(".py")[0], ""])

    testresult.append(["\xa0Start DAQ Measurement f�r Kommunikationsanalyse", ""])
    daq.startMeasurement(meas_vars)
    time.sleep(1)

    testresult.append(["[+] Pr�fe, dass kein Fehler gesetzt wird bei g�ltiger Zyklusver�nderung", ""])
    testresult.append(["[+] �ndere Zykluszeit und pr�fe Fehlerspeicher", ""])
    testresult.append(["Setze Zykluszeit auf %sms" % max_valid_cycletime, "INFO"])
    period_var.set(max_valid_cycletime)
    testresult.append(["Warte maximum tMSG_CYCLE (%sms)" % (wait_time), "INFO"])
    time.sleep(float(wait_time) / 1000)
    testresult.append(["[.] Lese Fehlerspeicher (muss leer sein)", ""])
    testresult.append(canape_diag.checkEventMemoryEmpty())

    testresult.append(["[-] Pr�fe, dass ein Fehler gesetzt wird bei Timeout", ""])
    testresult.append(["[+] �ndere Zykluszeit und pr�fe Fehlerspeicher", ""])
    testresult.append(["Setze Zykluszeit auf 0ms", "INFO"])
    period_var.set(0)
    testresult.append(["Warte maximum tMSG_CYCLE (%sms)" % (wait_time), "INFO"])
    time.sleep(float(wait_time) / 1000)
    testresult.append(["[.] Lese Fehlerspeicher (Timeout DTC aktiv)", ""])
    active_dtcs = [(0xE00012, 0x27)]
    testresult.append(canape_diag.checkEventMemory(active_dtcs, ticket_id='Fehler Id:144'))

    testresult.append(["[-] Pr�fe, dass Fehler zur�ckgesetzt wird bei erneutem richtigen Empfangen", ""])
    testresult.append(["[+] �ndere Zykluszeit und pr�fe Fehlerspeicher", ""])
    testresult.append(["Setze Zykluszeit auf %sms" % cycle_time, "INFO"])
    period_var.set(cycle_time)

    testresult.append(["[.] Lese Fehlerspeicher (Timeout DTC passiv)", ""])
    passive_dtcs = [(0xE00012, 0x27)]
    testresult.append(canape_diag.checkEventMemory(passive_dtcs, ticket_id='Fehler Id:144'))

    testresult.append(["Warte maximum tMSG_CYCLE (%sms)" % (wait_time), "INFO"])
    time.sleep(float(wait_time) / 1000)
    # testresult.append(["[.] Lese Fehlerspeicher (Timeout DTC passiv)", ""])
    # passive_dtcs = [(0xE00012, 0x27)]
    # testresult.append(canape_diag.checkEventMemory(passive_dtcs, ticket_id='Fehler Id:144'))

    testresult.append(["[.] Lese Fehlerspeicher (muss leer sein)", ""])
    testresult.append(canape_diag.checkEventMemoryEmpty())

    testresult.append(["[-] Pr�fe, dass Fehler l�schbar ist", ""])
    testresult.append(canape_diag.resetEventMemory(wait=True))

    testresult.append(["Stopp DAQ Measurement", ""])
    daq_data = daq.stopMeasurement()
    time.sleep(0.5)

    testresult.append(["\nStart Analyse of DAQ Measurement", ""])
    plot_data = {}
    plot_data[str(failure_reac_var)] = daq_data[str(failure_reac_var)]
    v_lines = {}

    # search failure time --> SiShift period = max_valid_cycletime
    sishift_data = daq_data[str(hil.SiShift_01__period)]
    analyse_sishift_data = eval_signal.EvalSignal(sishift_data)
    analyse_sishift_data.clearAll()

    time_zero = analyse_sishift_data.getTime()

    time_period_stopp = analyse_sishift_data.find(operator="==", value=max_valid_cycletime)
    v_lines[1] = {'x': time_period_stopp - time_zero, 'label': 'SiShift Period == %s'%max_valid_cycletime}
    v_lines[2] = {'x': time_period_stopp - time_zero + (ftti_ms/1000.0), 'label': 'FTTI Ende (nach %sms)' %ftti_ms}

    # search changetime waehlhebel_04:wh_fahrstufe = Fehlerwert
    fahrstufe_data = daq_data[str(failure_reac_var)]
    analyse_fahrstufe_data = eval_signal.EvalSignal(fahrstufe_data)
    analyse_fahrstufe_data.clearAll()

    start_value = analyse_fahrstufe_data.getData()

    failure_timestamp = analyse_fahrstufe_data.find(operator="==", value=fehlerwert)

    if failure_timestamp:
        curr_ftti = failure_timestamp - time_period_stopp

        if curr_ftti >= 0:
            if curr_ftti <= (ftti_ms / 1000.0):
                descr = "Fehlerwert wurde korrekt gesetzt (nach %sms)" % (curr_ftti * 1000)
                verdict = "PASSED"
            else:
                descr = "Fehlerwert wurde zu sp�t gesetzt (erst nach %sms)" % (curr_ftti * 1000)
                verdict = "FAILED"
        else:
            descr = "Fehlerwert wurde gesetzt, bevor Timeout erkannt werden soll"
            verdict = "FAILED"
    else:
        descr = "Waehlhebel_04:WH_Fahrstufe wurde nicht auf Fehlerwert %s gesetzt" % fehlerwert
        verdict = "FAILED"

    testresult.append(["[.] Pr�fe, dass Fehlerwert (Waehlhebel_04:WH_Fahrstufe) gesetzt wurde", ""])
    testresult.append([descr, verdict])

    testresult.append(
        daq.plotMultiShot(plot_data, testenv.script_name.split(".py")[0], v_lines=v_lines)
    )

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["Shutdown ECU", ""])
    testenv.shutdownECU()

    # cleanup
    cal = None
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()

