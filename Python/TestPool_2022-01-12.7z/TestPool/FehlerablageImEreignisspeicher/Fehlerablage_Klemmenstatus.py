#*******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : Fehlerablage_Klemmenstatus.py
# Title   : Fehlerablage_Klemmenstatus
# Task    : Fehlerablage Klemmenstatus

# Author  : Mohammed Abdul Karim
# Date    : 05.11.2021
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************** Version ***********************************
#******************************************************************************
# Rev. | Date        | Name       | Description
#------------------------------------------------------------------------------
# 1.0  | 05.11.2021  | Mohammed| initial
# 1.1  | 11.01.2022  | Mohammed| Rework

#******************************************************************************

from _automation_wrapper_ import TestEnv
testenv = TestEnv()

# Imports #####################################################################
from simplified_bus_tests import getMaxValidPeriod, setTestcaseId
import time
import data_common as dc
import functions_hil

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()
    testenv.startupECU()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    func_hil = functions_hil.FunctionsHil(testenv, hil)
    canape_diag = testenv.getCanapeDiagnostic()

    # Initialize variables ####################################################
    failure_set_time = 1  # CAN_3244

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_210")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Schalte KL30 an (KL15 aus)", ""])
    hil.cl15_on__.set(0)

    testresult.append(["[+] Lese Fehlerspeicher (muss leer sein)", ""])
    testresult.append(canape_diag.resetEventMemory(wait=True))
    testresult.append(["[-] Pr�fe, dass Fehler l�schbar ist", ""])
    testresult.append(canape_diag.checkEventMemoryEmpty())

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split(".py")[0], ""])

    testresult.append(["\x0a1. Setze hil.vbat_cl30__V == 16.70V", ""])
    hil.vbat_cl30__V.set(16.70)

    testresult.append(["\x0a2. Fehlerspeicher ist leer", ""])
    testresult.append(canape_diag.checkEventMemoryEmpty())

    testresult.append(["\x0a3. KL15 ein", ""])
    hil.cl15_on__.set(1)

    testresult.append(["\x0a4. Warte %ss - Fehlererkennungszeit" % failure_set_time, "INFO"])
    time.sleep(failure_set_time)

    testresult.append(["\x0a5. Lese Fehlerspeicher", ""])
    testresult.append(["\x0aPr�fe DTC 0x000101 in Fehlerspeicher ist", ""])
    active_dtcs = [(0x800100, 0x27), (0x800101, 0x27)]
    testresult.append(canape_diag.checkEventMemory(active_dtcs))

    testresult.append(["\x0a6. Setze hil.vbat_cl30__V == 13V", ""])
    hil.vbat_cl30__V.set(13.0)

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["Shutdown ECU", ""])
    testenv.shutdownECU()

    # cleanup
    cal = None
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()

