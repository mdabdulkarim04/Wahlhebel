#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Routine_Check_Memory.py
# Task    : Test for Routine_Check_Memory 0x3101 0xFF00  0x0101
#
# Author  : Mohammed Abdul Karim
# Date    : 19.11.2021
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 19.11.2021 | Mohammed | initial
# 1.1  | 19.11.2021 | Mohammed | Added Fehler Id

#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
import time
from ttk_checks import basic_tests
import functions_gearselection

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_165")

    # Initialize functions ####################################################
    hil = testenv.getHil()
    func_common = functions_common.FunctionsCommon(testenv)
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Check Erase Memory']

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()

    # TEST PROCESS ############################################################
    testresult.append(["[.] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa01. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\xa02. Routine starten: 0x3101 FF00 01 01 (Erase Memory)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response:0x7F31 + 1 Byte", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31))

    testresult.append(["\xa0 Pr�fe Inhalt der Response", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x31, ticket_id= 'Fehler-Id:EGA-PRM-137'))

    # 5. Wechsel in Extended Session: 0x1003
    testresult.append(["\x0a5. Wechsel in Extended Session: 0x1003", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\xa07. Routine starten: 0x3101 FF00 01 01 (Erase Memory)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0  Pr�fe auf Negative Response:0x7F31 + 1 Byte", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31))

    testresult.append(["\xa0 Pr�fe Inhalt der Response", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x31, ticket_id= 'Fehler-Id:EGA-PRM-137'))

    # 10. Wechsel in Programming Session: 0x1002
    testresult.append(["\x0a10. Wechsel in Programming Session: 0x1002", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('programming'))

    testresult.append(["\xa011. Routine starten: 0x3101 FF00 01 01 (Erase Memory)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response:0x7F31 + 1 Byte", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x33, ticket_id= 'Fehler-Id:EGA-PRM-137'))

    testresult.append(["\xa0 Pr�fe Inhalt der Response", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x33,ticket_id= 'Fehler-Id:EGA-PRM-137'))

    # Wechsel in Default Session: 0x1001
    testresult.append(["\x0a15. Wechsel in Default Session: 0x1001", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))

    # 15. Wechsel in Factory Mode: 0x1060
    testresult.append(["\x0a15. Wechsel in Factory Mode: 0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa016. Routine starten: 0x3101 FF00 01 01 (Erase Memory)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0  Pr�fe auf Negative Response:0x7F31 + 1 Byte", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31))

    testresult.append(["\xa0 Pr�fe Inhalt der Response", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x31, ticket_id= 'Fehler-Id:EGA-PRM-137'))

#### 20. Security Access aktivieren
    testresult.append(["\xa020. Security Access aktivieren"])
    testresult.append(["\xa020.1. Seed anfragen: 0x2711"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(result)

    testresult.append(["\xa020.2. Key berechnen: <key 1>"])
    key, verdictkey = canape_diag.calculateKey(seed)
    testresult.append(verdictkey)

    testresult.append(["\xa020.3. Key senden: 0x2712 + <key 1>"])
    verdict = canape_diag.sendKey(key)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(verdict)

    ## 21. Routine starten: 0x3101 FF00 01 01 (Erase Memory)
    testresult.append(["\xa021. Routine starten: 0x3101 FF00 01 01 (Erase Memory)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0  Pr�fe auf Negative Response:0x7F31 + 1 Byte", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31))

    testresult.append(["\xa0 Pr�fe Inhalt der Response", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x31, ticket_id= 'Fehler-Id:EGA-PRM-137'))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
