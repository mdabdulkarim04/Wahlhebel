# ******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_Knockout_Timer.py
# Title   : Diagnose_Knockout_Timer
# Task    : A minimal "Diagnose Knockout Timer!" test script

# Author  : Mohammed Abdul Karim
# Date    : 05.11.2021
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 10.11.2021 | Mohammed  | initial
# 1.1  | 10.11.2021 | Mohammed  | Rework
# 1.2  | 13.12.2021 | Mohammed   | Added Fehler id
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t

testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    hil = testenv.getHil()
    testresult = testenv.getResults()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Knockout_timer']

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_162")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # 1. In Default Session auslesen"
    testresult.append(["\xa01. In Default Session auslesen", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\xa01.1 Auslesen der Knockout Timer: 0x2202CB"])
    response_dict = {}
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request, ticket_id='Fehler-Id: EGA-PRM-134'))

    testresult.append(["Datenl�nge: 2 Bytes �berpr�fen", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'], ticket_id='Fehler-Id: EGA-PRM-134'))

    if diag_ident['name'] == 'Knockout_timer':
        testresult.append(["\xa01.3 BusKnockOut_Tmr_NVEM auswerten : (NVEM Kopplung aktiv)", ""])
        testresult.append(canape_diag.checkResponseBitMask(response, 'XXXXXX1XXXXXXXXX', ticket_id='Fehler-Id: EGA-PRM-134'))

    if len(response) > 3:
        response_dict[diag_ident['name']] = response[3:]
        testresult.append(["\xa0Ausgelesener %s: %s" % (diag_ident['name'], response[3:]), ""])
    else:
        testresult.append(["Unerwartete Response! Folgende Tests davon betroffen!", "FAILED"])

    testresult.append(["\xa02. Schreiben im Factory Mode"])

    testresult.append(["\x0a2.1 Wechsel in die Default Session: 0x1001", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))

    testresult.append(["\xa02.2 Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\x0a2.3 Wechsel in Factory Mode:  0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa02.4 Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('factory_mode'))

    testresult.append(["\xa02.5 Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(result)

    testresult.append(["\xa02.6 Key berechnen:"])
    key, verdictkey = canape_diag.calculateKey(seed)
    testresult.append(verdictkey)

    testresult.append(["\xa02.7 Key senden: 0x2762 + <berechnet key>:"])
    verdict = canape_diag.sendKey(key)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(verdict)

    testresult.append(["\xa02.8 Schreiben der Knockout Timer: 0x2E02CB + 3C3C (jew. 60dez)"])
    req = [0x2E, 0x02, 0xCB, 0x3C, 0x3C]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 02CB ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, req))

    testresult.append(["\x0a2.9 Auslesen der Knockout Timer: 0x2202CB"])
    req = [0x22, 0x02, 0xCB]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62, 0x02, 0xCB, 0x3C, 0x3C]
    testresult.append(["Pr�fe Positive Response: 0x6202CB + 3C3C", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\xa03 Versuchen, ung�ltigen Wert f�r den Timer zu schreiben (< Min-Wert)"])
    testresult.append(["\xa03.1 Schreiben der Knockout Timer: 0x2E02CB + F200"])
    req = [0x2E, 0x02, 0xCB, 0xF2, 0x00]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response: 0x7F 2E 31", ""])
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, req, 0x7F, ticket_id='Fehler-Id: EGA-PRM-134'))

    testresult.append(["\xa03.2 Schreiben der Knockout Timer: 0x2E02CB + 3AF0"])
    req = [0x2E, 0x02, 0xCB, 0x3A, 0xF0]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response: 0x7F 2E 31", ""])
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, req, 0x7F, ticket_id='Fehler-Id: EGA-PRM-134'))

    testresult.append(["\xa0 4. Anpasswerte wieder auf vorherige Werte setzen", ""])
    request_timer = [0x2E, 0x02, 0xCB, 0x0F, 0x0F]  # [0x0F, 0x0F]

    testresult.append(["\xa0 4.1 Schreiben der Knockout Timer: 0x2E02CB + <timer>", ""])

    testresult.append(["\xa0 Pr�fe Positive Response: 0x6E 02CB ist ", ""])
    [response, result] = canape_diag.sendDiagRequest(request_timer)
    testresult.append(result)
    testresult.append(canape_diag.checkPositiveResponse(response, request_timer))

    testresult.append(["\xa04.2 Auslesen der Knockout Timer: 0x2202CB", ""])

    testresult.append(["\x0a Pr�fe Positive Response: 0x6202CB + <timer> ist"])
    req = [0x22, 0x02, 0xCB]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)
    testresult.append(canape_diag.checkPositiveResponse(response, req))

    expected_resp = [0x62, 0x02, 0xCB, 0x0F, 0x0F]
    testresult.append(["Pr�fe Timer : FF", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print "Done."
