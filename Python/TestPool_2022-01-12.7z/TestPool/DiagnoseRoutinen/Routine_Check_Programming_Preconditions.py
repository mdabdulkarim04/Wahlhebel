#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Routine_Check_Programming_Preconditions.py
# Task    : Test for Routine Diagnosejob 0x3101 0x0203
#
# Author  : An3Neumann
# Date    : 08.07.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 08.07.2021 | An3Neumann | initial
# 1.1  | 06.12.2021 | Mohammed | Rework
# 1.2  | 03.11.2022 | Mohammed   | NEU hinzu, ersetzt Selector lever in position P
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
import time
from ttk_checks import basic_tests
import functions_gearselection

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_149")

    # Initialize functions ####################################################
    hil = testenv.getHil()
    func_common = functions_common.FunctionsCommon(testenv)
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Check Programming Preconditions']
    geschwindigkeit = 10
    exp_wrong_prec = [0x05, 0xA5] # geschwindigkeit, Selector P
    testsessions = ['default', 'extended', 'factory']

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()
    testresult.append(["[.] Setze SiShift_01:SIShift_StLghtDrvPosn auf P", ""])
    descr, verdict = func_gs.changeDrivePosition('P')
    testresult.append([descr, verdict])
    testresult.append(["[.] Setze Geschwindigkeit auf 0km/h", ""])
    descr, verdict = func_gs.setVelocity_kmph(velocity_kmph=0)
    testresult.append([descr, verdict])

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    for session in testsessions:
        if session =='default':
            # Auslesen der Active Diagnostic Session: 0x22F186
            testresult.append(["[+] Lese aktuelle Diagnose Session aus", ""])
            testresult.extend(canape_diag.checkDiagSession(session))
        else:
            # Wechsel in Extended Session: 0x1003
            testresult.append(["[.] In die %s wechseln" %session, ""])
            testresult.extend(canape_diag.changeAndCheckDiagSession(session))
            time.sleep(1)

        testresult.append(["[.] '%s' ausf�hren: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
        request = [0x31, 0x01] + diag_ident['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
        descr, verdict = canape_diag.checkPositiveResponse(response, request, 4)
        testresult.append([descr, verdict])

        testresult.append(["[.] Inhalt der Response �berpr�fen", ""])
        response_content = response[4:]
        if response_content:
            testresult.append(["Liste sollte leer sein, alle Preconditions erf�llt", "FAILED"])
        else:
            testresult.append(["Liste ist leer, alle Preconditions erf�llt", "PASSED"])

    testresult.append(["[.] Setze Geschwindigkeit auf %skm/h"%geschwindigkeit, ""])
    descr, verdict = func_gs.setVelocity_kmph(velocity_kmph=geschwindigkeit)
    testresult.append([descr, verdict])

    testresult.append(["[.] Setze SiShift_01:SIShift_StLghtDrvPosn auf R", ""])
    descr, verdict = func_gs.changeDrivePosition('R')
    testresult.append([descr, verdict])

    for session in testsessions:

        # Wechsel in Extended Session: 0x1003
        testresult.append(["[.] In die %s wechseln" %session, ""])
        testresult.extend(canape_diag.changeAndCheckDiagSession(session))
        time.sleep(1)

        # Auslesen der Active Diagnostic Session: 0x22F186
        testresult.append(["[.] Lese aktuelle Diagnose Session aus", ""])
        testresult.extend(canape_diag.checkDiagSession(session))

        testresult.append(["[.] '%s' ausf�hren: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
        request = [0x22, 0x04, 0x48] #[0x31, 0x01] + diag_ident['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
        descr, verdict = canape_diag.checkPositiveResponse(response, request)
        testresult.append([descr, verdict])

        if verdict == 'PASSED':

            descr, verdict = canape_diag.checkDataLength(response, 7, 7)
            testresult.append([descr, verdict])

            for prec in exp_wrong_prec:
                if prec in response[4:]:
                    testresult.append(["Nicht erf�llte Precondition wird wie erwartet aufgelistet - 0x%02X"%prec, 'PASSED'])
                else:
                    testresult.append(
                        ["Nicht erf�llte Precondition wird nicht aufgelistet - 0x%02X" % prec, 'FAILED'])
        else:
            testresult.append(["Inhalt kann nicht gepr�ft werden, da Response nicht positiv war", 'FAILED'])


    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
