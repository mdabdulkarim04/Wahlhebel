#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Routine_Check_Programming_Dependencies.py
# Task    : Test for Routine Diagnosejob 0x3101 0xFF01
#
# Author  : An3Neumann
# Date    : 09.07.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 09.07.2021 | An3Neumann | initial
# 1.1  | 06.12.2021 | Mohammed   | Rework
# 1.2  | 13.12.2021 | Mohammed   | Added Fehler id
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
import time
from ttk_checks import basic_tests

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_170")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Check Programming Dependencies']
    '''
    test_sessions = {
        1: {'session': 'Default Session', 'sec_access': False, 'allowed': False},
        2: {'session': 'Extended Session', 'sec_access': False, 'allowed': False},
        3: {'session': 'Factory Mode', 'sec_access': False,  'allowed': False},
        4: {'session': 'Programming Session', 'sec_access': False,  'allowed': False},
        5: {'session': 'Programming Session', 'sec_access': True, 'allowed': True},
    }
    '''
    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa01. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\xa02. Routine starten: 0x3101 0xFF01 (Check Programming Dependencies)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response:0x7F317E ", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31, ticket_id='Fehler-Id:EGA-PRM-133'))

    # 3. Wechsel in Extended Session: 0x1003
    testresult.append(["\x0a3. Wechsel in Extended Session: 0x1003", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\xa05. Routine starten: 0x3101 0xFF01 (Check Programming Dependencies)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response:0x7F317E ", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31, ticket_id='Fehler-Id:EGA-PRM-133'))

    # 6. Wechsel in Programming Session: 0x1002
    testresult.append(["\x0a6. Wechsel in Programming Session: 0x1002", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('programming'))

    testresult.append(["\xa08. Routine starten: 0x3101 0xFF01 (Check Programming Dependencies)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response:0x7F317E ", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x33, ticket_id='Fehler-Id:EGA-PRM-133'))

    testresult.append(["\x0a Wechsel in Defaul Session Mode: 0x1001", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))

    # 15. Wechsel in Factory Mode: 0x1060
    testresult.append(["\x0a9. Wechsel in Factory Mode: 0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa011. Routine starten: 0x3101 0xFF01 (Check Programming Dependencies)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe auf Negative Response:0x7F317E ", ""])
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31, ticket_id='Fehler-Id:EGA-PRM-133'))

    #### 12. Security Access aktivieren
    testresult.append(["\xa012. Security Access aktivieren"])
    testresult.append(["\xa012.1. Seed anfragen: 0x2711"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(result)

    testresult.append(["\xa012.2. Key berechnen: <key 1>"])
    key, verdictkey = canape_diag.calculateKey(seed)
    testresult.append(verdictkey)

    testresult.append(["\xa012.3. Key senden: 0x2712 + <key 1>"])
    verdict = canape_diag.sendKey(key)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(verdict)

    testresult.append(["\xa013. Routine starten: 0x3101 0xFF01 (Check Programming Dependencies)", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, request, 0x31, ticket_id='Fehler-Id:EGA-PRM-133'))
    #testresult.append(canape_diag.checkPositiveResponse(response, request, ticket_id='Fehler-Id:EGA-PRM-133'))

    '''
    for session in test_sessions:
        curr_session = test_sessions[session]['session']
        set_check_session = curr_session.split(' ')[0].lower()
        allowed = test_sessions[session]['allowed']
        if session == 1:
            # Auslesen der Active Diagnostic Session: 0x22F186
            testresult.append(["[+] Lese aktuelle Diagnose Session aus", ""])
            testresult.extend(canape_diag.checkDiagSession(set_check_session))
        else:
            # Wechsel in Extended Session: 0x1003
            testresult.append(["[.] In die %s wechseln"%curr_session, ""])
            testresult.extend(canape_diag.changeAndCheckDiagSession(set_check_session))
            time.sleep(1)


        if test_sessions[session]['sec_access']:
            testresult.append(["[.] Erfolgreichen Security Access durchf�hren", ""])
            _, _, result = canape_diag.performSecurityAccess()
            testresult.extend(result)

        testresult.append(["[.] '%s' ausf�hren: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
        request = [0x31, 0x01] + diag_ident['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        if allowed:

            testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
            descr, verdict = canape_diag.checkPositiveResponse(response, request, 4)
            testresult.append([descr, verdict])

            testresult.append(["\xa0Datenl�nge �berpr�fen", ""])
            if verdict == 'FAILED':
                testresult.append(["Pr�fung der Datenl�nge nicht m�glich, da keine positive Response kam", "FAILED"])
            else:
                testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'], 4))

        else:

            testresult.append(["\xa0Auf negative Response �berpr�fen", ""])
            testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x7F))

    '''

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
