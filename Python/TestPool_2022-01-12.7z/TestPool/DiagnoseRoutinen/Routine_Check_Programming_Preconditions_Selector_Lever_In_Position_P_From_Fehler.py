#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Routine_Check_Programming_Preconditions_Selector_Lever_In_Position_P_From_Fehler.py
# Task    : Test for Routine Diagnosejob 0x3101 0x0203
#
# Author  : Mohammed Abdul Karim
# Date    : 29.09.2021
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 28.09.2021 | Mohammed | initial
# 1.1  | 12.10.2021 | Mohammed  | Added TestSpec ID
# 1.3  | 24.11.2021 | Mohammed   | Rework
# 1.4  | 03.11.2022 | Mohammed   | NEU hinzu, ersetzt Selector lever in position P
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
import time
from ttk_checks import basic_tests
import functions_gearselection

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_266")

    # Initialize functions ####################################################
    hil = testenv.getHil()
    func_common = functions_common.FunctionsCommon(testenv)
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Check Programming Preconditions']
    exp_wrong_prec = [0xA5]

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()

    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    testresult.append(["[.] Waehlhebelposition P aktiviert", ""])
    descr, verdict = func_gs.changeDrivePosition('P')
    testresult.append(["\xa0" + descr, verdict])

    testresult.append(["[.] VDSO_Vx3d = 32766 (0 km/h)", ""])
    descr, verdict = func_gs.setVelocity_kmph(0)
    testresult.append(["\xa0" + descr, verdict])

    # TEST PROCESS ############################################################
    testresult.append(["[.] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    # 1./3. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa01. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\xa02. Programmiervorbedingungen pr�fen: 0x31010203", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    descr, verdict = canape_diag.checkPositiveResponse(response, request, 4)
    testresult.append([descr, verdict])

    testresult.append(["Inhalt der Response �berpr�fen", ""])
    response_content = response[4:]
    if response_content:
        testresult.append(["Liste sollte leer sein, alle Preconditions erf�llt", "PASSED"])
    else:
        testresult.append(["Liste ist leer, alle Preconditions erf�llt", "PASSED"])

    # 4./7. Wechsel in Extended Session: 0x1003
    testresult.append(["4. Wechsel in Extended Session: 0x1003", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\xa06. Programmiervorbedingungen pr�fen: 0x31010203", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    descr, verdict = canape_diag.checkPositiveResponse(response, request, 4)
    testresult.append([descr, verdict])

    testresult.append(["Inhalt der Response �berpr�fen", ""])
    response_content = response[4:]
    if response_content:
        testresult.append(["Liste sollte leer sein, alle Preconditions erf�llt", "FAILED"])
    else:
        testresult.append(["Liste ist leer, alle Preconditions erf�llt", "PASSED"])

    # 8./11. Wechsel in die factory_mode Session: 0x1060
    testresult.append(["8. Wechsel in Factory Mode: 0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa010. Programmiervorbedingungen pr�fen: 0x31010203", ""])
    request = [0x31, 0x01] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    descr, verdict = canape_diag.checkPositiveResponse(response, request, 4)
    testresult.append([descr, verdict])
    if response_content:
        testresult.append(["Liste sollte leer sein, alle Preconditions erf�llt", "FAILED"])
    else:
        testresult.append(["Liste ist leer, alle Preconditions erf�llt", "PASSED"])

    testresult.append(["12. Setze SiShift_01:SIShift_StLghtDrvPosn = Fehler", ""])
    descr, verdict = func_gs.changeDrivePosition('Fehler')
    testresult.append([descr, verdict])

    # 13. Wechsel in Default Session: 0x1001
    testresult.append(["13. Wechsel in Default Session: 0x1001", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))

    # 15./16. Programmiervorbedingungen pr�fen: 0x31010203
    testresult.append(["\xa015. Programmiervorbedingungen pr�fen: 0x220448", ""])
    request = [0x22, 0x04, 0x48]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    descr, verdict = canape_diag.checkPositiveResponse(response, request)
    testresult.append([descr, verdict])

    if verdict == 'PASSED':
        descr, verdict = canape_diag.checkDataLength(response, 7, 7)
        testresult.append([descr, verdict])

        for prec in exp_wrong_prec:
            if prec in response[4:]:
                testresult.append(
                    ["Nicht erf�llte Precondition wird wie erwartet aufgelistet - 0x%02X" % prec, 'PASSED'])
            else:
                testresult.append(
                    ["Nicht erf�llte Precondition wird nicht aufgelistet - 0x%02X" % prec, 'PASSED'])
    else:
        testresult.append(["Inhalt kann nicht gepr�ft werden, da Response nicht positiv war", 'FAILED'])

    # 17. Wechsel in Extended Session: 0x1003
    testresult.append(["17. Wechsel in Extended Session: 0x1003", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # 19./20. Programmiervorbedingungen pr�fen: 0x31010203
    testresult.append(["\xa019. Programmiervorbedingungen pr�fen: 0x220448", ""])
    request = [0x22, 0x04, 0x48]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    descr, verdict = canape_diag.checkPositiveResponse(response, request)
    testresult.append([descr, verdict])

    if verdict == 'PASSED':
        descr, verdict = canape_diag.checkDataLength(response, 7, 7)
        testresult.append([descr, verdict])

        for prec in exp_wrong_prec:
            if prec in response[4:]:
                testresult.append(
                    ["Nicht erf�llte Precondition wird wie erwartet aufgelistet - 0x%02X" % prec, 'PASSED'])
            else:
                testresult.append(
                    ["Nicht erf�llte Precondition wird nicht aufgelistet - 0x%02X" % prec, 'FAILED'])
    else:
        testresult.append(["Inhalt kann nicht gepr�ft werden, da Response nicht positiv war", 'FAILED'])

    # 21. Wechsel in Factory Mode: 0x1060
    testresult.append(["21. Wechsel in Factory Mode: 0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    # 22./23. Programmiervorbedingungen pr�fen: 0x31010203
    testresult.append(["23. Programmiervorbedingungen pr�fen: 0x220448", ""])
    request = [0x22, 0x04, 0x48]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    descr, verdict = canape_diag.checkPositiveResponse(response, request)
    testresult.append([descr, verdict])

    if verdict == 'PASSED':
        descr, verdict = canape_diag.checkDataLength(response, 7, 7)
        testresult.append([descr, verdict])

        for prec in exp_wrong_prec:
            if prec in response[4:]:
                testresult.append(
                    ["Nicht erf�llte Precondition wird wie erwartet aufgelistet - 0x%02X" % prec, 'PASSED'])
            else:
                testresult.append(
                    ["Nicht erf�llte Precondition wird nicht aufgelistet - 0x%02X" % prec, 'FAILED'])
    else:
        testresult.append(["Inhalt kann nicht gepr�ft werden, da Response nicht positiv war", 'FAILED'])

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
