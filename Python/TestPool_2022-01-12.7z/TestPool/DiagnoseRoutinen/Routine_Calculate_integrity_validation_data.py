#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Routine_Calculate_integrity_validation_data.py
# Task    : Test for Routine Diagnosejob 0x3101 0x0253
#
# Author  : An3Neumann
# Date    : 05.07.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 05.07.2021 | An3Neumann | initial
# 1.1  | 23.08.2021 | Mohammed | Added Ticket Id
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
import time
from ttk_checks import basic_tests

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_157")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Calculate_integrity_validation_data']
    test_sessions = {
        1: {'session': 'Default Session', 'allowed': True},
        2: {'session': 'Extended Session', 'allowed': True},
        3: {'session': 'Factory Mode', 'allowed': True},
        4: {'session': 'Programming Session', 'allowed': False},
    }
    calc_result = diag_ident['expected_response'][0]
    hash_type = diag_ident['expected_response'][1]
    hash_value = diag_ident['expected_response'][2:]

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    for session in test_sessions:
        curr_session = test_sessions[session]['session']
        set_check_session = curr_session.split(' ')[0].lower()
        allowed = test_sessions[session]['allowed']
        if session == 1:
            # Auslesen der Active Diagnostic Session: 0x22F186
            testresult.append(["[+] Lese aktuelle Diagnose Session aus", ""])
            testresult.extend(canape_diag.checkDiagSession(set_check_session))
        else:
            # Wechsel in Extended Session: 0x1003
            testresult.append(["[.] In die %s wechseln"%curr_session, ""])
            testresult.extend(canape_diag.changeAndCheckDiagSession(set_check_session))
            time.sleep(1)

        for ident in diag_ident['identifier']:

            testresult.append(["[.] '%s (%s)' auslesen: %s" % (diag_ident['name'], ident, str(HexList(diag_ident['identifier'][ident]))), ""])
            request = [0x31, 0x01] + diag_ident['identifier'][ident]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)

            if allowed:

                testresult.append(["[.] Auf positive Response �berpr�fen", ""])
                descr, verdict = canape_diag.checkPositiveResponse(response, request, 4)
                testresult.append([descr, verdict])

                testresult.append(["[.] Datenl�nge �berpr�fen", ""])
                if verdict == 'FAILED':
                    testresult.append(["Pr�fung der Datenl�nge nicht m�glich, da keine positive Response kam", "FAILED"])
                else:
                    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'], 4, ticket_id='Fehler Id:EGA-PRM-31'))

                testresult.append(["[.] Inhalt der Response �berpr�fen", ""])
                if verdict == 'FAILED':
                    testresult.append(
                        ["Pr�fung des Inhaltes nicht m�glich, da keine positive Response kam", "FAILED"])
                else:
                    check_response = response[4:]

                    testresult.append(["[+] Pr�fe Byte 0: 'Result of Calculation'", ""])
                    testresult.append(
                        basic_tests.checkStatus(
                            current_status=check_response[0],
                            nominal_status=calc_result,
                            descr="Pr�fe, dass Calculation Result wie erwartet ist (0x%02X)" % (calc_result)
                        )
                    )

                    testresult.append(["[.] Pr�fe Byte 1: 'Type of Hash'", ""])
                    testresult.append(
                        basic_tests.checkStatus(
                            current_status=check_response[1],
                            nominal_status=hash_type,
                            descr="Pr�fe, dass Hash Type wie erwartet ist (0x%02X)" % (hash_type)
                        )
                    )

                    testresult.append(["[.] Pr�fe Byte 2-32: 'Hashvalue'", ""])
                    if len(check_response) > 2:
                        if len(check_response) == 32:
                            descr, verdict = basic_tests.checkStatus(
                                    current_status=check_response[2:],
                                    nominal_status=hash_value,
                                    descr="Pr�fe, dass Hash Type wie erwartet ist (%s)" % str(HexList(hash_value))
                                )
                        else:
                            descr = "L�nge des Hashwertes ist falsch"
                            verdict = 'FAILED'
                    else:
                        descr = "Es wurde kein Hashwert zur�ckgegeben"
                        verdict = 'FAILED'
                    testresult.append([descr, verdict])
                    testresult.append(["[-0]", ""])

            else:

                testresult.append(["\xa0Auf negative Response �berpr�fen", ""])
                testresult.append(canape_diag.checkNegativeResponse(response, [0x31], 0x7F, ticket_id='Fehler-Id:EGA-PRM-31'))


    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
