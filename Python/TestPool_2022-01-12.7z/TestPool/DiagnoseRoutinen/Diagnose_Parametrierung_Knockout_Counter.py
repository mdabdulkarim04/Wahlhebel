# ******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_Parametrierung_Knockout_Counter.py
# Title   : Diagnose_Parametrierung_Knockout_Counter
# Task    : A minimal "Diagnose Parametrierung Knockout Counter!" test script
#
# Author  : Mohammed Abdul Karim
# Date    : 23.06.2021
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 03.11.2021 | Devangbhai  | initial
# 1.1  | 15.11.2021 | Mohammed  | Rework
# 1.2  | 13.12.2021 | Mohammed   | Added Fehler id
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t

testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    hil = testenv.getHil()
    testresult = testenv.getResults()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Knockout_counter']
    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_161")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # 1. In Default Session auslesen"
    testresult.append(["\xa01. In Default Session auslesen", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\xa01.1 Auslesen der Knockout Counter: 0x2202CA"])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request, ticket_id='Fehler-Id:EGA-PRM-134'))

    testresult.append(["Datenl�nge: 2 Bytes �berpr�fen", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'], ticket_id='Fehler-Id:EGA-PRM-134'))

    testresult.append(["\xa02. Schreiben im Factory Mode"])

    testresult.append(["\x0a2.1 Wechsel in die Default Session: 0x1001", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))

    testresult.append(["\xa02.2 Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\x0a2.3 Wechsel in Factory Mode:  0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa02.4 Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('factory_mode'))

    testresult.append(["\xa02.5 Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(result)

    testresult.append(["\xa02.6 Key berechnen:"])
    key, verdictkey = canape_diag.calculateKey(seed)
    testresult.append(verdictkey)

    testresult.append(["\xa02.7 Key senden: 0x2762 + <berechnet key>:"])
    verdict = canape_diag.sendKey(key)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(verdict)

    testresult.append(["\xa02.8 Schreiben der Knockout Counter: 0x2E02CA + C8C8 (jew. 200dez)"])
    req = [0x2E, 0x02, 0xCA, 0xC8, 0xC8]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 02CA ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, req))

    testresult.append(["\x0a2.9 Auslesen der Knockout Counter: 0x2202CA"])
    req = [0x22, 0x02, 0xCA]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62, 0x02, 0xCA, 0xC8, 0xC8]
    testresult.append(["Pr�fe Positive Response:0x6202CA + C8C8 ist", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\xa03 Anpasswerte wieder auf vorherige Werte setzen"])
    testresult.append(["\xa03.1 Schreiben der Knockout Counter: 0x2E02CA + <counter>"])
    req = [0x2E, 0x02, 0xCA, 0x02, 0x30]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 02CA ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, req))

    testresult.append(["\x0a3.2 Auslesen der Knockout Counter: 0x2202CA"])
    req = [0x22, 0x02, 0xCA]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0 Pr�fe Positive Response: 0x6E 02CA ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, req))

    expected_resp = [0x62, 0x02, 0xCA, 0x00, 0x30]
    testresult.append(canape_diag.checkResponse(response, expected_resp, ticket_id='Fehler-Id:EGA-PRM-135'))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print "Done."
