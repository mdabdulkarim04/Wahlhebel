# ******************************************************************************
# -*- coding: latin1 -*-
# File    : KL15_AUS_Wechsel_In_NonDefaultSession_NM_Signal.py
# Title   : KL15 AUS Wechsel In NonDefaultSession mith NM Signal
# Task    : A minimal "KL15_AUS_Wechsel_In_NonDefaultSession_NM_Signal!" test script
#
# Author  : Mohammed Abdul Karim
# Date    : 15.10.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 15.10.2021 | Mohammed  | initial
# 1.1  | 02.11.2021 | Devang    | Added evaluation method
# 1.2  | 02.11.2021 | Devang    | Added TestStep
# 1.3  | 17.12.2021 | Devang    | Rework according to Test specification
# 1.4  | 21.12.2021 | Mohammed     | Added Fehler Id

# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from ttk_checks import basic_tests
import time
from ttk_daq import eval_signal
from functions_nm import _checkStatus
import copy


# Instantiate test environment
testenv = TestEnv()
hil = testenv.getHil()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_313")

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()

    # Initialize variables ####################################################
    nm_Waehlhebel_Diag = hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value
    meas_vars = [nm_Waehlhebel_Diag]

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["Signal-Aufzeichnung von NM_Waehlhebel_NM_aktiv_Diag ", ""])
    testresult.append(["Start DAQ Measurement", "INFO"])
    daq.startMeasurement(meas_vars)

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a1. Auslesen der Active Diagnostic Session: 0x22F186", "INFO"])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\x0a2. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", "INFO"])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    # testresult.append(["\x0a3. Signal-Aufzeichnung NM_Waehlhebel_NM_aktiv_Diag und NM_Waehlhebel_NM_aktiv_KL15 starten ", ""])
    # testresult.append(["\xa0 Start DAQ Measurement ", ""])
    # daq.startMeasurement(meas_vars)

    testresult.append(["\x0a3. Warte 2 Sekunden", ""])
    time.sleep(2)

    testresult.append(["\x0a4. KL15 ausschalten", ""])
    hil.cl15_on__.set(0)
    time.sleep(0.01)

    testresult.append(["\x0a5. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    testresult.append(["\x0a6. Warte 11 Sekunden", ""])
    time.sleep(11)

    testresult.append(["\x0a7. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", "INFO"])
    testresult.append(
        _checkStatus(current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value, nominal_status=0,
                     descr="Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag__value = 0 (inaktiv) ist",
                     ticket_id='Fehler Id:EGA-PRM-141'))

    testresult.append(["\x0a8. Wechsel in Extended Session: 0x1003 (NonDefaultSession)", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\x0a9. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('extended'))

    testresult.append(["\x0a10. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    testresult.append(["\x0a11. Warte 1,5 min", ""])
    time.sleep(90)

    testresult.append(["\x0a12. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", "INFO"])
    testresult.append(
        _checkStatus(current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value, nominal_status=0,
                     descr="Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag__value = 0 (inaktiv) ist",
                     ticket_id='Fehler Id:EGA-PRM-141'))

    testresult.append(["\x0a13. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\x0a14. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", "INFO"])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    testresult.append(["\x0a Stoppe Signal-Aufzeichnung", ""])
    testresult.append(["Warte 2 Sekunde, bevor DAQ Messung beendet wird", "INFO"])
    time.sleep(2)
    daq_data = daq.stopMeasurement()
    time.sleep(0.5)

    testresult.append(["\nStart Analyse of DAQ Measurement", ""])
    plot_data = {}
    for mes in [nm_Waehlhebel_Diag]:
        plot_data[str(mes)] = daq_data[str(mes)]
    testresult.append(daq.plotMultiShot(plot_data, str(testenv.script_name.split('.py')[0])))


    # testresult.append(["\x0a11. Stoppe Signal-Aufzeichnung", ""])
    # daq_data = daq.stopMeasurement()
    # time.sleep(0.5)
    # testresult.append(["\x0a12. Start Analyse of DAQ Measurement", ""])
    #
    # erzeuge Plot f�r Testreport
    # plot_data = {}
    # for mes in [nm_Waehlhebel_Diag, nm_Waehlhebel_KL15]:
    #     plot_data[str(mes)] = daq_data[str(mes)]
    # testresult.append(
    #     daq.plotMultiShot(plot_data, str(testenv.script_name.split('.py')[0])))
    #
    # def A111():
    #     testresult.append([ "\x0a12.1 Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum: keine Werte au�er 0, 1 angenommen hat", ""])
    #
    # def A112():
    #     testresult.append([ "\x0a12.2 Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum:  genau einmal von 1 auf 0 wechselt und speichere den Zeitstempel des Wechsels als kl15_aus",""])
    #
    # def A113():
    #     testresult.append([ "\x0a12.3 Pr�fe, dass  NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum: keinmal von 0 auf 1 wechselt", ""])
    #
    # def B114():
    #     testresult.append([ "\x0a12.4 Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum: keine Werte au�er 0, 1 angenommen hat", ""])
    #
    # def B115():
    #     testresult.append([ "\x0a12.5 Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum:  genau einmal von 1 auf 0 wechselt und speichere den Zeitstempel des Wechsels als diag_aus",""])
    #
    # def B116():
    #     testresult.append([ "\x0a12.6 Pr�fe, dass  NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum: genau einmal von 0 auf 1 wechselt und speichere den Zeitstempel des Wechsels als diag_ein", ""])
    #
    #
    ######################### 12 evaluation of NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 ############
    # nm_Waehlhebel_KL15_eval = daq_data[str(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_KL15__value)]
    # nm_Waehlhebel_KL15_data = eval_signal.EvalSignal(nm_Waehlhebel_KL15_eval)
    # nm_Waehlhebel_KL15_data.clearAll()
    # time_zero1 = nm_Waehlhebel_KL15_data.getTime()
    # KL15_aus_time = nm_Waehlhebel_KL15_data.find(operator="==", value=0)
    #
    # if KL15_aus_time is not None:
    #     testresult.append(["KL15_aus Zeitpunkt: %ss" % (KL15_aus_time - time_zero1), "INFO"])
    #     kl_aus= KL15_aus_time - time_zero1
    # else:
    #     testresult.append(["KL15_aus Zeitpunkt Nicht erreicht", "INFO"])
    #
    # kl15list = []
    # list_extended= []
    # kl15timelist = nm_Waehlhebel_KL15_eval["time"]
    # kl15datalist = nm_Waehlhebel_KL15_eval["data"]
    # for i in range(len(kl15datalist)):
    #     if len(kl15list) == 0 or  kl15list[-1]  != kl15datalist[i]:
    #         kl15list.append(kl15datalist[i])
    #         list1 = [[kl15datalist[i], kl15timelist[i]- time_zero1]]
    #         list_extended.extend(list1)
    #
    # if len(list_extended) == 2 and len(kl15list) ==2:
    #     i, j = 0, 1
    #     res = True
    #     A111()
    #     for ele in kl15list:
    #         if ele < i or ele > j:
    #             res = False
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat", "FAILED"])
    #     if res:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
    #
    #     if kl15list[0] == 1 and kl15list[1] == 0:
    #         A112()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])
    #     A113()
    #     if kl15list[-1] == 0 and kl15list[-2] == 1:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ","PASSED"])
    #     else:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum mal von 0 auf 1 wechselt ","FAILED"])
    #
    # elif len(kl15list) >= 3:
    #     i, j = 0, 1
    #     res = True
    #     A111()
    #     for ele in kl15list:
    #         if ele < i or ele > j:
    #             res = False
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat", "FAILED"])
    #     if res:
    #         testresult.append([ "NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat", "PASSED"])
    #     A112()
    #     testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum mehrmal von 0 auf 1 wechselt ", "FAILED"])
    #     A113()
    #
    # elif len(kl15list)<= 1:
    #     A111()
    #     testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 kann nicht messen in gemessenen Zeitraum", "FAILED"])
    #     A112()
    #     testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 kann nicht messen in gemessenen Zeitraum", "FAILED"])
    #     A113()
    #     testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 kann nicht messen in gemessenen Zeitraum", "FAILED"])
    #
    #########################  13 evaluation of NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag ############
    # NM_Waehlhebel_NM_aktiv_Diag_eval = daq_data[str(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value)]
    # NM_Waehlhebel_NM_aktiv_Diag = eval_signal.EvalSignal(NM_Waehlhebel_NM_aktiv_Diag_eval)
    # NM_Waehlhebel_NM_aktiv_Diag.clearAll()
    # time_zero2 = NM_Waehlhebel_NM_aktiv_Diag.getTime()
    # NM_aktiv_Diag_aus_time = NM_Waehlhebel_NM_aktiv_Diag.find(operator="==", value=0)
    # testresult.append(["NM_aktiv_Diag Zeitpunkt: %ss" % (NM_aktiv_Diag_aus_time - time_zero2), "INFO"])
    #
    # if NM_aktiv_Diag_aus_time is not None:
    #     testresult.append(["Diagnose_aus Zeitpunkt: %ss" % (NM_aktiv_Diag_aus_time - time_zero2), "INFO"])
    #     Diagnose_aus = NM_aktiv_Diag_aus_time - time_zero2
    # else:
    #     testresult.append(["Diagnose_aus Zeitpunkt Nicht erreicht", "INFO"])
    #
    # NM_aktiv_Diag_ein_time = NM_Waehlhebel_NM_aktiv_Diag.findNext(operator="==", value=1)
    # if NM_aktiv_Diag_ein_time is not None:
    #     testresult.append(["Diagnose_ein Zeitpunkt: %ss" % (NM_aktiv_Diag_ein_time - time_zero2), "INFO"])
    #     Diagnose_ein = NM_aktiv_Diag_ein_time - time_zero2
    # else:
    #     testresult.append(["Diagnose_ein Zeitpunkt Nicht erreicht", "INFO"])
    #
    # Diagnose_list = []
    # diag_list_extended = []
    # Diagnosetimelist = NM_Waehlhebel_NM_aktiv_Diag_eval["time"]
    # Diagnosedatalist = NM_Waehlhebel_NM_aktiv_Diag_eval["data"]
    # for i in range(len(Diagnosedatalist)):
    #     if len(Diagnose_list) == 0 or Diagnose_list[-1] != Diagnosedatalist[i]:
    #         Diagnose_list.append(Diagnosedatalist[i])
    #         list2 = [[Diagnosedatalist[i], Diagnosetimelist[i] - time_zero2]]
    #         diag_list_extended.extend(list2)
#
######################################################
    # if len(diag_list_extended) == 3 and len(Diagnose_list) == 3:
    #     i, j = 0, 1
    #     res = True
    #     for ele in Diagnose_list:
    #         if ele < i or ele > j:
    #             res = False
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat", "FAILED"])
    #     if res:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
    #
    #     if Diagnose_list[0] == 1 and Diagnose_list[1] == 0:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])
    #
    #     elif Diagnose_list[0] == 0 and Diagnose_list[1] == 1:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ","FAILED"])
    #
    #     if Diagnose_list[1] == 0 and Diagnose_list[2] == 1:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 0 auf 1 wechselt ","PASSED"])
    #
    #     elif Diagnose_list[1] == 1 and Diagnose_list[2] == 0:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Zwitemal von 1 auf 0 wechselt ","FAILED"])
    #
    # elif len(diag_list_extended) >= 4 and len(Diagnose_list) >= 4:
    #     i, j = 0, 1
    #     res = True
    #     for ele in Diagnose_list:
    #         if ele < i or ele > j:
    #             res = False
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat", "FAILED"])
    #     if res:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
    #
    #     testresult.append( ["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum mehrmal von 0 auf 1 order von 1 uf 0 wechselt ", "FAILED"])
    #
    # elif len(diag_list_extended) <= 2 and len(Diagnose_list) <= 2:
    #     if len(diag_list_extended) == 2 and len(Diagnose_list) == 2:
    #         i, j = 0, 1
    #         res = True
    #         for ele in Diagnose_list:
    #             if ele < i or ele > j:
    #                 res = False
    #                 testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
    #         if res:
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat", "PASSED"])
    #
    #         if Diagnose_list[0] == 1 and Diagnose_list[1] == 0:
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ", "PASSED"])
    #
    #         elif Diagnose_list[0] == 0 and Diagnose_list[1] == 1:
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ", "FAILED"])
    #
    #         testresult.append( ["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ", "FAILED"])
    #
    #     elif len(diag_list_extended) == 1 and len(Diagnose_list) == 1:
    #         testresult.append( ["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte nicht �berpr�fen", "FAILED"])
    #         testresult.append( ["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 1 auf 0 wechselt ", "FAILED"])
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ", "FAILED"])
    # if len(diag_list_extended) == 3 and len(Diagnose_list) == 3:
    #     i, j = 0, 1
    #     res = True
    #     B114()
    #     for ele in Diagnose_list:
    #         if ele < i or ele > j:
    #             res = False
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
    #     if res:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat", "PASSED"])
    #
    #     if Diagnose_list[0] == 1 and Diagnose_list[1] == 0:
    #         B115()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])
    #
    #     elif Diagnose_list[0] == 0 and Diagnose_list[1] == 1:
    #         B115()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ","FAILED"])
    #
    #     B116()
    #     if Diagnose_list[1] == 0 and Diagnose_list[2] == 1:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 0 auf 1 wechselt ","PASSED"])
    #
    #     elif Diagnose_list[1] == 1 and Diagnose_list[2] == 0:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Zwitemal von 1 auf 0 wechselt ","FAILED"])
    #
    # elif len(diag_list_extended) >= 4 and len(Diagnose_list) >= 4:
    #     i, j = 0, 1
    #     res = True
    #     B114()
    #     for ele in Diagnose_list:
    #         if ele < i or ele > j:
    #             res = False
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
    #     if res:
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
    #     B115()
    #     testresult.append(["[.] Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum:  genau einmal von 1 auf 0 wechselt und speichere den Zeitstempel des Wechsels als diag_aus", ""])
    #     B116()
    #     testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum mehrmal von 0 auf 1 order von 1 uf 0 wechselt ","FAILED"])
    #
    # elif len(diag_list_extended) <= 2 and len(Diagnose_list) <= 2:
    #     if len(diag_list_extended) == 2 and len(Diagnose_list) == 2:
    #         i, j = 0, 1
    #         res = True
    #         B114()
    #         for ele in Diagnose_list:
    #             if ele < i or ele > j:
    #                 res = False
    #                 testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
    #         if res:
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
    #
    #         if Diagnose_list[0] == 1 and Diagnose_list[1] == 0:
    #             B115()
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])
    #
    #         elif Diagnose_list[0] == 0 and Diagnose_list[1] == 1:
    #             B115()
    #             testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ", "FAILED"])
    #         B116()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ","FAILED"])
    #
    #     elif len(diag_list_extended) == 1 and len(Diagnose_list) == 1:
    #         B114()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte nicht �berpr�fen", "FAILED"])
    #         B115()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 1 auf 0 wechselt ","FAILED"])
    #         B116()
    #         testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ", "FAILED"])
    #
    # if NM_aktiv_Diag_aus_time is not None:
    #     testresult.append( ["\x0a12.7 Pr�fe, dass zwischen Ausschalten der KL15 und Diagnose-Deaktivierung 10 s vergehen", "INFO"])
    #     testresult.append(basic_tests.compareCE(current_status=Diagnose_aus-KL15_aus_time,operator="==", expected_value=10, abs_tol=1 ,descr="Pr�fe, dass (diag_aus - kl15_aus) == 10s", ))
    # else:
    #     testresult.append( ["\x0a12.7 Pr�fe, dass zwischen Ausschalten der KL15 und Diagnose-Deaktivierung 10 s vergehen", "INFO"])
    #     testresult.append( ["Pr�fe, dass (diag_aus - kl15_aus) == 10s", "FAILED"])
    #
    # if NM_aktiv_Diag_ein_time is not None:
    #     testresult.append( ["\x0a12.8 Pr�fe, dass beim Wechsel in die Extended Session (NonDefaultSession) Diagnose aktiviert wird (indirekt da Sessionwechsel nicht messbar)", "INFO"])
    #     testresult.append(basic_tests.compareCE(current_status=Diagnose_ein,operator=">=", expected_value= kl_aus + 11, abs_tol=0.1,  descr="Pr�fe, dass diag_ein >= (kl15_aus + 11s)", ))
    # else:
    #     testresult.append(["\x0a12.8 Pr�fe, dass beim Wechsel in die Extended Session (NonDefaultSession) Diagnose aktiviert wird (indirekt da Sessionwechsel nicht messbar)","INFO"])
    #     testresult.append(["Pr�fe, dass Pr�fe, dass diag_ein >= (kl15_aus + 11s)", "FAILED"])
    #
    # testresult.append(["[.] Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", "INFO"])
    # testresult.append(
    #     basic_tests.checkStatus(
    #         current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
    #         nominal_status=1,
    #         descr="Pr�fe, dass Wert 1 ist",
    #     )
    # )

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[#0] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    ########################################################################
    testenv.breakdown()
    del (testenv)
    #########################################################################

print "Done."
