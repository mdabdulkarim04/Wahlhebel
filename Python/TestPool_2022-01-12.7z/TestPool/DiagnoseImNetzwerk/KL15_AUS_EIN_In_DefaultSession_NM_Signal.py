# ******************************************************************************
# -*- coding: latin1 -*-
# File    : KL15_AUS_EIN_In_DefaultSession_NM_Signal.py
# Title   KL15 AUS EIN In DefaultSession NM Signal
# Task    : A minimal "KL15_AUS_EIN_In_DefaultSession_NM_Signal!" test script
#
# Author  : Mohammed Abdul Karim
# Date    : 14.10.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 14.10.2021 | Mohammed  | initial
# 1.1  | 04.11.2021 | Devang    | Added evaluation method
# 1.2  | 17.12.2021 | Mohammed  | Rework according to Test specification

# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from ttk_checks import basic_tests
import time
from ttk_daq import eval_signal

# Instantiate test environment
testenv = TestEnv()
hil = testenv.getHil()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_315")

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()

    # Initialize variables ####################################################
    nm_Waehlhebel_Diag = hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value
    meas_vars = [nm_Waehlhebel_Diag]

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["Signal-Aufzeichnung von NM_Waehlhebel_NM_aktiv_Diag ", ""])
    testresult.append(["Start DAQ Measurement", "INFO"])
    daq.startMeasurement(meas_vars)

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a 1. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2
    testresult.append(["\x0a 2. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    #3
    testresult.append(["\x0a3. Warte 2 Sekunde", ""])
    time.sleep(2.0)

    #4
    testresult.append(["\x0a4. 4 KL15 ausschalten ", ""])
    hil.cl15_on__.set(0)

    # 5
    testresult.append(["\x0a5. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", " "])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    ## 6
    testresult.append(["\x0a6. Warte 11 Sekund", ""])
    time.sleep(11)

    #7
    testresult.append(["\x0a7. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=0,
            descr="Pr�fe, dass Wert 0 ist",
        )
    )

    # 8
    testresult.append(["\x0a8. KL15 einschalten ", ""])
    hil.cl15_on__.set(1)

    # 9
    testresult.append(["[.] Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=0,
            descr="Pr�fe, dass Wert 0 ist",
        )
    )

    ####
    testresult.append(["\x0a Stoppe Signal-Aufzeichnung", ""])
    testresult.append(["Warte 2 Sekunde, bevor DAQ Messung beendet wird", "INFO"])
    time.sleep(2)
    daq_data = daq.stopMeasurement()
    time.sleep(0.5)

    testresult.append(["\nStart Analyse of DAQ Measurement", ""])
    plot_data = {}
    for mes in [nm_Waehlhebel_Diag]:
        plot_data[str(mes)] = daq_data[str(mes)]
    testresult.append(daq.plotMultiShot(plot_data, str(testenv.script_name.split('.py')[0])))

    #11
    '''
    # erzeuge Plot f�r Testreport
    plot_data = {}
    for mes in [nm_Waehlhebel_Diag]:
        plot_data[str(mes)] = daq_data[str(mes)]
        kl15_data = daq_data[str(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_KL15__value)]
        analyse_kl15_data = eval_signal.EvalSignal(kl15_data)
        analyse_kl15_data.clearAll()
        time_zero = analyse_kl15_data.getTime()
        cl15_off_time = analyse_kl15_data.find(operator="==", value=1)
        testresult.append(["NM_aktiv_Diag aus Zeitpunkt: %ss" % (cl15_off_time - time_zero), "INFO"])

        testresult.append([" Pr�fe NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum", "INFO"])
        testresult.append(
            daq.plotMultiShot(plot_data, "KL15_AUS_EIN_In_DefaultSession_NM_Signal",
                              v_lines={1: {'x': cl15_off_time - time_zero, 'label': 'NM_aktiv_Diag off'}})
        )

    
   
    plot_data = {}
    for mes in [nm_Waehlhebel_Diag, nm_Waehlhebel_KL15]:
        plot_data[str(mes)] = daq_data[str(mes)]
    testresult.append(
        daq.plotMultiShot(plot_data, str(testenv.script_name.split('.py')[0])))

    def A111():
        testresult.append([ "[+] Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum: keine Werte au�er 0, 1 angenommen hat", ""])

    def A112():
        testresult.append([ "[.] Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum:  genau einmal von 1 auf 0 wechselt und speichere den Zeitstempel des Wechsels als diag_aus",""])

    def A113():
        testresult.append([ "[.] Pr�fe, dass  NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum: genau einmal von 0 auf 1 wechselt und speichere den Zeitstempel des Wechsels als diag_ein", ""])

    def B114():
        testresult.append([ "[.] Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum: keine Werte au�er 0, 1 angenommen hat", ""])

    def B115():
        testresult.append([ "[.] Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum:  genau einmal von 1 auf 0 wechselt und speichere den Zeitstempel des Wechsels als diag_aus",""])

    def B116():
        testresult.append([ "[.] Pr�fe, dass  NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum: genau einmal von 0 auf 1 wechselt und speichere den Zeitstempel des Wechsels als diag_ein", ""])


    ########################## 11.1-11.3 evaluation of NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 ############
    nm_Waehlhebel_KL15_eval = daq_data[str(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_KL15__value)]
    nm_Waehlhebel_KL15_data = eval_signal.EvalSignal(nm_Waehlhebel_KL15_eval)
    nm_Waehlhebel_KL15_data.clearAll()
    time_zero1 = nm_Waehlhebel_KL15_data.getTime()
    KL15_aus_time = nm_Waehlhebel_KL15_data.find(operator="==", value=0)

    kl_aus= None
    if KL15_aus_time is not None:
        testresult.append(["KL15_aus Zeitpunkt: %ss" % (KL15_aus_time - time_zero1), "INFO"])
        kl_aus = KL15_aus_time - time_zero1
    else:
        testresult.append(["KL15_aus Zeitpunkt Nicht erreicht", "INFO"])
    KL15_ein = None
    KL15_ein_time = nm_Waehlhebel_KL15_data.findNext(operator="==", value=1)
    if KL15_ein_time is not None:
        testresult.append(["KL15_ein Zeitpunkt: %ss" % (KL15_ein_time - time_zero1), "INFO"])
        KL15_ein = KL15_ein_time - time_zero1
    else:
        testresult.append(["KL15_ein Zeitpunkt Nicht erreicht", "INFO"])


    kl15list = []
    list_extended = []
    kl15timelist = nm_Waehlhebel_KL15_eval["time"]
    kl15datalist = nm_Waehlhebel_KL15_eval["data"]
    for i in range(len(kl15datalist)):
        if len(kl15list) == 0 or kl15list[-1] != kl15datalist[i]:
            kl15list.append(kl15datalist[i])
            list1 = [[kl15datalist[i], kl15timelist[i] - time_zero1]]
            list_extended.extend(list1)

    if len(list_extended) == 3 and len(kl15list) == 3:
        i, j = 0, 1
        res = True
        A111()
        for ele in kl15list:
            if ele < i or ele > j:
                res = False
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
        if res:
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])

        if kl15list[0] == 1 and kl15list[1] == 0:
            A112()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])

        elif kl15list[0] == 0 and kl15list[1] == 1:
            A112()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ","FAILED"])

        if kl15list[1] == 0 and kl15list[2] == 1:
            A113()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum genau einmal von 0 auf 1 wechselt ","PASSED"])

        elif kl15list[1] == 1 and kl15list[2] == 0:
            A113()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Zwitemal von 1 auf 0 wechselt ","FAILED"])

    elif len(list_extended) >= 4 and len(kl15list) >= 4:
        i, j = 0, 1
        res = True
        A111()
        for ele in kl15list:
            if ele < i or ele > j:
                res = False
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
        if res:
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
        A112()
        A113()
        testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum mehrmal von 0 auf 1 order von 1 uf 0 wechselt ","FAILED"])

    elif len(list_extended) <= 2 and len(kl15list) <= 2:
        if len(list_extended) == 2 and len(kl15list) == 2:
            i, j = 0, 1
            res = True
            A111()
            for ele in kl15list:
                if ele < i or ele > j:
                    res = False
                    testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
            if res:
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])

            if kl15list[0] == 1 and kl15list[1] == 0:
                A112()
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])

            elif kl15list[0] == 0 and kl15list[1] == 1:
                A112()
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ","FAILED"])
            A113()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ","FAILED"])

        elif len(list_extended) == 1 and len(kl15list) == 1:
            A111()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum Werte nicht �berpr�fen", "FAILED"])
            A112()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keinmal von 1 auf 0 wechselt ","FAILED"])
            A113()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ","FAILED"])

    ##########################  11.4-11.8 evaluation of NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag ############
    NM_Waehlhebel_NM_aktiv_Diag_eval = daq_data[str(hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value)]
    NM_Waehlhebel_NM_aktiv_Diag = eval_signal.EvalSignal(NM_Waehlhebel_NM_aktiv_Diag_eval)
    NM_Waehlhebel_NM_aktiv_Diag.clearAll()
    time_zero2 = NM_Waehlhebel_NM_aktiv_Diag.getTime()
    NM_aktiv_Diag_aus_time = NM_Waehlhebel_NM_aktiv_Diag.find(operator="==", value=0)
    # testresult.append(["NM_aktiv_Diag Zeitpunkt: %ss" % (NM_aktiv_Diag_aus_time - time_zero2), "INFO"])

    Diagnose_aus = None
    if NM_aktiv_Diag_aus_time is not None:
        testresult.append(["Diagnose_aus Zeitpunkt: %ss" % (NM_aktiv_Diag_aus_time - time_zero2), "INFO"])
        Diagnose_aus = NM_aktiv_Diag_aus_time - time_zero2
    else:
        testresult.append(["Diagnose_aus Zeitpunkt Nicht erreicht", "INFO"])

    NM_aktiv_Diag_ein_time = NM_Waehlhebel_NM_aktiv_Diag.findNext(operator="==", value=1)
    Diagnose_ein = None
    if NM_aktiv_Diag_ein_time is not None:
        testresult.append(["Diagnose_ein Zeitpunkt: %ss" % (NM_aktiv_Diag_ein_time - time_zero2), "INFO"])
        Diagnose_ein = NM_aktiv_Diag_ein_time - time_zero2
    else:
        testresult.append(["Diagnose_ein Zeitpunkt Nicht erreicht", "INFO"])

    Diagnose_list = []
    diag_list_extended = []
    Diagnosetimelist = NM_Waehlhebel_NM_aktiv_Diag_eval["time"]
    Diagnosedatalist = NM_Waehlhebel_NM_aktiv_Diag_eval["data"]
    for i in range(len(Diagnosedatalist)):
        if len(Diagnose_list) == 0 or Diagnose_list[-1] != Diagnosedatalist[i]:
            Diagnose_list.append(Diagnosedatalist[i])
            list2 = [[Diagnosedatalist[i], Diagnosetimelist[i] - time_zero2]]
            diag_list_extended.extend(list2)


    if len(diag_list_extended) == 3 and len(Diagnose_list) == 3:
        i, j = 0, 1
        res = True
        B114()
        for ele in Diagnose_list:
            if ele < i or ele > j:
                res = False
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
        if res:
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat", "PASSED"])

        if Diagnose_list[0] == 1 and Diagnose_list[1] == 0:
            B115()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])

        elif Diagnose_list[0] == 0 and Diagnose_list[1] == 1:
            B115()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ","FAILED"])

        B116()
        if Diagnose_list[1] == 0 and Diagnose_list[2] == 1:
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 0 auf 1 wechselt ","PASSED"])

        elif Diagnose_list[1] == 1 and Diagnose_list[2] == 0:
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Zwitemal von 1 auf 0 wechselt ","FAILED"])

    elif len(diag_list_extended) >= 4 and len(Diagnose_list) >= 4:
        i, j = 0, 1
        res = True
        B114()
        for ele in Diagnose_list:
            if ele < i or ele > j:
                res = False
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
        if res:
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])
        B115()
        testresult.append(["[.] Pr�fe, dass NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum:  genau einmal von 1 auf 0 wechselt und speichere den Zeitstempel des Wechsels als diag_aus", ""])
        B116()
        testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_KL15 im gemessenen Zeitraum mehrmal von 0 auf 1 order von 1 uf 0 wechselt ","FAILED"])

    elif len(diag_list_extended) <= 2 and len(Diagnose_list) <= 2:
        if len(diag_list_extended) == 2 and len(Diagnose_list) == 2:
            i, j = 0, 1
            res = True
            B114()
            for ele in Diagnose_list:
                if ele < i or ele > j:
                    res = False
                    testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte au�er 0 und  1 angenommen hat","FAILED"])
            if res:
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keine Werte au�er 0, 1 angenommen hat","PASSED"])

            if Diagnose_list[0] == 1 and Diagnose_list[1] == 0:
                B115()
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum genau einmal von 1 auf 0 wechselt ","PASSED"])

            elif Diagnose_list[0] == 0 and Diagnose_list[1] == 1:
                B115()
                testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum erstemal von 0 auf 1 wechselt ", "FAILED"])
            B116()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ","FAILED"])

        elif len(diag_list_extended) == 1 and len(Diagnose_list) == 1:
            B114()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum Werte nicht �berpr�fen", "FAILED"])
            B115()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 1 auf 0 wechselt ","FAILED"])
            B116()
            testresult.append(["NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag im gemessenen Zeitraum keinmal von 0 auf 1 wechselt ", "FAILED"])

    if NM_aktiv_Diag_aus_time and KL15_aus_time is not None:
        testresult.append(["[.] Pr�fe, dass zwischen Ausschalten der KL15 und Diagnose-Deaktivierung 10 s vergehen", ""])
        testresult.append(basic_tests.compareCE(current_value=Diagnose_aus - kl_aus, operator="==", expected_value=10,abs_tol=1, descr="Pr�fe, dass (diag_aus - kl15_aus) == 10s", ))
    else:
        testresult.append(["[.] Pr�fe, dass zwischen Ausschalten der KL15 und Diagnose-Deaktivierung 10 s vergehen", ""])
        testresult.append(["Pr�fe, dass (diag_aus - kl15_aus) == 10s", "FAILED"])

    if NM_aktiv_Diag_ein_time and KL15_ein_time is not None:
        testresult.append(["[.] Pr�fe, dass bei Einschalten der KL15 Diagnose aktiviert wird", ""])
        testresult.append(basic_tests.compareCE(current_value=(Diagnose_ein - KL15_ein), operator="==", expected_value= 0, abs_tol=0.1, descr="(diag_ein - kl15_ein) == 0s", ))
    else:
        testresult.append(["[.] Pr�fe, dass bei Einschalten der KL15 Diagnose aktiviert wird", ""])
        testresult.append(["Pr�fe, dass (diag_ein - kl15_ein) == 0s", "FAILED"])
'''

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[#0] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print "Done."
