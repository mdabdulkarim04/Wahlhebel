# ******************************************************************************
# -*- coding: latin1 -*-
# File    : KL15_AUS_S3_Timeout.py
# Title   : KL15 AUS S3_Timeout
# Task    : A minimal "KL15_AUS_S3_Timeout!" test script
#
# Author  : Mohammed Abdul Karim
# Date    : 17.12.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 14.10.2021 | Mohammed  | initial
# 1.2  | 21.12.2021 | Mohammed     | Added Fehler Id

# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from ttk_checks import basic_tests
import time
from ttk_daq import eval_signal
from data_common import s3_timeout
from functions_nm import _checkStatus

# Instantiate test environment
testenv = TestEnv()
hil = testenv.getHil()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_339")

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()

    # Initialize variables ####################################################
    nm_Waehlhebel_Diag = hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value

    meas_vars = [nm_Waehlhebel_Diag]

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a1. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2
    testresult.append(["\x0a2. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )
    ## 3
    testresult.append(["\x0a3. Signal-Aufzeichnung von NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(["\xa0 Start DAQ Measurement", ""])
    daq.startMeasurement(meas_vars)

    ## 4
    testresult.append(["\x0a4. KL15 ausschalten", ""])
    hil.cl15_on__.set(0)

    # 5. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag
    testresult.append(["\x0a2. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    ## 6. Warte 11 s
    testresult.append(["\x0a6. Warte 11 s", ""])
    time.sleep(11)

    #7
    testresult.append([" \x0a7. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(["\x0a14. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        _checkStatus(current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value, nominal_status=0,
                     descr="Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag__value = 0 (inaktiv) ist",
                     ticket_id='Fehler Id:EGA-PRM-143'))

    # 8. Wechsel in die Extended Session: 0x1003
    testresult.append(["\xa08. Wechsel in Extended Session: 0x1003", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # 9. warte 5 s (S3-Timeout)
    testresult.append(["\xa09. warte 5 s (S3-Timeout)", ""])
    time.sleep(s3_timeout)

    testresult.append([" \x0a10. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    # 11. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa011. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append([" \x0a12. Pr�fe NM_Waehlhebel:NM_Waehlhebel_NM_aktiv_Diag", ""])
    testresult.append(
        basic_tests.checkStatus(
            current_status=hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Diag__value,
            nominal_status=1,
            descr="Pr�fe, dass Wert 1 ist",
        )
    )

    testresult.append(["\x0a Stoppe Signal-Aufzeichnung", ""])
    testresult.append(["\x0a Warte 2 Sekunde, bevor DAQ Messung beendet wird", ""])
    time.sleep(2)
    daq_data = daq.stopMeasurement()
    time.sleep(0.5)
    testresult.append(["\nStart Analyse of DAQ Measurement", ""])
    plot_data = {}
    for mes in [nm_Waehlhebel_Diag]:
        plot_data[str(mes)] = daq_data[str(mes)]
    testresult.append(daq.plotMultiShot(plot_data, str(testenv.script_name.split('.py')[0])))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print "Done."
