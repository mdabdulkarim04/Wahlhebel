# ******************************************************************************
# -*- coding: latin1 -*-
# File    : FDS_Security_Access_Sperrzeit.py
# Title   : FDS Security Access Sperrzeit
# Task    : FDS Security Access Sperrzeit
#
# Author  : Mohammed Abdul Karim
# Date    : 31.05.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 27.10.2021 | Mohammed     | initial
# 1.1  | 27.10.2021 | Mohammed     | Rework
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
import time
from functions_diag import HexList  # @UnresolvedImport
from ttk_checks import basic_tests

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_308")

    # Initialize variables ####################################################
    ''' 
request_dict = {
        1: {
            'identifier': [0x3E, 0x00],
            'name': 'TesterPresent',
            'expected_response': [0x7E, 0x00],
            'exp_data_length': 3,  # Bytes
        },
        2: {
            'identifier': [0x10, 0x03],
            'name': 'extended',
            'expected_response': [0x50, 0x03, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3
        },
    }
'''

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])
    testresult.append(["[+0]", ""])
    '''
    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a1. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2. Wechsel in Extended Session: 0x1003
    testresult.append(["\xa02. Wechsel in Extended Session: 0x1003", "Info"])
    for test in request_dict:
        test_data = request_dict[test]
        if test_data['name'] == 'extended':
            request = test_data['identifier']
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)
            testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
            testresult.append(canape_diag.checkPositiveResponse(response, request, job_length=2))

'''
    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a1. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2. Wechsel in Extended Session: 0x1003
    testresult.append(["\x0a2. Wechsel in Extended Session: 0x1003", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\x0a4. Tester Present aktivieren: 3E 00", ""])
    req_TesterPresent = [0x3E, 0x00]
    [response, result] = canape_diag.sendDiagRequest(req_TesterPresent)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 7E 00 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, req_TesterPresent, job_length=2))

    testresult.append(["\x0a5. Wechsel in EGA Mode: 0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    '''
    # 4. Tester present aktivieren
    testresult.append(["\xa0\xa04. Tester Present aktivieren: 3E 00", ""])
    for test in request_dict:
        test_data = request_dict[test]
        if test_data['name'] == 'TesterPresent':
            request = test_data['identifier']
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)
            testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
            testresult.append(canape_diag.checkPositiveResponse(response, request, job_length=2))

'''
    testresult.append(["\xa07. Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Pr�fe Positive Response: 0x6711 + <seed 1> ist", ""])
    testresult.extend(result)

    wrong_key = [0x10, 0xA3, 0x1B, 0x03]
    testresult.append(["\x0aKey berechnen", ""])
    key_calculated, ver = canape_diag.calculateKey(seed)
    testresult.extend(ver)

    if key_calculated!= wrong_key:
        testresult.append(["\xa08. falschen Key senden: 0x2762 + <wrong key 1> "])
        verdict, res4 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x35, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res4)
    else:
        testresult.append(["\xa08. falschen Key senden: 0x2762 + <wrong key 1>"])
        verdict, res4 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x35, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res4)

    testresult.append(["\xa09. Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Pr�fe Positive Response: 0x6711 + <seed 2> ist", ""])
    testresult.extend(result)

    wrong_key = [0x10, 0xA3, 0x1B, 0x04]
    testresult.append(["\x0aKey berechnen", ""])
    key_calculated, ver = canape_diag.calculateKey(seed)
    testresult.extend(ver)

    if key_calculated != wrong_key:
        testresult.append(["\xa010. falschen Key senden: 0x2762 + <wrong key 2> "])
        verdict, res5 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x36, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2736", ""])
        testresult.append(res5)
    else:
        testresult.append(["\xa010. falschen Key senden: 0x2762 + <wrong key 2>"])
        verdict, res5 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x36, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2736", ""])
        testresult.append(res5)

    testresult.append(["\xa011. Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Pr�fe Positive Response: 0x6711 + <seed 3> ist", ""])
    testresult.extend(result)

    wrong_key = [0x10, 0xA3, 0x1B, 0x05]
    testresult.append(["\x0aKey berechnen", ""])
    key_calculated, ver = canape_diag.calculateKey(seed)
    testresult.extend(ver)

    if key_calculated != wrong_key:
        testresult.append(["\xa012. falschen Key senden: 0x2762 + <wrong key 3> "])
        verdict, res6 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x24, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2724", ""])
        testresult.append(res6)
    else:
        testresult.append(["\xa012. falschen Key senden: 0x2762 + <wrong key 3>"])
        verdict, res6 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x37, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2724", ""])
        testresult.append(res6)

    testresult.append(["\xa0Zugriffsversuch w�hrend Sperrzeit:"])
    testresult.append(["\xa013. Warte 5 Minute"])
    time.sleep(300)

    testresult.append(["\xa014. Seed anfragen: 0x2761", ""])
    seed, result = canape_diag.requestSeed(pos_response=False, exp_nrc=0x7F, special=False)
    testresult.append(["Pr�fe Negative Response: 0x7F277F", ""])
    testresult.extend(result)

    testresult.append(["\xa0Zugriffsversuch w�hrend Sperrzeit:"])
    testresult.append(["\xa015. Warte 5 Minute"])
    time.sleep(300)

    testresult.append(["\x0a16 Wechsel in Factory Mode:  0x1060", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa0 17. Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(result)

    testresult.append(["\xa0 18 Key berechnen:<key 4>"])
    key, verdictkey = canape_diag.calculateKey(seed)
    testresult.append(verdictkey)

    testresult.append(["\xa0 19. Key senden: 0x2712 + <key 4>"])
    verdict = canape_diag.sendKey(key)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(verdict)

    testresult.append(["\xa0Pr�fen, ob KeyCounter auf 0 zur�ckgesetzt wurde:", ""])
    testresult.append(["\xa020. Seed anfragen: 0x2761", ""])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Pr�fe Positive Response: 0x6711 + <seed 4> ist", ""])
    testresult.extend(result)

    wrong_key = [0x10, 0xA3, 0x1B, 0x16]
    testresult.append(["\x0aKey berechnen", ""])
    key_calculated, ver = canape_diag.calculateKey(seed)
    testresult.extend(ver)

    if key_calculated != wrong_key:
        testresult.append(["\xa021. falschen Key senden: 0x2762 + <wrong key 5> "])
        verdict, res7 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x24, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res7)
    else:
        testresult.append(["\xa021. falschen Key senden: 0x2762 + <wrong key 5>"])
        verdict, res7 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x35, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res7)

    testresult.append(["\xa022. Seed anfragen: 0x2761", ""])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Pr�fe Positive Response: 0x6711 + <seed 6> ist", ""])
    testresult.extend(result)

    wrong_key = [0x10, 0xA3, 0x1B, 0x26]
    testresult.append(["\x0aKey berechnen", ""])
    key_calculated, ver = canape_diag.calculateKey(seed)
    testresult.extend(ver)

    if key_calculated != wrong_key:
        testresult.append(["\xa023. falschen Key senden: 0x2762 + <wrong key 6> "])
        verdict, res8 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x24, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res8)
    else:
        testresult.append(["\xa023. falschen Key senden: 0x2762 + <wrong key 6>"])
        verdict, res8 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x36, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res8)

    testresult.append(["\xa024. Seed anfragen: 0x2761", ""])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Pr�fe Positive Response: 0x6711 + <seed 7> ist", ""])
    testresult.extend(result)

    wrong_key = [0x10, 0xA3, 0x1B, 0x07]
    testresult.append(["\x0aKey berechnen", ""])
    key_calculated, ver = canape_diag.calculateKey(seed)
    testresult.extend(ver)

    if key_calculated != wrong_key:
        testresult.append(["\xa025. falschen Key senden: 0x2762 + <wrong key 7> "])
        verdict, res9 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x24, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res9)
    else:
        testresult.append(["\xa025. falschen Key senden: 0x2762 + <wrong key 7>"])
        verdict, res9 = canape_diag.sendKey(wrong_key, pos_response=False, exp_nrc=0x37, special=False)
        testresult.append(["\x0aPr�fe Negative Response: 0x7F2735", ""])
        testresult.append(res9)

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print ("Done.")
