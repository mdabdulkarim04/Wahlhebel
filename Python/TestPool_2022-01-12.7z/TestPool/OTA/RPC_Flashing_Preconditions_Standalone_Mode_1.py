# ******************************************************************************
# -*- coding: latin-1 -*-
# File    : RPC_Flashing_Preconditions_Standalone_Mode_1.py
# Task    : RPC_Flashing_Preconditions_Standalone_Mode_1
#
# Author  : Mohammed Abdul Karim
# Date    : 24.11.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name      | Description
# ------------------------------------------------------------------------------
# 1.0  | 20.11.2021 | Mohammed  | initial
# ******************************************************************************


from vflash_api_common import FLASH_TIMEOUT
from vflash_api_common import VFlashStatus
from vflash_api_common import VFlashResult
from vflash_api_common import VFlashError
from vflash_api_common import VFlashResultError
from vflash_api_common import VFlashDLLError
import _vflash_api

import os
import time
from xml.dom.minidom import parse
from ttk_tools.vector.vflash_api import VFlashAPI
from _automation_wrapper_ import TestEnv
from ttk_daq import eval_signal
from ttk_checks import basic_tests
import functions_nm
import functions_gearselection
from functions_nm import _checkStatus

from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import time


# Instantiate test environment
testenv = TestEnv()
odx_file_path    = r'C:\Users\DEENLAB01\Desktop\SW0063\FL_95C713041_0063_H02WAEHLHEBEL_V001_E.pdx'
flash_file_path = r"C:\Users\DEENLAB01\Desktop\SW0063\OTA\MP_EGA_PM_SCHALTBETAETIGUNG.vflash"
vflash_dll_path  = r'C:\Program Files (x86)\Vector vFlash 7\Bin\VFlashAutomation.dll'

test_dict = {
    1: identifier_dict['Status_ECU_Standalone-Mode'],
    2: identifier_dict['ECU_standalone_mode_1'],
    3: identifier_dict['ECU_standalone_mode_2']
}
request_defined_1 = [0x2E, 0xC1, 0x10, 0xBD, 0xDB, 0x6B, 0x3A]
request_defined_2 = [0x2E, 0xC1, 0x11, 0x42, 0x24, 0x94, 0xC5]
request_undefined_1 = [0x2E, 0xC1, 0x10, 0x11, 0x22, 0x33, 0x44]
request_undefined_2 = [0x2E, 0xC1, 0x11, 0x11, 0x22, 0x33, 0x44]
expected_response_1 = [0x6E, 0xC1, 0x10]
expected_response_2 = [0x6E, 0xC1, 0x11]

try:
    # #########################################################################

    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_282")
    hil = testenv.getHil()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    vf = VFlashAPI(vflash_dll_path)

    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
   # testresult.append(["[.] Tester Present deaktivieren", ""])
   # canape_diag.disableTesterPresent()

    testresult.append(["\xa0 In Default Session auslesen", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["\x0a Wechsel in Factory Mode:  0x1060", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    testresult.append(["\xa0 Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('factory_mode'))

    testresult.append(["\xa0 Seed anfragen: 0x2761"])
    seed, result = canape_diag.requestSeed()
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(result)

    testresult.append(["\xa0 Key berechnen:"])
    key, verdictkey = canape_diag.calculateKey(seed)
    testresult.append(verdictkey)

    testresult.append(["\xa0 Key senden: 0x2762 + <berechnet key>:"])
    verdict = canape_diag.sendKey(key)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.extend(verdict)

    testresult.append(["[-] ECU auf 'Standalone aktiv' setzen ", ""])
    testresult.append(["[+] Anpasskanal 1 und 2 auf 'definierte' Werte setzen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_defined_1)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_1))
    #[response, result] = canape_diag.sendDiagRequest(request_defined_2)
   # testresult.append(result)
    #testresult.append(canape_diag.checkResponse(response, expected_response_2))

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']['active']
        testresult.append(canape_diag.checkResponse(response, expected_response))

    '''   
    testresult.append(["\xa02.8 Schreiben der Knockout Timer: 0x2E02CB + 3C3C (jew. 60dez)"])
    req = [0x2E, 0xC1, 0x10, 0xDB, 0x6B, 0x3A]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 02CB ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, req))

    testresult.append(["\x0a2.9 Auslesen der Knockout Timer: 0x2202CB"])
    req = [0x22, 0xC1, 0x10]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, req))
'''
    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    #testenv.shutdownECU()

finally:
    # #########################################################################
    #testenv.shutdownECU()
    #testenv.breakdown()
    pass
    # #########################################################################