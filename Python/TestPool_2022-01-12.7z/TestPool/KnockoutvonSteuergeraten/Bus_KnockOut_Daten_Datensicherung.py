# ******************************************************************************
# -*- coding: latin1 -*-
# File    : Bus_KnockOut_Daten_Datensicherung.py
# Title   :Bus_KnockOut_Daten_Datensicherung
# Task    : Test for Bus_KnockOut_Daten_Datensicherung
#
# Author  : Devangbhai Patel
# Date    : 04.01.2022
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 04.01.2022 | Devangbhai   | initial

from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import functions_nm
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident_KN_CTR = identifier_dict['Knockout_counter']
    diag_ident_KN_TMR = identifier_dict['Knockout_timer']
    diag_ident_KN_TEST_MODE = identifier_dict['Knockout_test_mode']
    func_nm = functions_nm.FunctionsNM(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_272")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["[.] Wechsle in die Extended Session", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["[.] BusKnockOut_Tmr und ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] BusKnockOut_Ctr und ECUKnockOut_Ctr auf 0 setzen"])
    request = [0x2E] + diag_ident_KN_CTR['identifier'] + [0x00, 0x00]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.]  ECU ausschalten", ""])
    # canape_diag.disableTesterPresent()
    testenv.canape_Diagnostic = None

    # clear instances before
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)

    testenv.shutdownECU()
    func_nm.hil_ecu_tx_off_state("aus")
    time.sleep(10)
    testresult.append(["\xa0 ECU einschalten", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    # TEST PROCESS ########################################################################################################################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])
    testresult.append(["\xa0Wechsle in die Extended Session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\x0a 1. BusKnockOut_Tmr auf 3 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x03]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))


    testresult.append(["\x0a 2. Pr�fe BusKnockOut_Tmr"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_start = None
    ECUKnockoutTmr_start = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BusKnockoutTmr_start is not None:
            BusKnockoutTmr_start = BusKnockoutTmr_start
        else:
            BusKnockoutTmr_start = 0

        if ECUKnockoutTmr_start is not None:
            ECUKnockoutTmr_start = ECUKnockoutTmr_start
        else:
            ECUKnockoutTmr_start = 0

        testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr > ECUKnockOut_Tmr"])
        testresult.append(basic_tests.compare(BusKnockoutTmr_start, '<', ECUKnockoutTmr_start, descr="Pr�fe dass BusKnockOut_Tmr < ECUKnockOut_Tmr"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 3. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3")]

    testresult.append(["\x0a 4. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr_start = response[4]
        if BUSKnockOut_Ctr_start is not None:
            BUSKnockOut_Ctr_start = BUSKnockOut_Ctr_start
        else:
            BUSKnockOut_Ctr_start = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr_start, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 5. KL15 ausschalten"])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a 6. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3")]

    testresult.append(["\x0a 7. Pr�fe BUS-Kommunikation", ""])
    testresult.append(["\xa0  SPECIFICATIONS NEEDS TO BE UPDATED ", "INFO"])     # TODO: CHECK IF THE BUS COMMUNICATES ON THE BUS VIA NM MESSAGE

    testresult.append(["\x0a 8. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a 9. Warte auf InternalTmr_Bus == 2 (Timeout: 1 min)", ""])
    time.sleep(61)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 2, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 2")]

    testresult.append(["\x0a 10. Pr�fe, dass InternalTmr_Bus nach 60 Sekunden dekrementiert wird", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 1, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 1")]

    testresult.append(["\x0a 11. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr_start = response[4]
        if BUSKnockOut_Ctr_start is not None:
            BUSKnockOut_Ctr_start = BUSKnockOut_Ctr_start
        else:
            BUSKnockOut_Ctr_start = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr_start, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 12. Warte bis InternalTmr_Bus == 0 (Timeout: 1 min)", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 0, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 0")]

    testresult.append(["\x0a 13. Pr�fe KN_Waehlhebel:Waehlhebel_Abschaltstufe", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__Waehlhebel_Abschaltstufe__value, 0, descr="KN_Waehlhebel:Waehlhebel_Abschaltstufe  == 0 (keine_Einschraenkung)")]

    testresult.append(["\x0a 14. Pr�fe NVEM_12:NVEM_Abschaltstufe", ""])
    testresult += [basic_tests.checkStatus(hil.NVEM_12__NVEM_Abschaltstufe__value, 3, equal=False, descr="NVEM_12:NVEM_Abschaltstufe__value != 3")]

    testresult.append(["\x0a 15. Sende NVEM_12:NVEM_Abschaltstufe = 3 (Stufe_3)", ""])
    hil.NVEM_12__NVEM_Abschaltstufe__value.set(3)

    testresult.append(["\x0a 16. Pr�fe KN_Waehlhebel:Waehlhebel_Abschaltstufe", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__Waehlhebel_Abschaltstufe__value, 1, descr="KN_Waehlhebel:Waehlhebel_Abschaltstufe  == 1  (Funktionseinschraenkung)")]
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 13 to 16 ***", "INFO"])

    testresult.append(["\x0a 17. Warte bis BusKnockOut_Ctr == 0x01 (Timeout: ?)", ""])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr= None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr, 1, descr=" Pr�fe BusKnockOut_Ctr == 0x01")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 18. Warte auf Reset des SG (Timeout: ?)", ""])
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 18 ***", "INFO"])
    time.sleep(5)

    testresult.append(["\x0a 19. Pr�fe nichtfl�chtige Speicherung von BusKnockOut_Tmr", ""])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr = response[4]
        if BusKnockoutTmr is not None:
            BusKnockoutTmr = BusKnockoutTmr
        else:
            BusKnockoutTmr = 0
        testresult.append(basic_tests.compare(BusKnockoutTmr, '==', 3, descr="Pr�fe dass BusKnockOut_Tmr == 3"))

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 20. Pr�fe nichtfl�chtige Speicherung von BusKnockOut_Ctr", ""])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr, 1, descr=" Pr�fe BusKnockOut_Ctr == 0x01  (wurde inkrementiert)")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 21. Pr�fe nichtfl�chtige Speicherung von InternalTmr_Bus", ""])
    if BusKnockoutTmr is not None:
        testresult.append(basic_tests.compare(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, '==', BusKnockoutTmr, descr="Pr�fe dass InternalTmr_Bus == BusKnockOut_Tmr"))
    else:
        testresult.append(["\xa0 BusKnockOut_Tmr kann nicht auslesen", "FAILED"])

    #######################################################################################################################################################################################

    testresult.append(["\x0a 22. BusKnockOut_Tmr auf 1 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x01]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 23. Pr�fe BusKnockOut_Tmr"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_start = None
    ECUKnockoutTmr_start = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BusKnockoutTmr_start is not None:
            BusKnockoutTmr_start = BusKnockoutTmr_start
        else:
            BusKnockoutTmr_start = 0

        if ECUKnockoutTmr_start is not None:
            ECUKnockoutTmr_start = ECUKnockoutTmr_start
        else:
            ECUKnockoutTmr_start = 0

        testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr > ECUKnockOut_Tmr"])
        testresult.append(basic_tests.compare(BusKnockoutTmr_start, '<', ECUKnockoutTmr_start,
                                              descr="Pr�fe dass BusKnockOut_Tmr < ECUKnockOut_Tmr"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 24. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 1,
                                           descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 1")]

    testresult.append(["\x0a 25. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr_start = response[4]
        if BUSKnockOut_Ctr_start is not None:
            BUSKnockOut_Ctr_start = BUSKnockOut_Ctr_start
        else:
            BUSKnockOut_Ctr_start = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr_start, 1, descr=" Pr�fe BusKnockOut_Ctr == 0x01")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 26. KL15 ausschalten"])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a 27. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 1,
                                           descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 1")]

    testresult.append(["\x0a 28. Pr�fe BUS-Kommunikation", ""])
    testresult.append(["\xa0  SPECIFICATIONS NEEDS TO BE UPDATED ", "INFO"])  # TODO: CHECK IF THE BUS COMMUNICATES ON THE BUS VIA NM MESSAGE

    testresult.append(["\x0a 29. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a 30. Pr�fe KN_Waehlhebel:Waehlhebel_Abschaltstufe", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__Waehlhebel_Abschaltstufe__value, 0, descr="KN_Waehlhebel:Waehlhebel_Abschaltstufe  == 0 (keine_Einschraenkung)")]

    testresult.append(["\x0a 31. Pr�fe NVEM_12:NVEM_Abschaltstufe", ""])
    testresult += [basic_tests.checkStatus(hil.NVEM_12__NVEM_Abschaltstufe__value, 3, equal=False, descr="NVEM_12:NVEM_Abschaltstufe__value != 3")]

    testresult.append(["\x0a 32. Sende NVEM_12:NVEM_Abschaltstufe = 3 (Stufe_3)", ""])
    hil.NVEM_12__NVEM_Abschaltstufe__value.set(3)

    testresult.append(["\x0a 33. Pr�fe KN_Waehlhebel:Waehlhebel_Abschaltstufe", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__Waehlhebel_Abschaltstufe__value, 1, descr="KN_Waehlhebel:Waehlhebel_Abschaltstufe  == 1  (Funktionseinschraenkung)")]

    testresult.append(["\x0a 34. Warte bis InternalTmr_Bus == 0 (Timeout: 1 min)", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 0, descr=" KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 0")]

    testresult.append(["\x0a 35. Warte bis BusKnockOut_Ctr == 0x01 (Timeout: ?)++++TODO++++", ""])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr, 2, descr=" Pr�fe BusKnockOut_Ctr == 0x02")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 36. Warte auf Reset des SG (Timeout: ?)", ""])
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 36 ***", "INFO"])
    time.sleep(5)

    testresult.append(["\x0a 37. Pr�fe nichtfl�chtige Speicherung von BusKnockOut_Tmr", ""])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_end = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_end = response[4]
        if BusKnockoutTmr_end is not None:
            BusKnockoutTmr_end = BusKnockoutTmr_end
        else:
            BusKnockoutTmr_end = 0
        testresult.append(basic_tests.compare(BusKnockoutTmr_end, '==', 1, descr="Pr�fe dass BusKnockOut_Tmr == 1"))

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 38. Pr�fe nichtfl�chtige Speicherung von BusKnockOut_Ctr", ""])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [
            basic_tests.checkStatus(BUSKnockOut_Ctr, 2, descr=" Pr�fe BusKnockOut_Ctr == 0x02  (wurde inkrementiert)")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 39. Pr�fe nichtfl�chtige Speicherung von InternalTmr_Bus", ""])
    if BusKnockoutTmr_end is not None:
        testresult.append(
            basic_tests.compare(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, '==', BusKnockoutTmr_end,
                                descr="Pr�fe dass InternalTmr_Bus == BusKnockOut_Tmr"))
    else:
        testresult.append(["\xa0 BusKnockOut_Tmr kann nicht auslesen", "FAILED"])


    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)