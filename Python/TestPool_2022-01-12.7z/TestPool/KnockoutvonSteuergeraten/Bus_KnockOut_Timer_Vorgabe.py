#******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : Bus_KnockOut_Timer_Vorgabe.py
# Title   : Bus KnockOut Timer Vorgabe
# Task    : BU KnockOut Timer Vorgabe

# Author  : Devangbhai Patel
# Date    :  05.01.2022
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name       | Description
#------------------------------------------------------------------------------
# 1.0  | 05.01.2022 | Devangbhai   | initial
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import functions_nm
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident_KN_CTR = identifier_dict['Knockout_counter']
    diag_ident_KN_TMR = identifier_dict['Knockout_timer']
    diag_ident_KN_TEST_MODE = identifier_dict['Knockout_test_mode']
    func_nm = functions_nm.FunctionsNM(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_273")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["[.] Wechsle in die Extended Session", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["[.] BusKnockOut_Tmr und ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] BusKnockOut_Ctr und ECUKnockOut_Ctr auf 0 setzen"])
    request = [0x2E] + diag_ident_KN_CTR['identifier'] + [0x00, 0x00]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.]  ECU ausschalten", ""])
    # canape_diag.disableTesterPresent()
    testenv.canape_Diagnostic = None

    # clear instances before
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)

    testenv.shutdownECU()
    func_nm.hil_ecu_tx_off_state("aus")
    time.sleep(10)
    testresult.append(["\xa0 ECU einschalten", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()
    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["\x0a 1.Setze ECUKnockout_Tmr  auf 62"])
    testresult.append(["\xa0 Change to extended session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x3E, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 2.Setze BUSKnockout_Tmr  auf 61"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x3E, 0x3D]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a3. Pr�fe InternalTmr_Bus", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 61, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 61"))

    testresult.append(["\x0a4. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 61, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 61"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 3 and 4 ***", "INFO"])

    testresult.append(["\x0a 5.Setze BUSKnockout_Tmr  auf 05"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x3E, 0x05]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a7. Pr�fe InternalTmr_Bus", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 5, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 5"))

    testresult.append(["\x0a7. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 5, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 5"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 6 and 8 ***", "INFO"])

    testresult.append(["\x0a 8. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr_start = response[4]
        if BUSKnockOut_Ctr_start is not None:
            BUSKnockOut_Ctr_start = BUSKnockOut_Ctr_start
        else:
            BUSKnockOut_Ctr_start = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr_start, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 9. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0, descr="KN_Waehlhebel_BUSKnockOut = 0")]

    testresult.append(["\x0a10. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a 11. Warte 60 s"])
    time.sleep(60)

    testresult.append(["\x0a 12. Pr�fe BUS-Kommunikation", ""])
    testresult.append(["\xa0 SPECIFICATIONS NEEDS TO BE UPDATED ", "INFO"])     # TODO: CHECK IF THE BUS COMMUNICATES ON THE BUS VIA NM MESSAGE

    testresult.append(["\x0a 13. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a14. Pr�fe InternalTmr_Bus", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 4,
                                              descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 4"))

    testresult.append(["\x0a15. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 4,
                                              descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 4"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 14 and 15 ***", "INFO"])

    testresult.append(["\x0a 16.Setze BUSKnockout_Tmr  auf 61"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x3E, 0x3D]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a17. Pr�fe InternalTmr_Bus", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 4, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 4 (laufender Timer wird nicht �berschrieben)"))

    testresult.append(["\x0a18. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 4, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 4"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 17 and 18 ***", "INFO"])

    testresult.append(["\x0a19. Warte auf InternalTmr_Bus == 3 (Timeout: 1 min)", ""])
    time.sleep(60)
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3 (laufender Timer wird nicht angehalten)"))

    testresult.append(["\x0a20. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 19 and 20 ***", "INFO"])

    testresult.append(["\x0a21. KnockOut_Test auf 0x2 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x02]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 22. Warte 60 s"])
    time.sleep(60)

    testresult.append(["\x0a 23. Pr�fe InternalTmr_Bus"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3,  descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3  (Veto aktiv, Timer l�uft nicht ab)"))

    testresult.append(["\x0a24. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 23 and 24 ***", "INFO"])

    testresult.append(["\x0a 25.Setze BUSKnockout_Tmr  auf 32"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x3E, 0x20]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 26. Pr�fe InternalTmr_Bus"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3   (Timer ist eingefroren, d.h. wird nicht �berschrieben w�hrend Veto aktiv)"))

    testresult.append(["\x0a27. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 26 and 27 ***", "INFO"])

    testresult.append(["\x0a28. KnockOut_Test auf 0x0 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a29. Warte auf InternalTmr_Bus == 2 (Timeout: 1 min)", ""])
    time.sleep(60)
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 2,
                                              descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 2 (Timer laufuft weiter)"))

    testresult.append(["\x0a30. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 2,
                                              descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 2"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 29 and 30 ***", "INFO"])

    testresult.append(["\x0a 31. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a32. KL15 einschalten "])
    hil.cl15_on__.set(1)

    testresult.append(["\x0a33. Pr�fe BusKnockOut_Tmr"])

    testresult.append(["\xa0 Pr�fe Diagnoseparameter BUSKnockOut_Tmr (22 02 CB)"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BusKnockoutTmr = None

    if response[0:3] == [98, 2, 203]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BusKnockoutTmr = response[4]
        if BusKnockoutTmr is not None:
            BusKnockoutTmr = BusKnockoutTmr
        else:
            BusKnockoutTmr = 0
        testresult.append(basic_tests.checkStatus(BusKnockoutTmr, 32, descr="Pr�fe BusKnockOut_Tmr == 32 (zuletzt gesetzter Wert)"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 34. Pr�fe InternalTmr_Bus"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 32, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 32 (Reset durch KL15; �bernahme des gesetzten Wertes)"))

    testresult.append(["\x0a35. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BUSKnockOutTimer", ""])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 32, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 32"))
    testresult.append(["\xa0 *** NEEDS TO BE CHECK STEP 34 and 35 ***", "INFO"])

    testresult.append(["\x0a 36. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 37. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0, descr="KN_Waehlhebel_BUSKnockOut = 0")]

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)
