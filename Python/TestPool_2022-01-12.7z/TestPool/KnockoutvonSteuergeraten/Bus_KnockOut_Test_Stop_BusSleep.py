# ******************************************************************************
# -*- coding: latin1 -*-
# File    : Bus_KnockOut_Test_Stop_BusSleep.py
# Title   : Bus_KnockOut_Test_Stop_BusSleep
# Task    : Test for Bus_KnockOut_Test_Stop_BusSleep
#
# Author  : Mohammed Abdul Karim
# Date    : 22.12.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 22.12.2021 | Mohammed   | initial
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
import functions_nm
from time import time as t
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)
    func_nm = functions_nm.FunctionsNM(testenv)

    # Initialize variables ####################################################
    #diag_ident = identifier_dict['Knockout_timer']
    diag_ident_timer = identifier_dict['Knockout_timer']
    diag_ident_counter = identifier_dict['Knockout_counter']
    diag_ident_Testmode= identifier_dict['Knockout_test_mode']

    test_variable = hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
    test_variable.alias = "KN_Waehlhebel:BusKnockOutTimer"
    func_com = functions_common.FunctionsCommon(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_276")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["\xa0Wechsle in die Extended Session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # 1
    testresult.append(["\x0a 1. Setze BusKnockOut_Tmr auf 15"])
    req = [0x2E, 0x02, 0xCB, 0x10, 0x0F]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    response_dict = {}
    request = [0x22] + diag_ident_timer['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    if len(response) > 3:
        response_dict[diag_ident_timer['name']] = response[3:]
        testresult.append(["\xa0Pr�fe ECUKnockOut_Tmr > BusKnockOut_Tmr  ist %s: %s" % (diag_ident_timer['name'], response[3:]), "INFO"])
    else:
        testresult.append(["Unerwartete Response! Folgende Tests davon betroffen!", "FAILED"])

    BusKnockoutTmr_start = None
    ECUKnockoutTmr_start = None
    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BusKnockoutTmr_start is not None:
            BusKnockoutTmr_start = BusKnockoutTmr_start
            testresult.append([ "\xa0 Gespeichere Wert f�r BusKnockoutTmr_start f�r sp�teren Vergleich ist %s" % BusKnockoutTmr_start,"PASSED"])
        else:
            BusKnockoutTmr_start = 0
            testresult.append(["\xa0 Gespeichere Wert f�r BusKnockoutTmr_start f�r sp�teren Vergleich ist %s" % BusKnockoutTmr_start,"FAILED"])

        if ECUKnockoutTmr_start is not None:
            ECUKnockoutTmr_start = ECUKnockoutTmr_start
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start f�r sp�teren Vergleich ist %s" % ECUKnockoutTmr_start,"PASSED"])
        else:
            ECUKnockoutTmr_start = 0
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start f�r sp�teren Vergleich ist %s" % ECUKnockoutTmr_start,"FAILED"])
            testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr < ECUKnockOut_Tmr"])
            testresult.append(basic_tests.compare(BusKnockoutTmr_start, '<', ECUKnockoutTmr_start, descr="Pr�fe dass BusKnockOut_Tmr > ECUKnockOut_Tmr"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\xa03. Pr�fe InternalTmr_Bus ist ", "INFO"])
    #testresult.append([" Pr�fe InternalTmr_Bus ist %s" % InternalTmr_Bus, ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                           descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    '''
    InternalTmr_Bus = None
    if response[0:3] == [98, 2, 203]:
        InternalTmr_Bus = response[4]
        if InternalTmr_Bus is not None:
            InternalTmr_Bus == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
            testresult.append([" Pr�fe InternalTmr_Bus ist %s" % InternalTmr_Bus, ""])
            testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                                   descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
        else:
            BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
            testresult.append(["InternalTmr_Bus  %s" % BusKnockoutTmr_start, "FAILED"])
'''
    testresult.append(["\x0a 4. BusKnockOut_Ctr"])
    request = [0x22] + diag_ident_counter['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BusKnockOut_Ctr_start = None
    if response[0:3] == [98, 2, 202]:
        BusKnockOut_Ctr_start = response[4]
        testresult.append( ["\xa0 Pr�fe BusKnockOut_Ctr == 0x00 ist %s" % BusKnockOut_Ctr_start, "PASSED"])
    else:
        testresult.append(["\xa0 Kein Positive response erhalten. ", "FAILED"])

    testresult.append(["\xa05. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", "INFO"])
    # testresult.append([" Pr�fe InternalTmr_Bus ist %s" % InternalTmr_Bus, ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                           descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    testresult.append(["\x0a6. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    '''
    testresult.append(["\x0a6. KnockOut_Test auf 0x1 setzen*"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_Testmode['identifier'] + [0x01]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    #### Todo: 7.1 Kein Senden und Empfangen von Botschaften (WH im lokalen Nachlauf)

    testresult.append(["\x0a7.2 Pr�fe Strommonitoring (2 mA<I<100mA)", ""])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.002,  # 2mA
            max_value=0.100,  # 100mA
            descr="Pr�fe, dass Strom zwischen 2mA und 100mA liegt"
        )
    )

    testresult.append(["\x0a8.  Pr�fe Bus State"])
    req = [0x22] + diag_ident_Testmode['identifier']
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62] + diag_ident_Testmode['identifier'] + [0x01]
    testresult.append(["Pr�fe  Bus State == Bus Sleep", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\x0a Schalte Senden von RX Signalen (HiL --> ECU) aus", "INFO"])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0a9. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3,
                                           descr="KN_Waehlhebel_ECUKnockOutTimer = 3")]

    testresult.append(["\x0a10. Pr�fe InternalTmr_ECU nach 61 Sekunden", ""])
    time.sleep(61)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 2,
                                           descr="KN_Waehlhebel_ECUKnockOutTimer = 2"),
                   ]

    testresult.append(["\x0a11. Pr�fe InternalTmr_ECU nach 60 Sekunden", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 1,
                                           descr="KN_Waehlhebel_ECUKnockOutTimer = 1"),
                   ]

    
    testresult.append(["\x0a 3. Warte 1,5 Minuten"])
    time.sleep(1.5*60)

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe InternalTmr_Bus == BusKnockOut_Tmr (Timer l�uft nicht) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_ECUKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\x0a 5. Warte 1,5 Minuten"])
    time.sleep(1.5 * 60)

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe  InternalTmr_Bus == BusKnockOut_Tmr (Timer l�uft nicht) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_ECUKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\x0a 7. Warte 12,5 Minuten"])
    time.sleep(12.50 * 60)

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe InternalTmr_Bus == BusKnockOut_Tmr (Timer l�uft nicht) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_ECUKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\xa0Wechsle in die Extended Session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\x0a 9. Pr�fe BusKnockOut_Ctr (22 02 CB) ist "])
    request = [0x22] + diag_ident['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    BusKnockoutTmr_end = response[4]
    if BusKnockoutTmr_end is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe BusKnockOut_Ctr == busctr_start (unver�ndert) ist %s" % BusKnockoutTmr_end, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_ECUKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_end, "FAILED"])
'''

    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)