# ******************************************************************************
# -*- coding: latin1 -*-
# File    : kein_Bus_KnockOut_KL15_EIN.py
# Title   :kein_Bus_KnockOut_KL15_EIN
# Task    : Test for kein_Bus_KnockOut_KL15_EIN
#
# Author  : Mohammed Abdul Karim
# Date    : 17.12.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 17.12.2021 | Mohammed   | initial
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Knockout_timer']

    test_variable = hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
    test_variable.alias = "KN_Waehlhebel:BusKnockOutTimer"

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_206")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["\xa0Wechsle in die Extended Session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    #
    # 1
    testresult.append(["\x0a 1. Pr�fe BusKnockOut_Ctr und speichere Wert in busctr_start(22 02 CB)"])
    response_dict = {}
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BusKnockOut_Ctr_start = None
    if len(response) > 3:
        response_dict[diag_ident['name']] = response[3:]
        testresult.append(["\xa0Pr�fe BusKnockOut_Ctr und speichere Wert in busctr_start ist %s: %s" % (diag_ident['name'], response[3:]), ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Ausgangswert)")]
    else:
        testresult.append(["Unerwartete Response! Folgende Tests davon betroffen!", "FAILED"])

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe InternalTmr_Bus == BusKnockOut_Tmr (Ausgangswert) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Ausgangswert) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\x0a 3. Warte 1,5 Minuten"])
    time.sleep(1.5*60)

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe InternalTmr_Bus == BusKnockOut_Tmr (Timer l�uft nicht) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\x0a 5. Warte 1,5 Minuten"])
    time.sleep(1.5 * 60)

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe  InternalTmr_Bus == BusKnockOut_Tmr (Timer l�uft nicht) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\x0a 7. Warte 12,5 Minuten"])
    time.sleep(12.50 * 60)

    BusKnockoutTmr_start = response[4]
    if BusKnockoutTmr_start is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe InternalTmr_Bus == BusKnockOut_Tmr (Timer l�uft nicht) ist %s" % BusKnockoutTmr_start, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_start, "FAILED"])

    testresult.append(["\xa0Wechsle in die Extended Session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["\x0a 9. Pr�fe BusKnockOut_Ctr (22 02 CB) ist "])
    request = [0x22] + diag_ident['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    BusKnockoutTmr_end = response[4]
    if BusKnockoutTmr_end is not None:
        BusKnockoutTmr_start == hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" Pr�fe BusKnockOut_Ctr == busctr_start (unver�ndert) ist %s" % BusKnockoutTmr_end, ""])
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 15,
                                               descr="KN_Waehlhebel_BusKnockOutTimer = 15 (Timer l�uft nicht)")]
    else:
        BusKnockoutTmr_start != hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value
        testresult.append([" InternalTmr_Bus != BusKnockOut_Tmr (Timer l�uft nicht) %s" % BusKnockoutTmr_end, "FAILED"])

    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)