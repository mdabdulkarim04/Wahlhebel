# ******************************************************************************
# -*- coding: latin1 -*-
# File    : ECU_KnockOut_Veto_KL15_EIN.py
# Title   :ECU_KnockOut_Veto_KL15_EIN
# Task    : Test for ECU_KnockOut_Veto_KL15_EIN
#
# Author  : Devangbhai Patel
# Date    : 05.10.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 05.10.2021 | Devangbhai   | initial
# 1.1  | 12.10.2021 | Mohammed   | Rework
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)
    test_dict = {
        1: identifier_dict['Knockout_test_mode'],
        2: identifier_dict['Knockout_counter'],
        3: identifier_dict['Knockout_timer']
    }

    request_dict = {1: {
                    'identifier': [0x2E, 0x02, 0xCA],
                    'name': 'Knockout_counter_write',
                    'expected_response': [0x6E, 0x02, 0xCA],
                    'exp_data_length': 3},
        2: {
                    'identifier': [0x2E, 0x02, 0xCB],
                    'name': 'Knockout_timer_write',
                    'expected_response': [0x6E, 0x02, 0xCB], # ToDo
                    'exp_data_length': 3,  # Bytes
                    },
        3: {
                    'identifier': [0x2E, 0x09, 0xF3],
                    'name': 'Knockout_test_mode_write',
                    'expected_response': [0x6E, 0x09, 0xF3], # ToDo
                    'exp_data_length': 3
                    },
    }

    # Initialize variables ####################################################
    test_variable = hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value
    test_variable.alias = "KN_Waehlhebel:ECUKnockOutTimer"

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_269")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # 1
    testresult.append(["[.]Setze ECUKnockout_Tmr  auf 5"])
    req = [0x2E, 0x02, 0xCB, 0x05, 0x0F]
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)
    if response == [0x6E, 0x02, 0xCB]:
        testresult.append(["ECUKnockout_Tmr  auf 5 gesetz", "INFO"])
    else:
        testresult.append(["Negative Antwort", "FAILED"])

    # 2
    testresult.append(["[.]Pr�fe BusKnockOut_Tmr"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x05, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.compareCE(response[4], '>', response[3],
                                                        descr='Pr�f ob BusKnockOut_Tmr > ECUKnockOut_Tmr'))
                testresult.append(basic_tests.checkStatus(response[3], 0x03, descr='Pr�f InternalTmr_ECU ist 0x05 '))
            else:
                testresult.append(basic_tests.compareCE(response[4], '>', response[3],
                                                        descr='Pr�f ob BusKnockOut_Tmr > ECUKnockOut_Tmr'))
                testresult.append(basic_tests.checkStatus(response[3], 0x03, descr='Pr�f InternalTmr_ECU ist 0x05 '))

    # 3
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x05, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x05, descr='Pr�f InternalTmr_ECU ist 0x05 '))

    ###
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 5,descr="InternalTmr_ECU : 5"))

    # 4
    testresult.append(["[.] Pr�f ECUKnockOut_Ctr"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_counter':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCA, 0x00, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x00, descr='Pr�f ECUKnockOut_Ctr ist 0'))
            else:
                testresult.append(["Negative Antwort", "FAILED"])

    # 5
    testresult.append(["[.]Setze Knockout_test auf 0x2"])
    for req in request_dict:
        req_data = request_dict[req]
        if req_data['name'] == 'Knockout_test_mode_write':
            [response, result] = canape_diag.sendDiagRequest(req_data['identifier'] + [0x02])
            testresult.append(canape_diag.checkResponse(response, req_data['expected_response']))

    # 6
    testresult.append(["[.] KL15 ausschalten"])
    hil.cl15_on__.set(0)

    # 7
    testresult.append(["[.]Setze Knockout_test auf 0x3"])
    for req in request_dict:
        req_data = request_dict[req]
        if req_data['name'] == 'Knockout_test_mode_write':
            [response, result] = canape_diag.sendDiagRequest(req_data['identifier'] + [0x03])
            testresult.append(canape_diag.checkResponse(response, req_data['expected_response']))

    # 8
    testresult.append(["[.]Warte bis Busruhe erreicht "])
    testresult.append(["[]Pr�fe Kein Senden und Empfagen von Botschaften im local Nachlauf ", "Info"])
    time.sleep(60)
    descr, verdict = func_gs.checkBusruhe(daq, 1)
    testresult.append([descr, verdict])
    testresult.append(basic_tests.checkRange(value=hil.cc_mon__A.get(), min_value=0.002, max_value=0.100,
                                             descr="Pr�fe, dass Strom zwischen 2mA und 100mA liegt"))

    # 9
    testresult.append(["[.]Pr�fe  Bus State"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_test_mode':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x09, 0xF3, 0x00]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x00, descr='Pr�f Bus State = Bus Sleep '))
            else:
                testresult.append(["Negative Antwort", "FAILED"])

    # 10
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x05, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x05, descr='Pr�f InternalTmr_ECU ist 0x05 '))
###
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 5,
                                              descr="InternalTmr_ECU : 5"))

    # 11
    testresult.append(["[.]Pr�fe 70 s lang, dass InternalTmr_ECU eingefroren ist"])
    time.sleep(70)
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 5,
                                              descr="nicht dekrementiert"))

    # 12
    testresult.append(["[.]Setze Knockout_test auf 0x1"])
    for req in request_dict:
        req_data = request_dict[req]
        if req_data['name'] == 'Knockout_test_mode_write':
            [response, result] = canape_diag.sendDiagRequest(req_data['identifier'] + [0x01])
            testresult.append(canape_diag.checkResponse(response, req_data['expected_response']))

    # 13
    testresult.append(["[.] Pr�fe, dass InternalTmr_ECU nach 1 Minute um 1 dekrementiert wird"])
    time.sleep(60)
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x04, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x04, descr='Pr�f InternalTmr_ECU ist 0x04 '))
    ####
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 4,
                                              descr="InternalTmr_ECU : 4"))

    # 14
    testresult.append(["[.]Warte bis InternalTmr_ECU = 3 (Timeout: 61 s)"])
    time.sleep(61)
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x03, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x03, descr='Pr�f InternalTmr_ECU ist 0x03 '))
    ###
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3,
                                              descr="InternalTmr_ECU : 3"))

    # 15
    testresult.append(["[.]Setze Knockout_test auf 0x3"])
    for req in request_dict:
        req_data = request_dict[req]
        if req_data['name'] == 'Knockout_test_mode_write':
            [response, result] = canape_diag.sendDiagRequest(req_data['identifier'] + [0x03])
            testresult.append(canape_diag.checkResponse(response, req_data['expected_response']))
####
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3,
                                              descr="InternalTmr_ECU : 3"))

    # 16
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x03, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x03, descr='Pr�f InternalTmr_ECU ist 0x03 '))

    # 17
    testresult.append(["[.]Pr�fe 70 s lang, dass InternalTmr_ECU eingefroren ist"])
    time.sleep(70)
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x03, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x03, descr='Pr�f InternalTmr_ECU ist 0x03 '))

    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3,
                                              descr="InternalTmr_ECU : 3"))

    # 18
    testresult.append(["[.]Setze Knockout_test auf 0x1"])
    for req in request_dict:
        req_data = request_dict[req]
        if req_data['name'] == 'Knockout_test_mode_write':
            [response, result] = canape_diag.sendDiagRequest(req_data['identifier'] + [0x01])
            testresult.append(canape_diag.checkResponse(response, req_data['expected_response']))

    # 19
    testresult.append(["[.] Pr�fe, dass InternalTmr_ECU nach 1 Minute um 1 dekrementiert wird"])
    time.sleep(60)
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x02, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x02, descr='Pr�f InternalTmr_ECU ist 0x02 '))

    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 2,
                                              descr="InternalTmr_ECU : 2"))

    # 20
    testresult.append(["[.] KL15 einschalten"])
    hil.cl15_on__.set(1)

    # 21
    testresult.append(["[.] Pr�fe ECUKnockOut_Tmr"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x05, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x05, descr='Pr�f ECUKnockOut_Tmr ist 5 '))
            else:
                testresult.append(["Negative Antwort", "FAILED"])

    # 22
    testresult.append(["[.] Pr�f ECUKnockOut_Ctr"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_counter':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCA, 0x00, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x00, descr='Pr�f ECUKnockOut_Ctr ist 0'))
            else:
                testresult.append(["Negative Antwort", "FAILED"])

    # 23
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value.get(), 1, descr='Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut ist 1'))

    # 24
    testresult.append(["[.] Pr�fe InternalTmr_ECU"])
    for test in test_dict:
        test_data = test_dict[test]
        if test_data['name'] == 'Knockout_timer':
            request = [0x22] + test_data['identifier']
            expected_response = [0x62, 0x02, 0xCB, 0x03, 0x0F]
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(canape_diag.checkResponse(response, expected_response))
            if response == expected_response:
                testresult.append(basic_tests.checkStatus(response[3], 0x03, descr=' InternalTmr_ECU == ECUKnockOut_Tmr (Reset durch KL15 ein)'))

    hil.cl15_on__.set(1)
    testresult.append(basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value.get(), 2, descr='Pr�f KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value ist 2'))


    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)