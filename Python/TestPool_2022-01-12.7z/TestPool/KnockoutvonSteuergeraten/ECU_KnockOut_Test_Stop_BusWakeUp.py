# ******************************************************************************
# -*- coding: latin1 -*-
# File    : ECU_KnockOut_Test_Stop_BusWakeUp.py
# Title   :ECU_KnockOut_Test_Stop_BusWakeUp
# Task    : Test for ECU_KnockOut_Test_Stop_BusWakeUp
#
# Author  : Devangbhai Patel
# Date    : 06.10.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 05.10.2021 | Devangbhai   | initial
# 1.1  | 03.01.2022 | Devangbhai   | Rework according to test specification
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import functions_nm
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident_KN_CTR = identifier_dict['Knockout_counter']
    diag_ident_KN_TMR = identifier_dict['Knockout_timer']
    diag_ident_KN_TEST_MODE = identifier_dict['Knockout_test_mode']
    func_nm = functions_nm.FunctionsNM(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_271")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["[.] Wechsle in die Extended Session", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["[.] BusKnockOut_Tmr und ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] BusKnockOut_Ctr und ECUKnockOut_Ctr auf 0 setzen"])
    request = [0x2E] + diag_ident_KN_CTR['identifier'] + [0x00, 0x00]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.]  ECU ausschalten", ""])
    # canape_diag.disableTesterPresent()
    testenv.canape_Diagnostic = None

    # clear instances before
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)

    testenv.shutdownECU()
    func_nm.hil_ecu_tx_off_state("aus")
    time.sleep(10)
    testresult.append(["\xa0 ECU einschalten", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # 1
    testresult.append(["\x0a 1. Setze ECUKnockOut_Tmr auf 12"])

    testresult.append(["\xa0 Change to extended session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0C, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    # 2
    testresult.append(["\x0a 2. Pr�fe BusKnockOut_Tmr"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_start = None
    ECUKnockoutTmr_start = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BusKnockoutTmr_start is not None:
            BusKnockoutTmr_start = BusKnockoutTmr_start
        else:
            BusKnockoutTmr_start = 0

        if ECUKnockoutTmr_start is not None:
            ECUKnockoutTmr_start = ECUKnockoutTmr_start
        else:
            ECUKnockoutTmr_start = 0
        testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr > ECUKnockOut_Tmr"])
        testresult.append(basic_tests.compare(BusKnockoutTmr_start, '>', ECUKnockoutTmr_start, descr="Pr�fe dass BusKnockOut_Tmr > ECUKnockOut_Tmr"))

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
    # 4
    testresult.append(["\x0a 4. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start = response[3]
        if ECUKnockOut_Ctr_start is not None:
            ECUKnockOut_Ctr_start = ECUKnockOut_Ctr_start
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
        else:
            ECUKnockOut_Ctr_start = 0
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    # 5
    testresult.append(["\x0a5. KL15 ausschalten"])
    hil.cl15_on__.set(0)

    # 6
    testresult.append(["\x0a 6. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a7. KnockOut_Test auf 0x1 setzen*"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a8.  Pr�fe Bus State"])
    req = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    testresult.append(["Pr�fe  Bus State == Bus Sleep", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\x0a9. Warte bis Busruhe erreicht (Timeout: ?)", ""])
    testresult.append(["\xa0  Skipping because not required", "INFO"])


    testresult.append(["\x0a10. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 12,  descr=" KN_Waehlhebel_ECUKnockOutTimer = 12")]

    testresult.append(["\x0a11. Pr�fe, dass InternalTmr_ECU nach 1 Minute um 1 dekrementiert wird", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 11, descr=" KN_Waehlhebel_ECUKnockOutTimer = 11 (wird dekrementiert)")]

    testresult.append(["\x0a12. KnockOut_Test auf 0x0 setzen*"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a13. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a14. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 12, descr=" KN_Waehlhebel_ECUKnockOutTimer = 12 (Reset durch Bus State != Bus Sleep)")]


    testresult.append(["\x0a15. Pr�fe 70 s lang, dass InternalTmr_ECU konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value.get())
    print len(timerlist), "Printing out the timer list lenght"
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append(["\xa0 InternalTmr_ECU konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(["\xa0 InternalTmr_ECU konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a16. Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOutTimer", ""])
    testresult.append(["\xa0 NEEDS TO CHECK SPECIFICATION", "FAILED"])

    testresult.append(["\x0a17.  Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0x0")]

    testresult.append(["\x0a18. KL15 einschalten"])
    hil.cl15_on__.set(1)

    testresult.append(["\x0a19. Warte 10s"])
    time.sleep(10)

    testresult.append(["\x0a20. KL15 ausschalten"])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a21. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a22.  KnockOut_Test auf 0x5 setzen (Bit 1 und 3: Bus State == Bus Sleep und Vetos unterdr�ckt (intern und von Testfunktion, Bit 2))"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x05]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a23. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State = Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, descr="Pr�fe dass Bus State = Bus Sleep")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a24. Warte bis Busruhe erreicht (Timeout: ?)", ""])
    testresult.append(["\xa0  Skipping because not required", "INFO"])

    testresult.append(["\x0a25. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 12,
                                           descr=" KN_Waehlhebel_ECUKnockOutTimer = 12 ")]

    testresult.append(["\x0a26. Pr�fe, dass InternalTmr_ECU nach 1 Minute um 1 dekrementiert wird", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 11,
                                           descr=" KN_Waehlhebel_ECUKnockOutTimer = 11 ")]

    testresult.append(["\x0a27. Warte bis InternalTmr_ECU == 10 (Timeout: 61 s)", ""])
    time.sleep(61)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 10,
                                           descr=" KN_Waehlhebel_ECUKnockOutTimer = 10 ")]

    testresult.append(["\x0a28. KnockOut_Test auf 0x0 setzen*"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a29. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a30. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 12, descr=" KN_Waehlhebel_ECUKnockOutTimer = 12 (Reset durch Bus State != Bus Sleep)")]

    testresult.append(["\x0a31. Pr�fe 70 s lang, dass InternalTmr_ECU konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value.get())
    print len(timerlist), "Printing out the timer list lenght"
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append( ["\xa0 InternalTmr_ECU konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(["\xa0 InternalTmr_ECU konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a32. Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOutTimer", ""])
    testresult.append(["\xa0 NEEDS TO CHECK SPECIFICATION", "FAILED"])

    testresult.append(["\x0a33.  Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0x0")]


    testresult.append(["\x0a34. KL15 einschalten"])
    hil.cl15_on__.set(1)

    testresult.append(["\x0a35. Warte 10s"])
    time.sleep(10)

    testresult.append(["\x0a36. KL15 ausschalten"])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a37. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a 38.KnockOut_Test auf 0x7 setzen (Bit 1, 2 und 3: Bus State == Bus Sleep, Test-Veto aktiv, aber Vetos unterdr�ckt (intern und von Testfunktion, Bit 2))"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x07]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a39. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State = Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, descr="Pr�fe dass Bus State = Bus Sleep")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a40. Warte bis Busruhe erreicht (Timeout: ?)", ""])
    testresult.append(["\xa0  Skipping because not required", "INFO"])

    testresult.append(["\x0a41. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 12, descr=" KN_Waehlhebel_ECUKnockOutTimer = 12 ")]

    testresult.append(["\x0a42. Pr�fe, dass InternalTmr_ECU nach 1 Minute um 1 dekrementiert wird", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 11, descr=" KN_Waehlhebel_ECUKnockOutTimer = 11 ")]

    testresult.append(["\x0a43. KnockOut_Test auf 0x0 setzen*"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a44. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a45. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 12,
                                           descr=" KN_Waehlhebel_ECUKnockOutTimer = 12 (Reset durch Bus State != Bus Sleep)")]

    testresult.append(["\x0a46. Pr�fe 70 s lang, dass InternalTmr_ECU konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value.get())
    print len(timerlist), "Printing out the timer list lenght"
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append(
        ["\xa0 InternalTmr_ECU konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(
        ["\xa0 InternalTmr_ECU konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a 47. Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOutTimer", ""])
    testresult.append(["\xa0 NEEDS TO CHECK SPECIFICATION", "FAILED"])

    testresult.append(["\x0a 48.  Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0x0")]

    testresult.append(["\x0a 49. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_end = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_end = response[3]
        if ECUKnockOut_Ctr_end is not None:
            ECUKnockOut_Ctr_end = ECUKnockOut_Ctr_end
            testresult += [
                basic_tests.checkStatus(ECUKnockOut_Ctr_end, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
        else:
            ECUKnockOut_Ctr_end = 0
            testresult += [
                basic_tests.checkStatus(ECUKnockOut_Ctr_end, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 50. Setze ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)