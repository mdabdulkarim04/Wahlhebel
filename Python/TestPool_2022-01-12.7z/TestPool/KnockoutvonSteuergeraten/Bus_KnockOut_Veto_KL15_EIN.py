#******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : Bus_KnockOut_Veto_KL15_EIN.py
# Title   : Bus KnockOut Veto KL15 EIN
# Task    : Bus KnockOut Veto KL15 EIN

# Author  : Devangbhai Patel
# Date    :  05.01.2022
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name       | Description
#------------------------------------------------------------------------------
# 1.0  | 05.01.2022 | Devangbhai   | initial
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import functions_nm
import os

# Instantiate test environment
testenv = TestEnv()


try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident_KN_CTR = identifier_dict['Knockout_counter']
    diag_ident_KN_TMR = identifier_dict['Knockout_timer']
    diag_ident_KN_TEST_MODE = identifier_dict['Knockout_test_mode']
    func_nm = functions_nm.FunctionsNM(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_274")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["[.] Wechsle in die Extended Session", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["[.] BusKnockOut_Tmr und ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] BusKnockOut_Ctr und ECUKnockOut_Ctr auf 0 setzen"])
    request = [0x2E] + diag_ident_KN_CTR['identifier'] + [0x00, 0x00]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.]  ECU ausschalten", ""])
    # canape_diag.disableTesterPresent()
    testenv.canape_Diagnostic = None

    # clear instances before
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)

    testenv.shutdownECU()
    func_nm.hil_ecu_tx_off_state("aus")
    time.sleep(10)
    testresult.append(["\xa0 ECU einschalten", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()
    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])
    testresult.append(["\x0a 1.Setze BUSKnockout_Tmr  auf 5"])
    testresult.append(["\xa0 Change to extended session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x05]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 2. Pr�fe ECUKnockOut_Tmr"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_start = None
    ECUKnockoutTmr_start = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BusKnockoutTmr_start is not None:
            BusKnockoutTmr_start = BusKnockoutTmr_start
        else:
            BusKnockoutTmr_start = 0

        if ECUKnockoutTmr_start is not None:
            ECUKnockoutTmr_start = ECUKnockoutTmr_start
        else:
            ECUKnockoutTmr_start = 0

        testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr < ECUKnockOut_Tmr"])
        testresult.append(basic_tests.compare(BusKnockoutTmr_start, '<', ECUKnockoutTmr_start,
                                              descr="Pr�fe dass BusKnockOut_Tmr < ECUKnockOut_Tmr"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 3. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 5,
                                           descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 5")]

    testresult.append(["\x0a 4. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr_start = response[4]
        if BUSKnockOut_Ctr_start is not None:
            BUSKnockOut_Ctr_start = BUSKnockOut_Ctr_start
        else:
            BUSKnockOut_Ctr_start = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr_start, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 5. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0, descr="KN_Waehlhebel_BUSKnockOut = 0")]

    testresult.append(["\x0a6. KnockOut_Test auf 0x2 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x02]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a7. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a 8. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 5, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 5")]

    testresult.append(["\x0a 9. Pr�fe BUS-Kommunikation", ""])
    testresult.append(["\xa0 SPECIFICATIONS NEEDS TO BE UPDATED ",
                       "INFO"])  # TODO: CHECK IF THE BUS COMMUNICATES ON THE BUS VIA NM MESSAGE

    testresult.append(["\x0a 10. Pr�fe Bus State", ""])
    request = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    bus_sleep = None

    if response[0:3] == [98, 9, 243]:
        bus_sleep = response[3]
        testresult.append(["Pr�fe dass Bus State != Bus Sleep", ""])
        testresult += [
            basic_tests.checkStatus(bus_sleep, 1, equal=False, descr="Pr�fe dass Bus State != Bus Sleep (Bus-WakeUp)")]
    else:
        testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        testresult.append(["\xa0 Kein Positive response erhalten.  Bus State kann nicht auslasen", "FAILED"])

    testresult.append(["\x0a11. Pr�fe 70 s lang, dass InternalTmr_BUS konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value.get())
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append(["\xa0 InternalTmr_BUS konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(["\xa0 InternalTmr_BUS konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a 12. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 1, descr="KN_Waehlhebel_BUSKnockOut = 1(VETO aktiv)")]

    testresult.append(["\x0a13. KnockOut_Test auf 0x0 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 14. Pr�fe, dass InternalTmr_Bus nach 1 Minute um 1 dekrementiert wird", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 4, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 4(Wird dekrementiert)")]

    testresult.append(["\x0a 15. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0, descr="KN_Waehlhebel_BUSKnockOut = 0 (Function nicht ausgel�st)")]

    testresult.append(["\x0a 16. Warte bis InternalTmr_Bus == 3 (Timeout: 61 s)", ""])
    time.sleep(61)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3")]

    testresult.append(["\x0a17. KnockOut_Test auf 0x2 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x02]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 18. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 3, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 3")]

    testresult.append(["\x0a19. Pr�fe 70 s lang, dass InternalTmr_BUS konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value.get())
    print
    len(timerlist), "Printing out the timer list lenght"
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append(["\xa0 InternalTmr_BUS konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(["\xa0 InternalTmr_BUS konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a 20. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 1, descr="KN_Waehlhebel_BUSKnockOut = 1(VETO aktiv)")]

    testresult.append(["\x0a21. KnockOut_Test auf 0x0 setzen(Kein Veto)*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 22. Pr�fe, dass InternalTmr_Bus nach 1 Minute um 1 dekrementiert wird", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 2, descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 2(Wird dekrementiert)")]

    testresult.append(["\x0a 23. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0, descr="KN_Waehlhebel_BUSKnockOut = 0 (Function nicht ausgel�st)")]

    testresult.append(["\x0a 24. KL15 einschalten "])
    hil.cl15_on__.set(1)

    testresult.append(["\x0a 25. Pr�fe BUSKnockOut_Tmr"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BUSKnockOut_Tmr = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BUSKnockOut_Tmr is not None:
            BUSKnockOut_Tmr = BUSKnockOut_Tmr
        else:
            BUSKnockOut_Tmr = 0
        testresult.append(basic_tests.compare(BUSKnockOut_Tmr, '==', 5, descr="Pr�fe dass BusKnockOut_Tmr == 5"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 26. Pr�fe  BUSKnockOut_Ctr (22 02 CA)"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    BUSKnockOut_Ctr = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        BUSKnockOut_Ctr = response[4]
        if BUSKnockOut_Ctr is not None:
            BUSKnockOut_Ctr = BUSKnockOut_Ctr
        else:
            BUSKnockOut_Ctr = 0
        testresult += [basic_tests.checkStatus(BUSKnockOut_Ctr_start, 0, descr=" Pr�fe BusKnockOut_Ctr == 0x00 (wurde nicht inkrementiert)")]
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 27. Pr�fe InternalTmr_Bus", ""])
    if BUSKnockOut_Tmr is not None:
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, BUSKnockOut_Tmr,
                                           descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = BUSKnockOut_Tmr  (Reset durch KL15 ein)")]
    else:
        testresult.append(["BUSKnockOut_Tmr kann nicht �berpr�fen", "FAILED"])

    testresult.append(["\x0a 28. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0, descr="KN_Waehlhebel_BUSKnockOut = 0 (Function nicht ausgel�st)")]

    testresult.append(["\x0a29. KnockOut_Test auf 0x2 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x02]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 30. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 5,
                                           descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 5")]

    testresult.append(["\x0a31. Pr�fe 70 s lang, dass InternalTmr_BUS konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value.get())
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append(["\xa0 InternalTmr_BUS konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(["\xa0 InternalTmr_BUS konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a 32. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 1, descr="KN_Waehlhebel_BUSKnockOut = 1(VETO aktiv)")]


    testresult.append(["\x0a 33. KnockOut_Test auf 0x0 setzen*"])
    testresult.append(["\xa0 Change to factory_mode session"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x00]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 35. Pr�fe InternalTmr_Bus", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value, 5,
                                           descr="KN_Waehlhebel_BUSKnockOutTimer(InternalTmr_BUS) = 5")]

    testresult.append(["\x0a36. Pr�fe 70 s lang, dass InternalTmr_BUS konstant bleibt", ""])
    timerlist = []
    sec = 70
    timeout = sec + t()
    while timeout > t():
        timerlist.append(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOutTimer__value.get())
    value = timerlist[0]
    value_boolean = True
    for timer_values in timerlist:
        if value != timer_values:
            value_boolean = False
            break
    testresult.append(
        ["\xa0 InternalTmr_BUS konstant hat konstant gebleiben", "PASSED"]) if value_boolean else testresult.append(
        ["\xa0 InternalTmr_BUS konstant hat nicht konstant gebleiben", "FAILED"])

    testresult.append(["\x0a 37. Pr�fe KN_Waehlhebel:KN_Waehlhebel_BusKnockOut", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_BusKnockOut__value, 0,
                                           descr="KN_Waehlhebel_BUSKnockOut =  0x0 (Funktion nicht ausgel�st)")]

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)
