# ******************************************************************************
# -*- coding: latin1 -*-
# File    : ECU_KnockOut_Timer_Vorgabe.py
# Title   :ECU_KnockOut_Timer_Vorgabe
# Task    : Test for ECU_KnockOut_Timer_Vorgabe
#
# Author  : Devangbhai Patel
# Date    : 05.10.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 27.09.2021 | Devangbhai   | initial
# 1.1  | 22.12.2021 | Devangbhai   | Rework according to test specification
# 1.2  | 03.01.2022 | Devangbhai   | Rework according to test specification

# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
from time import time as t
import os
import functions_nm

# Instantiate test environment
testenv = TestEnv()


try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident_KN_CTR = identifier_dict['Knockout_counter']
    diag_ident_KN_TMR = identifier_dict['Knockout_timer']
    diag_ident_KN_TEST_MODE = identifier_dict['Knockout_test_mode']
    func_nm = functions_nm.FunctionsNM(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_268")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["[.] Wechsle in die Extended Session", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["[.] BusKnockOut_Tmr und ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] BusKnockOut_Ctr und ECUKnockOut_Ctr auf 0 setzen"])
    request = [0x2E] + diag_ident_KN_CTR['identifier'] + [0x00, 0x00]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.]  ECU ausschalten", ""])
    testenv.canape_Diagnostic = None

    # clear instances
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)

    testenv.shutdownECU()
    func_nm.hil_ecu_tx_off_state("aus")
    time.sleep(10)
    testresult.append(["[.] ECU einschalten", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()
    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # 1
    testresult.append(["\x0a 1.Setze BUSKnockout_Tmr  auf 62"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x3E]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 2. Lese ECUKnockOut_Tmr und speichere den Wert als ecu_tmr_start"])
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    ecu_tmr_start = None

    if response[0:3] == [98, 2, 203]:
        ecu_tmr_start = response[3]
        if ecu_tmr_start is not None:
            ecu_tmr_start = ecu_tmr_start
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start (Variable) f�r sp�teren Vergleich ist %s" % ecu_tmr_start, "INFO"])
        else:
            ecu_tmr_start = 0
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start (Variable) f�r sp�teren Vergleich ist %s" % ecu_tmr_start, "INFO"])
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 3.Setze ECUKnockOut_Tmr auf 5"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x05, 0x3E]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 4.Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 15,
                                           descr="KN_Waehlhebel_ECUKnockOutTimer = 15 (Value Is updated only after KL15 off+ Bus sleep active or )")]

    testresult.append(["\x0a 5. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start = response[3]
        if ECUKnockOut_Ctr_start is not None:
            ECUKnockOut_Ctr_start = ECUKnockOut_Ctr_start
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr_start (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockOut_Ctr_start])
        else:
            ECUKnockOut_Ctr_start = 0
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr_start (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockOut_Ctr_start])

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a6. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a7.Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut"])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0")]

    testresult.append(["\x0a8. Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOutTimer"])
    if ecu_tmr_start is not None:
        testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, ecu_tmr_start , descr="KN_Waehlhebel_ECUKnockOutTimer =  ecu_tmr_start (Restwert ist Vorgabewert, da Tmr nicht dekrementiert wurde)")]
    else:
        testresult.append(["\xa0 KN_Waehlhebel:KN_Waehlhebel_ECUKnockOutTimer kann nicht mit ecu_tmr_start vergleichen", "FAILED"])

    testresult.append(["\x0a9. KnockOut_Test auf 0x1 setzen*"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a11.  Pr�fe Bus State"])
    req = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    testresult.append(["Pr�fe  Bus State == Bus Sleep", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\x0a11.1 Warte 150ms"])
    time.sleep(0.150)

    testresult.append(["\x0a11.2 Schalte Senden von RX Signalen (HiL --> ECU) aus", "INFO"])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0a12. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 5, descr=" KN_Waehlhebel_ECUKnockOutTimer = 5")]

    testresult.append(["\x0a13. Pr�fe InternalTmr_ECU nach 61 Sekunden", ""])
    time.sleep(61)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 4, descr=" KN_Waehlhebel_ECUKnockOutTimer = 4 (wird dekrementiert)")]

    testresult.append(["\x0a 14.Setze ECUKnockout_Tmr  auf 61"])
    # testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x3D, 0x3E]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a15. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 4, descr=" KN_Waehlhebel_ECUKnockOutTimer = 4 (laufender Timer wird nicht �berschrieben)")]

    testresult.append(["\x0a16. KnockOut_Test auf 0x3 setzen*"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x03]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a17. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 4, descr=" KN_Waehlhebel_ECUKnockOutTimer = 4 (Timer wird bei auftretendem Veto nicht �berschrieben)")]

    testresult.append(["\x0a18. Setze ECUKnockOut_Tmr auf 32", ""])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x20, 0x3E]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a19. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 4, descr=" KN_Waehlhebel_ECUKnockOutTimer = 4 (Timer wird bei auftretendem Veto nicht �berschrieben)")]

    testresult.append(["\x0a20. KnockOut_Test auf 0x1 setzen*"])
    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a21. Warte auf InternalTmr_ECU == 3", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3, descr=" KN_Waehlhebel_ECUKnockOutTimer = 3")]

    testresult.append(["\x0a 22. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start = response[3]
        if ECUKnockOut_Ctr_start is not None:
            ECUKnockOut_Ctr_start = ECUKnockOut_Ctr_start
            testresult += [
                basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
        else:
            ECUKnockOut_Ctr_start = 0
            testresult += [ basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a23. KL15 einschalten "])
    hil.cl15_on__.set(1)
    testresult.append(["\x0a23.1 Schalte Senden von RX Signalen (HiL --> ECU) ein", "INFO"])
    func_nm.hil_ecu_tx_off_state("an")

    testresult.append(["\x0a24. Pr�fe ECUKnockOut_Tmr"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    ecu_tmr = None

    if response[0:3] == [98, 2, 203]:
        ecu_tmr = response[3]
        if ecu_tmr is not None:
            ecu_tmr = ecu_tmr
            testresult += [basic_tests.checkStatus(ecu_tmr, 32, descr="Pr�fe dass ECUKnockOut_Tmr == 32)")]
        else:
            ecu_tmr = 0
            testresult += [basic_tests.checkStatus(ecu_tmr, 32, descr="Pr�fe dass ECUKnockOut_Tmr == 32)")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a26. Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOutTimer", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3, descr=" KN_Waehlhebel_ECUKnockOutTimer = 3 (Restwert)")]

    testresult.append(["\x0a27. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start = response[3]
        if ECUKnockOut_Ctr_start is not None:
            ECUKnockOut_Ctr_start = ECUKnockOut_Ctr_start
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]
        else:
            ECUKnockOut_Ctr_start = 0
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start, 0, descr="Pr�fe dass ECUKnockOut_Ctr == 0x00)")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a28.Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut"])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 1, descr="KN_Waehlhebel_ECUKnockOut = 1(Veto war aktiv, keine Abschaltung)")]

    testresult.append(["\x0a29. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a30.Pr�fe KN_Waehlhebel:KN_Waehlhebel_ECUKnockOut"])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0(zur�ckgesetzt, Init)")]


    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)