# ******************************************************************************
# -*- coding: latin1 -*-
# File    : ECU_KnockOut_Daten_Datensicherung.py
# Title   :ECU KnockOut Daten Datensicherung
# Task    : Test for ECU Knockout
#
# Author  : Devangbhai Patel
# Date    : 27.09.2021
# Copyright 2021 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name       | Description
# ------------------------------------------------------------------------------
# 1.0  | 27.09.2021 | Devangbhai   | initial
# 1.1  | 12.10.2021 | Mohammed   | Rework
# 1.1  | 22.12.2021 | Devangbhai   | Rework according to test specification
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from diag_identifier import identifier_dict
import functions_common
from ttk_checks import basic_tests
import functions_gearselection
import time
import functions_nm
import os

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # Initialize functions ####################################################
    hil = testenv.getHil()
    daq = testenv.getGammaDAQ()
    func_gs = functions_gearselection.FunctionsGearSelection(testenv, hil)
    func_com = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident_KN_CTR = identifier_dict['Knockout_counter']
    diag_ident_KN_TMR = identifier_dict['Knockout_timer']
    diag_ident_KN_TEST_MODE =identifier_dict['Knockout_test_mode']
    func_nm = functions_nm.FunctionsNM(testenv)

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_267")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] Starte ECU (KL30 an, KL15 an)", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["[.] Wechsle in die Extended Session", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    testresult.append(["[.] BusKnockOut_Tmr und ECUKnockOut_Tmr auf 15 setzen"])
    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x0F, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] BusKnockOut_Ctr und ECUKnockOut_Ctr auf 0 setzen"])
    request = [0x2E] + diag_ident_KN_CTR['identifier'] + [0x00, 0x00]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.]  ECU ausschalten", ""])
    # canape_diag.disableTesterPresent()
    testenv.canape_Diagnostic = None

    # clear instances before flashing
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)

    testenv.shutdownECU()
    func_nm.hil_ecu_tx_off_state("aus")
    time.sleep(10)
    testresult.append(["\xa0 ECU einschalten", ""])
    testenv.startupECU()
    func_nm.hil_ecu_tx_off_state("an")
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    ###
    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])
    testresult.append(["\x0a 1. Setze ECUKnockOut_Tmr auf 3"])

    testresult.append(["\xa0 Change to extended session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x03, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 2. Pr�fe BusKnockOut_Tmr"])

    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_start = None
    ECUKnockoutTmr_start = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start = response[4]
        ECUKnockoutTmr_start = response[3]
        if BusKnockoutTmr_start is not None:
            BusKnockoutTmr_start = BusKnockoutTmr_start
            testresult.append(["\xa0 Gespeichere Wert f�r BusKnockoutTmr_start (Variable) f�r sp�teren Vergleich ist %s" % BusKnockoutTmr_start, "INFO"])
        else:
            BusKnockoutTmr_start = 0
            testresult.append(["\xa0 Gespeichere Wert f�r BusKnockoutTmr_start (Variable) f�r sp�teren Vergleich ist %s" % BusKnockoutTmr_start,"INFO"])

        if ECUKnockoutTmr_start is not None:
            ECUKnockoutTmr_start = ECUKnockoutTmr_start
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockoutTmr_start, "INFO"])
        else:
            ECUKnockoutTmr_start = 0
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockoutTmr_start, "INFO"])

            testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr > ECUKnockOut_Tmr"])
            testresult.append(basic_tests.compare(BusKnockoutTmr_start, '>', ECUKnockoutTmr_start, descr="Pr�fe dass BusKnockOut_Tmr > ECUKnockOut_Tmr"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 4. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start = response[3]
        if ECUKnockOut_Ctr_start is not None:
            ECUKnockOut_Ctr_start = ECUKnockOut_Ctr_start
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr_start (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockOut_Ctr_start])
        else:
            ECUKnockOut_Ctr_start = 0
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr_start (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockOut_Ctr_start])

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a5. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a6. KnockOut_Test auf 0x1 setzen*"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a8.  Pr�fe Bus State"])
    req = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    testresult.append(["Pr�fe  Bus State == Bus Sleep", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\x0a8.1 Warte 150ms"])
    time.sleep(0.150)

    testresult.append(["\x0a8.2 Schalte Senden von RX Signalen (HiL --> ECU) aus", "INFO"])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0a9. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 3, descr="KN_Waehlhebel_ECUKnockOutTimer = 3")]

    testresult.append(["\x0a10. Pr�fe InternalTmr_ECU nach 61 Sekunden", ""])
    time.sleep(61)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 2, descr="KN_Waehlhebel_ECUKnockOutTimer = 2"),
        basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0")]

    testresult.append(["\x0a11. Pr�fe InternalTmr_ECU nach 60 Sekunden", ""])
    time.sleep(60)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 1, descr="KN_Waehlhebel_ECUKnockOutTimer = 1"),
                   basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 0, descr="KN_Waehlhebel_ECUKnockOut = 0")]

    testresult.append(["\x0a 12. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_middle = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_middle = response[3]
        if ECUKnockOut_Ctr_middle is not None:
            ECUKnockOut_Ctr_middle = ECUKnockOut_Ctr_middle
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr (Variable) ist %s" % ECUKnockOut_Ctr_middle])
            testresult.append( basic_tests.compare(ECUKnockOut_Ctr_middle, '==',ECUKnockOut_Ctr_start, descr="Pr�fe dass ECUKnockOut_Ctr == ecuctr_start"))
        else:
            ECUKnockOut_Ctr_middle = 0
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr (Variable) ist %s" % ECUKnockOut_Ctr_middle])
            testresult.append( basic_tests.compare(ECUKnockOut_Ctr_middle, '==', ECUKnockOut_Ctr_start, descr="Pr�fe dass ECUKnockOut_Ctr == ecuctr_start"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a13. Warte bis InternalTmr_ECU == 0 ", ""])
    time.sleep(59.01)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 0, descr="KN_Waehlhebel_ECUKnockOutTimer = 0"),
                   basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 2, descr="KN_Waehlhebel_ECUKnockOut = 2")]

    testresult.append(["\x0a13. Warte bis Warte bis SG abgeschaltet (5sek)", ""])
    time.sleep(5)
    testresult.append(["\xa0Pr�fe Busruhe (0<I<2mA)", ""])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.0,  # 0mA
            max_value=0.002, descr="Pr�fe, dass Strom zwischen 0 und 2mA liegt"))

    time_1 = time.time()
    descr, verdict = func_gs.checkBusruhe(daq, 1)
    testresult.append([descr, verdict])
    time_2 = time.time()
    time_difference = time_2 - time_1

    testresult.append(["\x0a15 ECU ausschalten", ""])
    testenv.shutdownECU()
    testenv.canape_Diagnostic = None

    # clear instances before flashing
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)
    testresult.append(["\x0a16. Warte 1 min"])
    time.sleep(60 - time_difference)

    testresult.append(["\x0a17 ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    testresult.append(["\xa0 Schalte Senden von RX Signalen (HiL --> ECU) ein, Schalte Kl15 ein", ""])
    func_nm.hil_ecu_tx_off_state("an")

    testresult.append(["\x0a 18.  Pr�fe nichtfl�chtige Speicherung von ECUKnockOut_Tmr"])
    testresult.append(["\xa0 Change to extended session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    ECUKnockoutTmr_end = None

    if response[0:3] == [98, 2, 203]:
        ECUKnockoutTmr_end = response[3]
        if ECUKnockoutTmr_end is not None:
            ECUKnockoutTmr_end = ECUKnockoutTmr_end
            testresult.append( basic_tests.compare(ECUKnockoutTmr_start, '==',ECUKnockoutTmr_end, descr="Pr�fe dass ECUKnockOut_tmr == ecutmr_start"))
        else:
            ECUKnockoutTmr_end = 0
            testresult.append( basic_tests.compare(ECUKnockoutTmr_start, '==',ECUKnockoutTmr_end, descr="Pr�fe dass ECUKnockOut_tmr == ecutmr_start"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 19. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_end = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_end = response[3]
        if ECUKnockOut_Ctr_end is not None:
            ECUKnockOut_Ctr_end = ECUKnockOut_Ctr_end
            testresult.append(basic_tests.compare(ECUKnockOut_Ctr_end, '==',  ECUKnockOut_Ctr_start + 1, descr="Pr�fe dass ECUKnockOut_Ctr wurde inkrementiert mit 1"))
        else:
            ECUKnockOut_Ctr_end = 0
            testresult.append(basic_tests.compare(ECUKnockOut_Ctr_end, '==',ECUKnockOut_Ctr_start +1 , descr="Pr�fe dass ECUKnockOut_Ctr wurde inkrementiert mit 1"))

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 20. Pr�fe nichtfl�chtige Speicherung von InternalTmr_ECU"])
    if ECUKnockoutTmr_end is not None:
        testresult.append(basic_tests.compare(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, '==', ECUKnockoutTmr_end , descr="Pr�fe dass  InternalTmr_ECU == ECUKnockOut_Tmr"))
    else:
        testresult.append(["ECUKnockOut_Tmr kann nicht �berpr�fen", "FAILED"])

    testresult.append(["\x0a 21. Setze ECUKnockOut_Tmr auf 1"])
    testresult.append(["\xa0 Change to extended session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    request = [0x2E] + diag_ident_KN_TMR['identifier'] + [0x01, 0x0F]
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["�berpr�fen, dass Request positiv beantwortet wird", "INFO"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 22. Pr�fe BusKnockOut_Tmr"])

    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    BusKnockoutTmr_start_1 = None
    ECUKnockoutTmr_start_1 = None

    if response[0:3] == [98, 2, 203]:
        BusKnockoutTmr_start_1 = response[4]
        ECUKnockoutTmr_start_1 = response[3]
        if BusKnockoutTmr_start_1 is not None:
            BusKnockoutTmr_start_1 = BusKnockoutTmr_start_1
            testresult.append(["\xa0 Gespeichere Wert f�r BusKnockoutTmr_start(teil2)(Variable) f�r sp�teren Vergleich ist %s" % BusKnockoutTmr_start_1, "INFO"])
        else:
            BusKnockoutTmr_start_1 = 0
            testresult.append(["\xa0 Gespeichere Wert f�r BusKnockoutTmr_start (teil2) (Variable) f�r sp�teren Vergleich ist %s" % BusKnockoutTmr_start_1, "INFO"])

        if ECUKnockoutTmr_start_1 is not None:
            ECUKnockoutTmr_start_1 = ECUKnockoutTmr_start_1
            testresult.append(["\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start(teil2) (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockoutTmr_start_1, "INFO"])
        else:
            ECUKnockoutTmr_start_1 = 0
            testresult.append([ "\xa0 Gespeichere Wert f�r ECUKnockoutTmr_start(teil2) (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockoutTmr_start_1, "INFO"])

            testresult.append(["\xa0 Pr�fe BusKnockOut_Tmr > ECUKnockOut_Tmr"])
            testresult.append(basic_tests.compare(BusKnockoutTmr_start, '>', ECUKnockoutTmr_start_1, descr="Pr�fe dass BusKnockOut_Tmr > ECUKnockOut_Tmr"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 24.  Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start_1 = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start_1 = response[3]
        if ECUKnockOut_Ctr_start_1 is not None:
            ECUKnockOut_Ctr_start_1 = ECUKnockOut_Ctr_start_1
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr_start (teil2) (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockOut_Ctr_start_1])
        else:
            ECUKnockOut_Ctr_start_1 = 0
            testresult.append(["\xa0 Gespeichere Wert f�r ecuctr_start (teil2) (Variable) f�r sp�teren Vergleich ist %s" % ECUKnockOut_Ctr_start_1])

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a25. KL15 ausschalten "])
    hil.cl15_on__.set(0)

    testresult.append(["\x0a26. KnockOut_Test auf 0x1 setzen*"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    testresult.append(["\xa0 Erfolgreichen Security Access durchf�hren", "INFO"])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    request = [0x2E] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Pr�fe Positive Response: 0x6E 09F3 ist"])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a28.  Pr�fe Bus State"])
    req = [0x22] + diag_ident_KN_TEST_MODE['identifier']
    [response, result] = canape_diag.sendDiagRequest(req)
    testresult.append(result)

    expected_resp = [0x62] + diag_ident_KN_TEST_MODE['identifier'] + [0x01]
    testresult.append(["Pr�fe  Bus State == Bus Sleep", ""])
    testresult.append(canape_diag.checkResponse(response, expected_resp))

    testresult.append(["\x0a28.1 Warte 150ms"])
    time.sleep(0.150)

    testresult.append(["\x0a28.2 Schalte Senden von RX Signalen (HiL --> ECU) aus", "INFO"])
    func_nm.hil_ecu_tx_off_state("aus")

    testresult.append(["\x0a29. Pr�fe InternalTmr_ECU", ""])
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 1, descr="KN_Waehlhebel_ECUKnockOutTimer = 1")]

    testresult.append(["\x0a 30.  Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_start_2 = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_start_2 = response[3]
        if ECUKnockOut_Ctr_start_2 is not None:
            ECUKnockOut_Ctr_start_2 = ECUKnockOut_Ctr_start_2
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start_2, ECUKnockOut_Ctr_start_1,
                                                   descr="Pr�fe dass ECUKnockOut_Ctr = ecuctr_start (teil2)")]
        else:
            ECUKnockOut_Ctr_start_2 = 0
            testresult += [basic_tests.checkStatus(ECUKnockOut_Ctr_start_2, ECUKnockOut_Ctr_start_1,
                                                   descr="Pr�fe dass ECUKnockOut_Ctr = ecuctr_start (teil2)")]

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a31. Pr�fe InternalTmr_ECU nach 61 Sekunden", ""])
    time.sleep(60.01)
    testresult += [basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, 0, descr="KN_Waehlhebel_ECUKnockOutTimer = 0"),
                   basic_tests.checkStatus(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOut__value, 2, descr="KN_Waehlhebel_ECUKnockOut = 2")]

    testresult.append(["\x0a32. Warte bis Warte bis SG abgeschaltet (5sek)", ""])
    time.sleep(5)
    testresult.append(["\xa0Pr�fe Busruhe (0<I<2mA)", ""])
    testresult.append(
        basic_tests.checkRange(
            value=hil.cc_mon__A.get(),
            min_value=0.0,  # 0mA
            max_value=0.002, descr="Pr�fe, dass Strom zwischen 0 und 2mA liegt"))

    time_1 = time.time()
    descr, verdict = func_gs.checkBusruhe(daq, 1)
    testresult.append([descr, verdict])
    time_2 = time.time()
    time_difference = time_2 - time_1

    testresult.append(["\x0a15 ECU ausschalten", ""])
    testenv.shutdownECU()
    testenv.canape_Diagnostic = None

    # clear instances before flashing
    testenv.asap3 = None
    testenv.canape_Diagnostic = None
    del (canape_diag)
    testresult.append(["\x0a33. Warte 1 min"])
    time.sleep(60 - time_difference)

    testresult.append(["\x0a34 ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()
    # hil.ISOx_Waehlhebel_Req_FD__period.setState('an')

    testresult.append(["\xa0 Schalte Senden von RX Signalen (HiL --> ECU) ein, Schalte Kl15 ein", ""])
    func_nm.hil_ecu_tx_off_state("an")

    testresult.append(["\x0a 35.  Pr�fe nichtfl�chtige Speicherung von ECUKnockOut_Tmr"])
    testresult.append(["\xa0 Change to extended session", "INFO"])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    request = [0x22] + diag_ident_KN_TMR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    testresult.append(["Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))
    ECUKnockoutTmr_end_1 = None

    if response[0:3] == [98, 2, 203]:
        ECUKnockoutTmr_end_1 = response[3]
        if ECUKnockoutTmr_end_1 is not None:
            ECUKnockoutTmr_end_1 = ECUKnockoutTmr_end_1
            testresult.append(basic_tests.compare(ECUKnockoutTmr_start_1, '==', ECUKnockoutTmr_end_1,
                                                  descr="Pr�fe dass ECUKnockOut_tmr == ecutmr_start"))
        else:
            ECUKnockoutTmr_end_1 = 0
            testresult.append(basic_tests.compare(ECUKnockoutTmr_start, '==', ECUKnockoutTmr_end_1,
                                                  descr="Pr�fe dass ECUKnockOut_tmr == ecutmr_start"))
    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 36. Pr�fe ECUKnockOut_Ctr"])
    request = [0x22] + diag_ident_KN_CTR['identifier']
    response, result = canape_diag.sendDiagRequest(request)
    testresult.append(result)
    ECUKnockOut_Ctr_end_1 = None

    if response[0:3] == [98, 2, 202]:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))
        ECUKnockOut_Ctr_end_1 = response[3]
        if ECUKnockOut_Ctr_end_1 is not None:
            ECUKnockOut_Ctr_end_1 = ECUKnockOut_Ctr_end_1
            testresult.append(basic_tests.compare(ECUKnockOut_Ctr_end_1, '==', ECUKnockOut_Ctr_start_1 + 1,
                                                  descr="Pr�fe dass ECUKnockOut_Ctr wurde inkrementiert mit 1"))
        else:
            ECUKnockOut_Ctr_end_1 = 0
            testresult.append(basic_tests.compare(ECUKnockOut_Ctr_end_1, '==', ECUKnockOut_Ctr_start_1 + 1,
                                                  descr="Pr�fe dass ECUKnockOut_Ctr wurde inkrementiert mit 1"))

    else:
        testresult.append(["Auf positive Response �berpr�fen", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a 37. Pr�fe nichtfl�chtige Speicherung von InternalTmr_ECU"])
    if ECUKnockoutTmr_end is not None:
        testresult.append( basic_tests.compare(hil.KN_Waehlhebel__KN_Waehlhebel_ECUKnockOutTimer__value, '==', ECUKnockoutTmr_end_1,
                                descr="Pr�fe dass  InternalTmr_ECU == ECUKnockOut_Tmr"))
    else:
        testresult.append(["ECUKnockOut_Tmr kann nicht �berpr�fen", "FAILED"])

    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    # cleanup
    hil = None

finally:
    testenv.breakdown(ecu_shutdown=False)