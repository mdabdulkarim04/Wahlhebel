#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Diagnose_Bootloader_TP_blocksize.py
# Task    : Test for Diagnosejob 0x22 0x0410 und 0x2E 0x0410
#
# Author  : An3Neumann
# Date    : 18.06.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 18.06.2021 | An3Neumann | initial
# 1.1  | 19.08.2021 | Mohammed | Added Ticket Id
# 1.2  | 15.12.2021 | Mohammed | TestStep line 67 and 68 corrected
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import ResponseDictionaries
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
from ttk_checks import basic_tests
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_144")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)
    rd = ResponseDictionaries()

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Bootloader TP Blocksize']

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["[+] Lese aktuelle Diagnose Session aus", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    #testresult.append(["\xa0Auf negative Response �berpr�fen", ""])
   # testresult.append(canape_diag.checkNegativeResponse(response, [0x22], 0x7F, ticket_id='Fehler Id:EGA-PRM-25'))
    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request, ticket_id='Fehler Id:EGA-PRM-25'))

    testresult.append(["[.] '%s' schreiben: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x2E] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf negative Response �berpr�fen", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x2E], 0x7F))

    # Wechsel in Extended Session: 0x1003
    testresult.append(["[.] In die Extended Session wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    time.sleep(1)

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["[.] Lese aktuelle Diagnose Session aus", ""])
    testresult.extend(canape_diag.checkDiagSession('extended'))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] '%s' schreiben: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x2E] + diag_ident['identifier'] + [0x1F]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\xa0Inhalt der Response �berpr�fen", ""])
    exp_response = [0x62] + diag_ident['identifier'] + [0x1F]
    testresult.append(canape_diag.checkResponse(response, exp_response))

    # Wechsel in Programming Session: 0x1002
    testresult.append(["[.] In die Programming Session wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('programming'))
    time.sleep(1)

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["[.] Lese aktuelle Diagnose Session aus", ""])
    testresult.extend(canape_diag.checkDiagSession('programming'))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\xa0Inhalt der Response �berpr�fen", ""])
    exp_response = [0x62] + diag_ident['identifier'] + [0x0F] ## Added 0x0F to 0x1F
    testresult.append(canape_diag.checkResponse(response, exp_response, ticket_id='Fehler Id:EGA-PRM-25'))

    testresult.append(["[.] '%s' schreiben: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x2E] + diag_ident['identifier'] + [0xFF]
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\xa0Inhalt der Response �berpr�fen", ""])
    exp_response = [0x62] + diag_ident['identifier'] + [0xFF]
    testresult.append(canape_diag.checkResponse(response, exp_response, ticket_id='Fehler Id:EGA-PRM-25'))

    # Wechsel in Programming Session: 0x1001
    testresult.append(["[.] In die Default Session wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))
    time.sleep(1)

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["[.] Lese aktuelle Diagnose Session aus", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    # Wechsel in Extended Session: 0x1003
    testresult.append(["[.] In die Extended Session wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    time.sleep(1)

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["[.] Lese aktuelle Diagnose Session aus", ""])
    testresult.extend(canape_diag.checkDiagSession('extended'))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\xa0Inhalt der Response �berpr�fen", ""])
    exp_response = [0x62] + diag_ident['identifier'] + diag_ident['expected_response']
    testresult.append(canape_diag.checkResponse(response, exp_response,ticket_id='Fehler Id:EGA-PRM-25'))


    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    
    # cleanup #################################################################
    hil = None
    
finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################
    
print "Done."
