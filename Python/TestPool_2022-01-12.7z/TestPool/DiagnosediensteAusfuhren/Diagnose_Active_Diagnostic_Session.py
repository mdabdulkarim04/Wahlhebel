# ******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_Active_Diagnostic_Session.py
# Title   : Diagnose Active Diagnostic Session
# Task    : A minimal "Diagnosesessions Active Diagnostic Session!" test script
#
# Author  : Mohammed Abdul Karim
# Date    : 23.09.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 23.09.2021 | Mohammed  | initial
# 1.1  | 12.10.2021 | Mohammed  | Added TestSpec ID
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_248")

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # 1./4. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 5./9. Wechsel in Extended Session: 0x1003
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('extended'))

    # 10./14. Wechsel in die factory_mode Session: 0x1060
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('factory_mode'))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print ("Done.")
