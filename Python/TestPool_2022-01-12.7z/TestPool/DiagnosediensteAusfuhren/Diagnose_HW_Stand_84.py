#******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_HW_Stand_84.py
# Title   : Diagnose HW Stand
# Task    : A minimal "Diagnose_HW_Stand!" test script
#
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name     | Description
#------------------------------------------------------------------------------
# 1.0  | 16.02.2021 | Abdul Karim  | initial
# 1.1  | 28.04.2021 | Abdul Karim  | added Default and Extended Session
# 1.2  | 18.05.2021 | StengerS     | automated test
# 1.3  | 28.05.2021 | StengerS     | read out HW version from iTestStudio
# 1.4  | 31.05.2021 | StengerS     | added info for not implemented jobs
# 1.5  | 06.09.2021 | Mohammed     | changed info SW name to HW
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
import os
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_84")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    test_dict = {
                1: identifier_dict['VW ECU Hardware Number'],
                2: identifier_dict['System Supplier ECU Hardware Number'],
                3: identifier_dict['System Supplier ECU Hardware Version Number'],
                4: identifier_dict['VW ECU Hardware Version Number']
                }

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])
    testresult.append(["[+0]", ""])
    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" %(test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

        testresult.append(["\xa0Datenl�nge �berpr�fen", ""])
        testresult.append(canape_diag.checkDataLength(response, test_data['exp_data_length']))

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        if test_data['name'] == 'VW ECU Hardware Version Number':

            try:
                hw_version = ''.join(chr(i) for i in response[3:])
            except:
                testresult.append(["Response cannot be decoded (ASCII): %s" % response, "FAILED"])

            current_series = os.getenv("ITESTSTUDIO_CURRENT_SER", None)
            if current_series:
                exp_hw_version = func_common.getVersionFromiTestStudio(current_series, 'HARDWAREVERSION')
                testresult.append(["Read version from %s: %s" % (current_series, str(exp_hw_version)), ""])

                if hw_version == exp_hw_version:
                    descr = ("The version read out is the same as that from the test series\n"
                            "Read out HW version: %s\n"
                            "HW Version from test series: %s" %(str(hw_version), str(exp_hw_version)))
                    verdict = "PASSED"
                else:
                    descr = ("The version read out does NOT match the version from the test series\n"
                            "Read out HW version: %s\n"
                            "HW Version from test series: %s" %(str(hw_version), str(exp_hw_version)))
                    verdict = "FAILED"

            else:
                exp_hw_version = test_data['expected_response']
                exp_hw_version = ''.join(chr(i) for i in exp_hw_version)

                if hw_version == exp_hw_version:
                    descr = ("The version read out is as expected\n"
                            "Read out HW version: %s\n"
                            "HW Version from diag_identifier: %s" %(str(hw_version), str(exp_hw_version)))
                    verdict = "PASSED"
                else:
                    descr = ("The version read out is NOT as expected\n"
                            "Read out HW version: %s\n"
                            "HW Version from diag_identifier: %s" %(str(hw_version), str(exp_hw_version)))
                    verdict = "FAILED"

            testresult.append([descr, verdict])

        else:
            expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']
            testresult.append(canape_diag.checkResponse(response, expected_response))


    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del(testenv)
    # #########################################################################

print "Done."
