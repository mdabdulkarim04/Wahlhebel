#******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_ECUReset_HardReset.py
# Title   : Diagnose ECUReset HardReset
# Task    : Tests if ECUReset with subfunction HardReset is working
#
# Author  : S. Stenger
# Date    : 02.06.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name         | Description
#------------------------------------------------------------------------------
# 1.0  | 02.06.2021 | StengerS     | initial
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_132")


    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()


    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])
    testresult.append(["[+0]", ""])

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2./3. Wechsel in Extended Session: 0x1003
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # 4./5. Wechsel in die Programming Session: 0x1002
    testresult.extend(canape_diag.changeAndCheckDiagSession('programming'))

    # 6. ECU Reset
    testresult.append(["[.] Programming Session: ECU Reset mit Subfunktion 'HardReset' durchf�hren", ""])
    result = canape_diag.performEcuReset(reset_type='HardReset', pos_response=False, exp_nrc = 0x78)
    testresult.extend(result)

   # request = [0x11, 0x01]
   # [response, result] = canape_diag.sendDiagRequest(request)
   # testresult.append(result)

  #  expected_resp = [0x51, 0x01]
   # testresult.append(canape_diag.checkResponse(response, expected_resp))

    # 7. Warten
    testresult.append(["[.] 2 Sekunden warten", ""])
    time.sleep(2)

    # 8. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('default'))
    
    # 9. ECU Reset
    testresult.append(["[.] Default Session: ECU Reset mit Subfunktion 'HardReset' durchf�hren", ""])
    result = canape_diag.performEcuReset(reset_type='HardReset', pos_response=False, exp_nrc = 0x7E)
    testresult.extend(result)

    # 10. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 11./12. Wechsel in Extended Session: 0x1003
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    
    # 13. ECU Reset
    testresult.append(["[.] Extended Session: ECU Reset mit Subfunktion 'HardReset' durchf�hren", ""])
    result = canape_diag.performEcuReset(reset_type='HardReset', pos_response=False, exp_nrc = 0x7E)
    testresult.extend(result)

    # 14. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('extended'))

    # 15./16. Wechsel in Default Session: 0x1001
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))
    

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del(testenv)
    # #########################################################################

print "Done."
