#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Diagnose_System_Supplier_Identifier.py
# Task    : Test for Diagnosejob 0x22 0xF18A
#
# Author  : An3Neumann
# Date    : 28.06.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 28.06.2021 | An3Neumann | initial
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_159")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['System Supplier Identifier']

    request_dict = {
        1: {
            'identifier': [0x10, 0x01],
            'name': 'default',
            'expected_response': [0x50, 0x01, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3},
        2: {
            'identifier': [0x10, 0x02],
            'name': 'programming',
            'expected_response': [0x50, 0x02, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3,  # Bytes
        },
        3: {
            'identifier': [0x10, 0x03],
            'name': 'extended',
            'expected_response': [0x50, 0x03, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3
        },
    }

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a1. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    #testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    testresult.append(["\x0a2. Diagnose Request schicken: 0x22F18A (System_Supplier_Identifier)", ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\x0a3. Positive Response pr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a4. Pr�fe L�nge der Response", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length']))

    testresult.append(["\x0a5. Inhalt Pr�fen", ""])
    exp_response = [0x62] + diag_ident['identifier'] + diag_ident['expected_response']
    testresult.append(canape_diag.checkResponse(response, exp_response))

    # Wechsel in Extended Session: 0x1003
    testresult.append(["\x0a6. Wechsel in Extended Session: 0x1003", ""])
    for test in request_dict:
        test_data = request_dict[test]
        if test_data['name'] == 'extended':
            request = test_data['identifier']
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)
            testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
            testresult.append(canape_diag.checkPositiveResponse(response, request, job_length=2))
    #time.sleep(1)

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a7. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('extended'))

    #testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    testresult.append(["\x0a8. Diagnose Request schicken: 0x22F18A (System_Supplier_Identifier)", ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\x0a9. Positive Response pr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["\x0a10. Pr�fe L�nge der Response", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length']))

    testresult.append(["\x0a11. Inhalt Pr�fen", ""])
    exp_response = [0x62] + diag_ident['identifier'] + diag_ident['expected_response']
    testresult.append(canape_diag.checkResponse(response, exp_response))

    # Wechsel in Programming Session: 0x1002
    testresult.append(["[.] In die Programming Session wechseln", ""])
    # 12. Wechsel in die Programming Session: 0x1002
    testresult.append(["\xa012. Wechsel in die Programming Session: 0x1002", ""])
    for test in request_dict:
        test_data = request_dict[test]
        if test_data['name'] == 'programming':
            request = test_data['identifier']
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)
            testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
            testresult.append(canape_diag.checkPositiveResponse(response, request, job_length=2))

    # Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\x0a13. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('programming'))

    #testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    testresult.append(["\x0a14. Diagnose Request schicken: 0x22F18A (System_Supplier_Identifier)", ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf negative Response �berpr�fen", ""])
    testresult.append(canape_diag.checkNegativeResponse(response, [0x22], 0x31, ticket_id='Fehler Id:EGA-PRM-30'))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
