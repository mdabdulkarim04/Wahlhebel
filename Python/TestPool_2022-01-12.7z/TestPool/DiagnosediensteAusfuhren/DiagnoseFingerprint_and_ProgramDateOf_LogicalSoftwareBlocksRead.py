# ******************************************************************************
# -*- coding: latin-1 -*-
# File    : DiagnoseFingerprint_and_ProgramDateOf_LogicalSoftwareBlocksRead.py
# Task    : Diagnosejob 0x22 0xF15B
#
# Author  : An3Neumann
# Date    : 21.06.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name      | Description
# ------------------------------------------------------------------------------
# 1.0  | 21.06.2021 | An3Neumann | initial  
# ******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
from ttk_checks import basic_tests
import data_common as dc
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_147")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)
    write_value = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09]
    number_softwareblocks_n = 1
    programming_date = dc.programming_date
    vw_device_number = 123465  # 0 - 1F FFFF (2097151)
    importer_number = 12  # 0 - 3FF (1023)
    workshop_number = 12312  # 0 - 1 FFFF (131071)
    programming_state = 0x00  # correct

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Fingerprint And Programming Date Of Logical Software Blocks']

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    testresult.append(["[+] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["[.] �berpr�fen, dass Request positiv beantwortet wird", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] Datenl�nge �berpr�fen", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'] * number_softwareblocks_n))

    testresult.append(["[.] Pr�fe Inhalt der Response", ""])
    response_content = response[3:]

    testresult.append(["[+] Pr�fe Byte 0 (Jahr)", ""])
    year = int(str(programming_date[0]), 16) if len(str(programming_date[0])) == 2 else int(
        str(programming_date[0])[2:], 16)
    testresult.append(
        basic_tests.checkStatus(
            current_status=response_content[0],
            nominal_status=year,
            descr="Pr�fe, dass Programming Date - Jahr korrekt ist: %s (0x%2X)" % (year, year)
        ))

    testresult.append(["[.] Pr�fe Byte 1 (Monat)", ""])
    month = int(str(programming_date[1]), 16)
    testresult.append(
        basic_tests.checkStatus(
            current_status=response_content[1],
            nominal_status=month,
            descr="Pr�fe, dass Programming Date - Monat korrekt ist: %s (0x%2X)" % (month, month)
        ))

    testresult.append(["[.] Pr�fe Byte 2 (Tag)", ""])
    day = year = int(str(programming_date[2]), 16)
    testresult.append(
        basic_tests.checkStatus(
            current_status=response_content[2],
            nominal_status=day,
            descr="Pr�fe, dass Programming Date - Tag korrekt ist: %s (0x%2X)" % (day, day)
        ))

    testresult.append(["[.] Pr�fe Byte 3 - 8", ""])
    bin_content = map(bin, response_content[3:9])
    bin_value = ""
    for bc in bin_content:
        value = bc[2:]
        while len(value) < 8: value = "0" + value
        bin_value += value

    testresult.append(["[+] Pr�fe Bit 0 - 20 (VW Device Number)", ""])
    vw_device_number_bit = int(bin_value[:21], 2)
    testresult.append(
        basic_tests.checkStatus(
            current_status=vw_device_number_bit,
            nominal_status=vw_device_number,
            descr="Pr�fe, dass VW Device Number korrekt ist"
        ))

    testresult.append(["[.] Pr�fe Bit 21 - 30 (Importer Number)", ""])
    importer_number_bit = int(bin_value[21:31], 2)
    testresult.append(
        basic_tests.checkStatus(
            current_status=importer_number_bit,
            nominal_status=importer_number,
            descr="Pr�fe, dass Importer Number korrekt ist"
        ))

    testresult.append(["[.] Pr�fe Bit 31 - 48 (Workshop Number)", ""])
    workshop_number_bit = int(bin_value[31:], 2)
    testresult.append(
        basic_tests.checkStatus(
            current_status=workshop_number_bit,
            nominal_status=workshop_number,
            descr="Pr�fe, dass Workshop Number korrekt ist"
        ))

    testresult.append(["[-] Pr�fe Byte 9 (Programming State)", ""])
    testresult.append(["[-0]"])
    testresult.append(
        basic_tests.checkStatus(
            current_status=response_content[9],
            nominal_status=programming_state,
            descr="Pr�fe, dass Programming State korrekt ist"
        ))

    # SCHREIBEN NEUER WERTE UND ANSCHLIESSEND LESEN
    # Wechsel in Extended Session: 0x1003
    testresult.append(["[.] In die Extended Session wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))
    time.sleep(1)

    # Wechsel in Programming Session: 0x1002
    testresult.append(["[.] In die Programming Session wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('programming'))
    time.sleep(1)

    # Security Access
    testresult.append(["[.] Erfolgreichen Security Access durchf�hren", ""])
    seed_1, key_1, result = canape_diag.performSecurityAccess()
    testresult.extend(result)

    testresult.append(["[.] '%s' schreiben: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x2E] + diag_ident['identifier'] + write_value
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["\xa0Auf positive Response �berpr�fen", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] '%s' auslesen: %s" % (diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["[.] �berpr�fen, dass Request positiv beantwortet wird", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] Datenl�nge �berpr�fen", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'] * number_softwareblocks_n))

    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()

    # cleanup #################################################################
    hil = None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

print "Done."
