#******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_Knockout.py
# Title   : Diagnose Knockout
# Task    : Test for reading the standalone mode and status
#
# Author  : S. Stenger
# Date    : 25.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name         | Description
#------------------------------------------------------------------------------
# 1.0  | 25.05.2021 | StengerS     | initial
# 1.1  | 25.06.2021 | StengerS     | added write jobs
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_128")

    # Initialize functions ####################################################
    hil = testenv.getHil()

    # Initialize variables ####################################################
    test_dict = {
                1: identifier_dict['Knockout_counter'],
                2: identifier_dict['Knockout_timer'],
                3: identifier_dict['Knockout_test_mode']
                }

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])
    testresult.append(["[+0]", ""])
    testresult.append(["[.] In Default Session auslesen", ""])
    testresult.append(["[+0]", ""])
    response_dict = {}
    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" %(test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

        testresult.append(["\xa0Datenl�nge �berpr�fen", ""])
        testresult.append(canape_diag.checkDataLength(response, test_data['exp_data_length']))

        if test_data['name'] == 'Knockout_timer':
            testresult.append(["\xa0BusKnockOut_Tmr_NVEM auswerten: aktiv", ""])
            testresult.append(canape_diag.checkResponseBitMask(response, 'XXXXXX1XXXXXXXXX'))

        if len(response) > 3:
            response_dict[test_data['name']] = response[3:]
            testresult.append(["\xa0Ausgelesener %s: %s" % (test_data['name'], response[3:]), ""])
        else:
            testresult.append(["Unerwartete Response! Folgende Tests davon betroffen!", "FAILED"])

    testresult.append(["[-] Versuchen in Default, Extended und in Programming Session Anpasswerte zu schreiben", ""])
    testresult.append(["[+0]", ""])

    request_counter = [0x2E, 0x02, 0xCA] + response_dict['Knockout_counter']
    request_timer = [0x2E, 0x02, 0xCB] + response_dict['Knockout_timer']
    request_testmode = [0x2E, 0x09, 0xF3] + response_dict['Knockout_test_mode']

    for session in ['default', 'extended', 'programming']:

        testresult.append(["[.] Schreiben in '%s session' �berpr�fen" % session, ""])
        testresult.extend(canape_diag.changeAndCheckDiagSession(session))

        # set knockout counter
        testresult.append(["\xa0 Knockout Counter schreiben und auf negative Response pr�fen", ""])
        [response, result] = canape_diag.sendDiagRequest(request_counter)
        testresult.append(result)
        testresult.append(canape_diag.checkNegativeResponse(response, request_counter, 0x7F))

        # set knockout timer
        testresult.append(["\xa0 Knockout Timer schreiben und auf negative Response pr�fen", ""])
        [response, result] = canape_diag.sendDiagRequest(request_timer)
        testresult.append(result)
        testresult.append(canape_diag.checkNegativeResponse(response, request_timer, 0x7F))

        # set knockout testmode
        testresult.append(["\xa0 Knockout Testmode schreiben und auf negative Response pr�fen", ""])
        [response, result] = canape_diag.sendDiagRequest(request_testmode)
        testresult.append(result)
        testresult.append(canape_diag.checkNegativeResponse(response, request_testmode, 0x7F))

    testresult.append(["[-] Anpasswerte im 'factory mode' schreiben", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    # ToDo: get Security Access
    testresult.append(["Security Access noch nicht umgesetzt", "FAILED"])

    request_counter = [0x2E, 0x02, 0xCA] + [0xC8, 0xC8]
    request_timer = [0x2E, 0x02, 0xCB] + [0xF2, 0xF0]

    # set knockout counter
    testresult.append(["\xa0 Knockout Counter schreiben und auf positive Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_counter)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x6E, 0x02, 0xCA]))

    # set knockout timer
    testresult.append(["\xa0 Knockout Timer schreiben und auf positive Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_timer)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x6E, 0x02, 0xCB]))

    testresult.append(["[.] Anpasswerte auslesen", ""])
    # read knockout counter
    testresult.append(["\xa0 Knockout Counter lesen und auf korrekte Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest([0x22, 0x02, 0xCA])
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x62, 0x02, 0xCA, 0xC8, 0xC8], ticket_id='Fehler Id:EGA-PRM-21'))

    # read knockout timer
    testresult.append(["\xa0 Knockout Timer lesen und auf korrekte Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest([0x22, 0x02, 0xCB])
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x62, 0x02, 0xCB, 0xF2, 0xF0]))

    testresult.append(["[.] Versuchen, ung�ltigen Wert f�r den Timer zu schreiben (< Min-Wert)", ""])

    testresult.append(["[+] ECUKnockOut_Tmr auf 0dez setzen", ""])
    request_timer = [0x2E, 0x02, 0xCB] + [0xF2, 0x00]

    # set knockout timer
    testresult.append(["\xa0 Knockout Timer schreiben und auf negative Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_timer)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request_timer, 0x31)) # NRC tbc

    testresult.append(["[.] BusKnockOut_Tmr auf 14dez setzen", ""])
    request_timer = [0x2E, 0x02, 0xCB] + [0x3A, 0xF0] # 0x3A = 0011 1010 = 14 dez and BusKnockOut_Tmr_NVEM = 1

    # set knockout timer
    testresult.append(["\xa0 Knockout Timer schreiben und auf negative Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_timer)
    testresult.append(result)
    testresult.append(canape_diag.checkNegativeResponse(response, request_timer, 0x31, ticket_id='Fehler Id:EGA-PRM-21'))  # NRC tbc


    testresult.append(["[-] Anpasswerte wieder auf vorherige Werte setzen", ""])

    request_counter = [0x2E, 0x02, 0xCA] + response_dict['Knockout_counter'] # [0x03, 0x30]
    request_timer = [0x2E, 0x02, 0xCB] + response_dict['Knockout_timer'] # [0x0F, 0x0F]

    # set knockout counter
    testresult.append(["\xa0 Knockout Counter schreiben und auf positive Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_counter)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x6E, 0x02, 0xCA]))

    # set knockout timer
    testresult.append(["\xa0 Knockout Timer schreiben und auf positive Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_timer)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x6E, 0x02, 0xCB]))

    testresult.append(["[.] Anpasswerte auslesen", ""])
    # read knockout counter
    testresult.append(["\xa0 Knockout Counter lesen und auf korrekte Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest([0x22, 0x02, 0xCA])
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x62, 0x02, 0xCA] + response_dict['Knockout_counter'], ticket_id='Fehler Id:EGA-PRM-21')) # [0x03, 0x30]

    # read knockout timer
    testresult.append(["\xa0 Knockout Timer lesen und auf korrekte Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest([0x22, 0x02, 0xCB])
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x62, 0x02, 0xCB] + response_dict['Knockout_timer'])) # [0x0F, 0x0F]


    testresult.append(["[.] Test Mode schreiben (1) und lesen", ""])
    request_testmode = [0x2E, 0x09, 0xF3] + [0x01]
    # set knockout testmode
    testresult.append(["\xa0 Knockout Testmode schreiben und auf positive Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_testmode)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x6E, 0x09, 0xF3]))

    # read knockout testmode
    testresult.append(["\xa0 Knockout Testmode lesen und auf korrekte Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest([0x22, 0x09, 0xF3])
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x62, 0x09, 0xF3, 0x01]))

    testresult.append(["[.] KL15 Wechsel durchf�hren: Test Mode muss danach wieder 0 sein", ""])
    testresult.append(["Setze KL15 auf 0", "INFO"])
    hil.cl15_on__.set(0)
    testresult.append(["Schalte Senden von empfangenen Signalen aus (HiL -> ECU)", "INFO"])
    hil.can0_HIL__HIL_TX__enable.set(0)
    time.sleep(1)
    testresult.append(["Setze KL15 auf 1", "INFO"])
    hil.cl15_on__.set(1)
    testresult.append(["Schalte Senden von empfangenen Signalen an (HiL -> ECU)", "INFO"])
    hil.can0_HIL__HIL_TX__enable.set(1)
    time.sleep(1)

    # read knockout testmode
    testresult.append(["\xa0 Knockout Testmode lesen und auf korrekte Response pr�fen", ""])
    [response, result] = canape_diag.sendDiagRequest([0x22, 0x09, 0xF3])
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, [0x62, 0x09, 0xF3, 0x00]))


    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del(testenv)
    # #########################################################################

print "Done."
