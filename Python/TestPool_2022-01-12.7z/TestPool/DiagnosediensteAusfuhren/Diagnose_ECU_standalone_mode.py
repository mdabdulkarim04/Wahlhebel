# ******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_ECU_standalone_mode.py
# Title   : Diagnose ECU standalone mode
# Task    : Test for reading the standalone mode and status
#
# Author  : S. Stenger
# Date    : 25.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name         | Description
# ------------------------------------------------------------------------------
# 1.0  | 25.05.2021 | StengerS     | initial
# 1.1  | 31.05.2021 | StengerS     | added info for not implemented jobs
# 1.2  | 22.06.2021 | StengerS     | added write jobs
# 1.3  | 22.06.2021 | Mohammed     | added Ticket ID
# ******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import time

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_129")

    # Initialize variables ####################################################
    test_dict = {
        1: identifier_dict['Status_ECU_Standalone-Mode'],
        2: identifier_dict['ECU_standalone_mode_1'],
        3: identifier_dict['ECU_standalone_mode_2']
    }
    request_defined_1 = [0x2E, 0xC1, 0x10, 0xBD, 0xDB, 0x6B, 0x3A]
    request_defined_2 = [0x2E, 0xC1, 0x11, 0x42, 0x24, 0x94, 0xC5]
    request_undefined_1 = [0x2E, 0xC1, 0x10, 0x11, 0x22, 0x33, 0x44]
    request_undefined_2 = [0x2E, 0xC1, 0x11, 0x11, 0x22, 0x33, 0x44]
    expected_response_1 = [0x6E, 0xC1, 0x10]
    expected_response_2 = [0x6E, 0xC1, 0x11]

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s" % testenv.script_name.split('.py')[0], ""])

    # TEIL 1 ##################################################################
    testresult.append(["[+] Funktionstest", ""])
    testresult.append(["[+0]", ""])

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

        testresult.append(["\xa0Datenl�nge �berpr�fen", ""])
        testresult.append(canape_diag.checkDataLength(response, test_data['exp_data_length']))

    testresult.append(["[-] �berpr�fen, dass Anpasskan�le in 'default session', 'extended session' und in "
                       "'programming session' nicht geschrieben werden k�nnen", ""])
    for session in ['default', 'extended', 'programming']:
        testresult.extend(canape_diag.changeAndCheckDiagSession(session))
        [response, result] = canape_diag.sendDiagRequest(request_undefined_1)
        testresult.append(result)
        testresult.append(canape_diag.checkNegativeResponse(response, request_undefined_1, 0x7F)) ## Added Ticket ID
        [response, result] = canape_diag.sendDiagRequest(request_undefined_2)
        testresult.append(result)
        testresult.append(canape_diag.checkNegativeResponse(response, request_undefined_2, 0x7F,ticket_id='Fehler Id:EGA-PRM-9')) ## Added Ticket ID
        [response, result] = canape_diag.sendDiagRequest(request_undefined_2)

    # TEIL 2 ##################################################################
    testresult.append(["[.] ECU auf 'Standalone inaktiv' setzen ", ""])
    testresult.append(["[+] �ber 'default session' in 'factory mode' wechseln", ""])
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))
    testresult.extend(canape_diag.changeAndCheckDiagSession('factory_mode'))
    # ToDo: get Security Access
    testresult.append(["Security Access noch nicht umgesetzt", "FAILED"])

    testresult.append(["[.] Anpasskanal 1 und 2 auf 'undefinierte' Werte setzen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_undefined_1)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_1))
    [response, result] = canape_diag.sendDiagRequest(request_undefined_2)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_2))

    testresult.append(["[.] Status und Anpasskan�le �berpr�fen", ""])
    testresult.append(["[+0]", ""])

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']['inactive']
        testresult.append(canape_diag.checkResponse(response, expected_response))
    testresult.append(["[-0]", ""])

    # TEIL 3 ##################################################################
    testresult.append(["[-] ECU auf 'Standalone aktiv' setzen ", ""])
    testresult.append(["[+] Anpasskanal 1 und 2 auf 'definierte' Werte setzen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_defined_1)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_1))
    [response, result] = canape_diag.sendDiagRequest(request_defined_2)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_2))

    testresult.append(["[.] Status und Anpasskan�le �berpr�fen", ""])
    testresult.append(["[+0]", ""])

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']['active']
        testresult.append(canape_diag.checkResponse(response, expected_response))
    testresult.append(["[-0]", ""])

    # TEIL 4 ##################################################################
    testresult.append(["[-] Nur Anpasskanal 1 schreiben, muss nach 30 Sekunden auf inaktiv gesetzt werden ", ""])
    testresult.append(["[+] Anpasskanal 1 auf 'definierten' Wert setzen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_defined_1)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_1))

    testresult.append(["[.] 28 Sekunden warten", ""])
    time.sleep(28)

    testresult.append(["[.] Status und Anpasskan�le �berpr�fen: muss noch aktiv sein", ""])
    testresult.append(["[+0]", ""])

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']['active']
        testresult.append(canape_diag.checkResponse(response, expected_response))
    testresult.append(["[-0]", ""])

    testresult.append(["[.] 3 Sekunden warten", ""])
    time.sleep(3)

    testresult.append(["[.] Status und Anpasskan�le �berpr�fen: muss nun inaktiv sein", ""])
    testresult.append(["[+0]", ""])

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']['inactive']
        testresult.append(canape_diag.checkResponse(response, expected_response))
    testresult.append(["[-0]", ""])

    # TEIL 5 ##################################################################
    testresult.append(["[-] ECU erneut auf 'Standalone aktiv' setzen ", ""])
    testresult.append(["[+] Anpasskanal 1 und 2 auf 'definierte' Werte setzen", ""])
    [response, result] = canape_diag.sendDiagRequest(request_defined_1)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_1))
    [response, result] = canape_diag.sendDiagRequest(request_defined_2)
    testresult.append(result)
    testresult.append(canape_diag.checkResponse(response, expected_response_2))

    testresult.append(["[.] Status und Anpasskan�le �berpr�fen", ""])
    testresult.append(["[+0]", ""])

    for test in test_dict:
        test_data = test_dict[test]

        testresult.append(["[.] '%s' auslesen: %s" % (test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + test_data['expected_response']['active']
        testresult.append(canape_diag.checkResponse(response, expected_response))
    testresult.append(["[-0]", ""])

    testresult.append(["[-0]", ""])
    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del (testenv)
    # #########################################################################

print "Done."
