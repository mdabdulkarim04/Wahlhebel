#******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_Bootloader.py
# Title   : Diagnose Bootloader
# Task    : Reads out SW version and part number in bootloader mode
#
# Author  : S. Stenger
# Date    : 31.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name         | Description
#------------------------------------------------------------------------------
# 1.0  | 31.05.2021 | StengerS     | initial
# 1.1  | 18.08.2021 | Mohammed     | Added Ticket ID
# 1.2  | 26.10.2021 | Mohammed     | Added Bootloader Version
# 1.3  | 28.10.2021 | Mohammed     | Rework
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_126")

    # Initialize variables ####################################################
    test_dict = {
        1: identifier_dict['VW Application Software Version Number'],
        2: identifier_dict['VW ECU Hardware Number'],
        3: identifier_dict['VW ECU Hardware Version Number'],
        4: identifier_dict['VW Spare Part Number'],

    }
    request_dict = {
        1: {
            'identifier': [0x10, 0x01],
            'name': 'default',
            'expected_response': [0x50, 0x01, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3},
        2: {
            'identifier': [0x10, 0x02],
            'name': 'programming',
            'expected_response': [0x50, 0x02, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3,  # Bytes
        },
        3: {
            'identifier': [0x10, 0x03],
            'name': 'extended',
            'expected_response': [0x50, 0x03, 0x00, 0x32, 0x01, 0xF4],
            'exp_data_length': 3
        },
    }

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()


    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])
    testresult.append(["[+0]", ""])

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa01. Auslesen der Active Diagnostic Session: 0x22F186 ", ""])
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2. Wechsel in Extended Session: 0x1003
    testresult.append(["\xa02. Wechsel in Extended Session: 0x1003 ", ""])
    for test in request_dict:
        test_data = request_dict[test]
        if test_data['name'] == 'extended':
            request = test_data['identifier']
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)
            testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
            testresult.append(canape_diag.checkPositiveResponse(response, request, job_length=2))


    # 3. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa03. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('extended'))

    # 4.Wechsel in die Programming Session: 0x1002
    testresult.append(["\xa04. Wechsel in die Programming Session: 0x1002 ", ""])
    for test in request_dict:
        test_data = request_dict[test]
        if test_data['name'] == 'programming':
            request = test_data['identifier']
            [response, result] = canape_diag.sendDiagRequest(request)
            testresult.append(result)
            testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
            testresult.append(canape_diag.checkPositiveResponse(response, request, job_length=2))

    # 5. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa03. Auslesen der Active Diagnostic Session: 0x22F186", ""])
    testresult.extend(canape_diag.checkDiagSession('programming'))

    for test in test_dict:
        test_data = test_dict[test]

        if test_data['name'] == 'VW Application Software Version Number':
            expected_data = [0x31, 0x58, 0x36, 0x36]
        else:
            expected_data = test_data['expected_response']

        testresult.append(["[.] '%s' auslesen: %s" %(test_data['name'], str(HexList(test_data['identifier']))), ""])
        request = [0x22] + test_data['identifier']
        [response, result] = canape_diag.sendDiagRequest(request)
        testresult.append(result)

        testresult.append(["\xa0�berpr�fen, dass Request positiv beantwortet wird", ""])
        testresult.append(canape_diag.checkPositiveResponse(response, request))

        testresult.append(["\xa0Datenl�nge �berpr�fen", ""])
        testresult.append(canape_diag.checkDataLength(response, test_data['exp_data_length']))

        testresult.append(["\xa0Inhalt auf Korrektheit �berpr�fen", ""])
        expected_response = [0x62] + test_data['identifier'] + expected_data
        testresult.append(canape_diag.checkResponse(response, expected_response, ticket_id='Fehler Id:EGA-PRM-129'))

    testresult.append(["[-0]", ""])
    # 18./19. Erneut Default Session anfordern: 0x1001
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))


    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del(testenv)
    # #########################################################################

print "Done."
