#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Diagnose_AUTOSAR_standard_application_software_identification.py
# Task    : Test for Diagnosejob 0x22 F1AF
#
# Author  : An3Neumann
# Date    : 17.06.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 17.06.2021 | An3Neumann | initial
# 1.1  | 23.08.2021 | Mohammed  | Added Ticket Id
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import ResponseDictionaries
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
from ttk_checks import basic_tests

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_141")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)
    rd = ResponseDictionaries()

    # Initialize variables ####################################################
    diag_ident = identifier_dict['AUTOSAR_standard_application_software_identification']
    exp_ssw_dict, all_ssw, vendor = rd.AUTOSAR_standard_application_software_identification()

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])
    
    testresult.append(["[+] '%s' auslesen: %s" %(diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["[.] �berpr�fen, dass Request positiv beantwortet wird", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] Datenl�nge �berpr�fen", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'], ticket_id='Fehler Id:EGA-PRM-22'))

    response_content = response[3:]
    content_ssw = []
    while len(response_content) > 0:
        if len(response_content) >= 7:
            content_ssw.append(response_content[:7])
            del response_content[0:7]
        else:
            break

    testresult.append(["[.] Pr�fe SSW Module und deren Inhalte", ""])
    exp_ssw = exp_ssw_dict.keys()
    for content in content_ssw:
        ssw_modul_id = "%02X%02X"%(content[0], content[1])
        vendor_id = "%02X%02X"%(content[2], content[3])
        ssw_version = "%02X%02X%02X"%(content[4], content[5], content[6])
        testresult.append(["\xa0Pr�fe Inhalt f�r Response 0x%s 0x%s 0x%s" % (ssw_modul_id, vendor_id, ssw_version), ""])
        if int(ssw_modul_id, 16) in all_ssw.keys():
            readout_modul_name = all_ssw[int(ssw_modul_id, 16)]
            testresult.append(["Read out SSW Modul name: %s"%readout_modul_name, "INFO"])
            if int(ssw_modul_id, 16) in exp_ssw_dict.keys():
                exp_ssw.remove(int(ssw_modul_id, 16))
                exp_version = exp_ssw_dict[int(ssw_modul_id, 16)][0]
                exp_vendor = exp_ssw_dict[int(ssw_modul_id, 16)][1]

                testresult.append(
                    basic_tests.checkStatus(
                        current_status = int(vendor_id, 16),
                        nominal_status = exp_vendor,
                        descr = "Pr�fe, dass Vendor-ID wie erwartet ist (0x%04X)"%(exp_vendor)
                        )
                    )

                testresult.append(
                    basic_tests.checkStatus(
                        current_status = int(ssw_version, 16),
                        nominal_status = exp_version,
                        descr = "Pr�fe, dass SSW-Version wie erwartet ist (0x%06X)"%(exp_version)
                        )
                    )

            else:
                testresult.append(["SSW Module sollte nicht implementiert sein", "FAILED"])
        else:
            pass
            testresult.append(["SSW Module wird nicht durch VOLKSWAGEN AG zur Verf�gung gestellt: "
                               "0x%s 0x%s 0x%s"%(ssw_modul_id, vendor_id, ssw_version), "Info"])

    testresult.append(["[.] Pr�fe, dass alle implementierten SSW Module ausgegeben wurden", ""])
    if len(exp_ssw) != 0:
        testresult.append(["Nicht alle implementierten SSW Module wurden ausgegeben", "FAILED"])
        info = ""
        for ssw in exp_ssw:
            info += "\n%s"%all_ssw[ssw]
        testresult.append(["Es fehlen folgende Module:"+info, "Info"])
    else:
        testresult.append(["Alle implementierten SSW Module wurden ausgegeben", "PASSED"])
    
    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    
    # cleanup #################################################################
    hil = None
    
finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################
    
print "Done."
