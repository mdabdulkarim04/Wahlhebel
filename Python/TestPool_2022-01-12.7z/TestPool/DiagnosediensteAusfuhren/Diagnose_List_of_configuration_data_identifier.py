#******************************************************************************
# -*- coding: latin-1 -*-
# File    : Diagnose_List_of_configuration_data_identifier.py
# Task    : Test for Diagnosejob 0x22 0x0250
#
# Author  : An3Neumann
# Date    : 17.06.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name      | Description
#------------------------------------------------------------------------------
# 1.0  | 17.06.2021 | An3Neumann | initial
# 1.1  | 23.08.2021 | Mohammed  | Added Ticket Id
#******************************************************************************
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
from functions_diag import ResponseDictionaries
from functions_diag import HexList  # @UnresolvedImport
from diag_identifier import identifier_dict  # @UnresolvedImport
import functions_common
from ttk_checks import basic_tests

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_155")

    # Initialize functions ####################################################
    func_common = functions_common.FunctionsCommon(testenv)

    # Initialize variables ####################################################
    diag_ident = identifier_dict['Integrity_validation_data_configuration_list']

    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Deaktiviere Tester Present", ""])
    canape_diag.disableTesterPresent()

    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])
    
    testresult.append(["[+] '%s' auslesen: %s" %(diag_ident['name'], str(HexList(diag_ident['identifier']))), ""])
    request = [0x22] + diag_ident['identifier']
    [response, result] = canape_diag.sendDiagRequest(request)
    testresult.append(result)

    testresult.append(["[.] �berpr�fen, dass Request positiv beantwortet wird", ""])
    testresult.append(canape_diag.checkPositiveResponse(response, request))

    testresult.append(["[.] Datenl�nge �berpr�fen", ""])
    testresult.append(canape_diag.checkDataLength(response, diag_ident['exp_data_length'], ticket_id='Fehler Id:177'))

    testresult.append(["[.] Inhalt der Response �berpr�fen", ""])
    response_content = response[3:]
    value_count_dataidentifier = "%02X%02X"%(response_content[0], response_content[1]) # Response Bytes 1 und 2
    count_di = int(value_count_dataidentifier, 16)
    testresult.append(["[+] Pr�fe Anzahl ausgegebener DataIdentifier", ""])
    testresult.append(["Anzahl ausgegebener DataIdentifier: %s (0x%s)"%(count_di, value_count_dataidentifier), "INFO"])
    testresult.append(
        basic_tests.checkStatus(
            current_status=len(response_content)-4,
            nominal_status=count_di*2, # pro Dataidentifier 2 Bytes
            descr="Pr�fe, dass ausgegebene Anzahl der DataIdentifier mit der L�nge der Response �bereinstimmt"
        )
    )
    testresult.append(["[.] Pr�fe, dass eigener DataIdentifier nicht mit ausgegeben wird", ""])
    data_identifier = response_content[2:]
    if data_identifier > 0:
        descr = "Der eigene DataIdentifier wurde nicht zur�ckgegeben"
        verdict = 'PASSED'
        for i in [ident for ident in range(len(data_identifier)) if ident%2==0]:
            resp_data_ident = data_identifier[i:i+2]
            if resp_data_ident == [0x02, 0x53]:
                descr = "Der Eigene DataIdentifier wurde mit zur�ckgegeben"
                verdict = 'FAILED'
    else:
        descr = "Es wurde kein DataIdentifier zur�ckgegeben (somit auch nicht der eigene)"
        verdict = 'PASSED'
    testresult.append([descr, verdict])
    testresult.append(["[-0]", ""])
    # TEST POST CONDITIONS ####################################################
    testresult.append(["[-] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()
    
    # cleanup #################################################################
    hil = None
    
finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################
    
print "Done."
