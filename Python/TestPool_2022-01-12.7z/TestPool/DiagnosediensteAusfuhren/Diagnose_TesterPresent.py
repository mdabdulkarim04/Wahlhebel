#******************************************************************************
# -*- coding: latin1 -*-
# File    : Diagnose_TesterPresent.py
# Title   : Diagnose Tester Present
# Task    : Tests if enable tester present is working correctly
#
# Author  : S. Stenger
# Date    : 21.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name         | Description
#------------------------------------------------------------------------------
# 1.0  | 21.05.2021 | StengerS     | initial
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
import time
from data_common import s3_timeout

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()

    # set Testcase ID #########################################################
    testresult.setTestcaseId("TestSpec_131")


    # TEST PRE CONDITIONS #####################################################
    testresult.append(["[#0] Test Vorbedingungen", ""])
    testresult.append(["[+] ECU einschalten", ""])
    testenv.startupECU()
    canape_diag = testenv.getCanapeDiagnostic()
    testresult.append(["[.] Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()


    # TEST PROCESS ############################################################
    testresult.append(["[-] Starte Testprozess: %s"%testenv.script_name.split('.py')[0], ""])

    # 1. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.extend(canape_diag.checkDiagSession('default'))

    # 2./3. Wechsel in Extended Session: 0x1003
    testresult.extend(canape_diag.changeAndCheckDiagSession('extended'))

    # 4. Tester Present aktivieren
    testresult.append(["\xa0Tester Present aktivieren", ""])
    canape_diag.enableTesterPresent()

    # 5. Warten
    testresult.append(["\xa0Warte %s Sekunden (2 * S3 timeout)" % (2 * s3_timeout), ""])
    time.sleep(2 * s3_timeout)

    # 6. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa0�berpr�fen, dass man immer noch in der 'extended session' ist", ""])
    testresult.extend(canape_diag.checkDiagSession('extended'))

    # 7./8. Wechsel in die Programming Session: 0x1002
    testresult.extend(canape_diag.changeAndCheckDiagSession('programming'))

    # 9. Warten
    testresult.append(["\xa0Warte %s Sekunden (2 * S3 timeout)" % (2 * s3_timeout), ""])
    time.sleep(2 * s3_timeout)

    # 10. Auslesen der Active Diagnostic Session: 0x22F186
    testresult.append(["\xa0�berpr�fen, dass man immer noch in der 'programming session' ist", ""])
    testresult.extend(canape_diag.checkDiagSession('programming'))

    # 11./12. Erneut Default Session anfordern: 0x1001
    testresult.extend(canape_diag.changeAndCheckDiagSession('default'))

    # 13. Tester Present deaktivieren
    testresult.append(["\xa0Tester Present deaktivieren", ""])
    canape_diag.disableTesterPresent()



    # TEST POST CONDITIONS ####################################################
    testresult.append(["[.] Test Nachbedingungen", ""])
    testresult.append(["[+] ECU ausschalten", ""])
    testenv.shutdownECU()


finally:
    # #########################################################################
    testenv.breakdown()
    del(testenv)
    # #########################################################################

print "Done."
