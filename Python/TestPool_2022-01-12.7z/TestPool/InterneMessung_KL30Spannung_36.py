#******************************************************************************
# -*- coding: latin1 -*-
# File    : InterneMessung_KL30Spannung_36.py
# Task    : A minimal "InterneMessung_KL30Spannung!" test script
#
# Copyright 2020 Eissmann Automotive Deutschland GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name     | Description
#------------------------------------------------------------------------------
# 1.0  | 12.02.2021 | Abdul Karim  | initial
#******************************************************************************
import time
from _automation_wrapper_ import TestEnv
testenv = TestEnv()
from ttk_bus.bus_signals_base import RxBusSignal, TxBusSignal, BusSignalContainer
from ttk_checks import basic_tests
##

try:
##
    testenv.setup()
    testresult = testenv.getResults()
    #hil = testenv.getHil()
    testenv.startupECU()
    cal = testenv.getCal()

    #daq = testenv.getCanapeDAQ()
    time.sleep(.200)
    canape = testenv.getCanapeCan()
    buf1 = canape.readBytes(0x12DD54FE, 16)
    buf2 = canape.readBytes(0x585,16)
    print (buf1)
    print (buf2)
    #daq.start()
  #  meas_vars = [cal.RawADCKL30Val, "10ms", 0]
    meas_vars = [
        # <variable/identifier>, <measurement task>, <device index>
        [cal.NM_aktiv_Tmin,       1, 0],
        [cal.RawADCSensor1Val,      "CAN", 1 ],
        ]

#    daq.setup(meas_vars)
    print(meas_vars)
    print "Data Acquisition...",
    # start measurement/recorder
#    daq.start()
    #cal.RawADCSensor1Val.set(10)

#    daq.setup(meas_vars)
    #testresult.append(basic_tests.checkStatus(cal.NM_Airbag_01, 1, 1, descr="NM_Airbag_01"))
    #testresult.append(basic_tests.checkTolerance(cal.NM_Airbag_01, 1, 1, descr="NM_Airbag_01"))
    testresult.append(basic_tests.checkTolerance(cal.RawADCSensor1Val, 100, 1, descr="RawADCKL30Val"))
    testresult.append(basic_tests.checkStatus(cal.KST_KL_15, 1, descr="RawADCKL30Val"))
    #testresult.append(basic_tests.checkTolerance(cal.NM_aktiv_Tmin, 1, 1, descr="KST_KL_15"))
    #testresult.append(basic_tests.checkStatus(cal.SwVersion, 'H01_0035', descr="Swversion"))
    #testresult.append(basic_tests.checkStatus(cal.SiShift_StLghtDrvPosn, 4, descr="SiShift_StLghtDrvPosn"))
   # testresult.append(basic_tests.checkTolerance(cal.Swc_GSL_IOHardwareAbstraction_value, 1, 1, descr="Swc_GSL_IOHardwar"))
   # sig = RxBusSignal(cal.RawADCSensor1Val,10)
    #testresult.append(basic_tests.checkStatus(sig,1, descr="Sensor1val"))
   # print (sig)

    ## Cleanup
    #hil=None
    cal=None

finally:
    # #########################################################################
    testenv.breakdown()
    # #########################################################################

