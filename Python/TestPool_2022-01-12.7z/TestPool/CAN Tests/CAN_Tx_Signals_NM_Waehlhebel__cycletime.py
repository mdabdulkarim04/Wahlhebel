#******************************************************************************
# -*- coding: latin-1 -*-
#
# File    : CAN_Tx_Signals_NM_Waehlhebel__cycletime.py
# Title   : CAN Tx Signals NM Waehlhebel cycletime
# Task    : Test of Cycle time ECU-Tx => HIL-Rx Signals of CAN Message NM_Waehlhebel
#
# Author  : A. Neumann
# Date    : 25.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
#******************************************************************************
#********************************* Version ************************************
#******************************************************************************
# Rev. | Date       | Name       | Description
#------------------------------------------------------------------------------
# 1.0  | 25.05.2021 | A. Neumann | initial
#******************************************************************************
#
# Imports #####################################################################
from _automation_wrapper_ import TestEnv
import simplified_bus_tests

# Instantiate test environment
testenv = TestEnv()

try:
    # #########################################################################
    # Testenv #################################################################
    testenv.setup()
    testresult = testenv.getResults()
    
    # Initialize functions ####################################################
    hil = testenv.getHil()
    #cal = testenv.getCal()
    
    # Initialize variables ####################################################
    cycle_time_ms       = 200
    inhibitzeit_ms      = 10
    tolerance_percent   = 0.10
    
    # set Testcase ID #########################################################
    #testenv.setTCID(mdd=None, mdp=None, cabin=None, private=None)
    testresult.setTestcaseId("CAN_90")
    
    # TEST PRE CONDITIONS #####################################################
    testenv.startupECU()  
    
    # TEST PROCESS ############################################################
    testresult.append(['Check the cycle time of the message NM_Waehlhebel.','INFO'])
    testresult.append(
        simplified_bus_tests.checkTiming(
            time_stamp_variable=hil.NM_Waehlhebel__timestamp, 
            cycle_time_value_ms=cycle_time_ms,
            message_name="NM_Waehlhebel",
            tol_perc=tolerance_percent,
            operator = "==")
            )

    # Anna Neumann: Inhibit zeit test aktuell noch nicht m�glich
    # testresult.append(['Check the inhibit cycle time of the message NM_Waehlhebel.','INFO'])
    # testresult.append(
    #     simplified_bus_tests.checkInhibitTiming(
    #         time_stamp_variable=hil.NM_Waehlhebel__timestamp,
    #         set_variable = calvar to set # TODO
    #         set_values = [0x0, 0x1],
    #         cycle_time_value_ms = cycle_time_ms,
    #         message_name="NS_Waehlhebel",
    #         inhibit_time_ms = inhibitzeit_ms,
    #         tol_perc=tolerance_percent,
    #         )
    #     )
    
    # TEST POST CONDITIONS ####################################################
    testenv.shutdownECU()
    
    # cleanup
    hil = None

finally:
    # #########################################################################
    testenv.breakdown(ecu_shutdown=False)
