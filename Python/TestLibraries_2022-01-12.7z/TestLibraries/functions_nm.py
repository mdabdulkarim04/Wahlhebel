# ******************************************************************************
# -*- coding: latin-1 -*-
# File    : functions_nm.py
# Task    : functions to work with network management
#
# Author  : An3Neumann
# Date    : 28.05.2021
# Copyright 2021 iSyst Intelligente Systeme GmbH
#
# ******************************************************************************
# ********************************* Version ************************************
# ******************************************************************************
# Rev. | Date       | Name      | Description
# ------------------------------------------------------------------------------
# 1.0  | 28.05.2021 | An3Neumann | initial
# 1.1  | 21.07.2021 | M. Abdul Karim | Rework for N-Haltphase Timer values
# 1.2  | 08.09.2021 | Devangbhai Patel | Trying to write failure ID in the verdict
# 1.3  | 24.11.2021 | Devangbhai Patel | Added evaluation method to check if the NM and Application messages are sending/stopped
# ******************************************************************************
from ttk_daq import eval_signal
import functions_gearselection
import functions_common
import time
from ttk_checks.basic_tests import *
from ttk_checks import _basic_tests
from ttk_checks.basic_checks import CHECKBITMASK_DEFAULT_BIT_LENGTH



class FunctionsNM(object):

    def __init__(self, testenv, hil=None):
        """
            TODO
        """
        self.testenv = testenv

        if hil is None:
            self.hil = self.testenv.getHil()
        else:
            self.hil = hil

        self.func_gs = functions_gearselection.FunctionsGearSelection(testenv, self.hil)
        self.func_com = functions_common.FunctionsCommon(testenv)

        self.fcab_bit_mapping = {
            56: "Charging_Status",  # 56_ChargingStatus
            55: "Dimming",  # 55_Dimming
            54: "<reserved>",  # 54_<reserved>
            53: "Lock_Unlock",  # 53_Lock_Unlock
            52: "not definded",  #
            51: "not definded",  #
            50: "not definded",  #
            49: "<reserved>",  # 49_<reserved>
            48: "Diagnosis_ClimateTmeLINs",  # 48_Diagnosis_ClimateTmeLINs
            47: "Diagnosis_ComfortLINs",  # 47_Diagnosis_ComfortLINs
            46: "Diagnosis_Light",  # 46_Diagnosis_Light
            45: "Diagnosis_Comfort",  # 45_Diagnosis_Comfort
            44: "Diagnosis_Infotainment",  # 44_Diagnosis_Infotainment
            43: "Diagnosis_DrivingAssistance",  # 43_Diagnosis_DrivingAssistance
            42: "Diagnosis_FlexRay",  # 42_Diagnosis_FlexRay
            41: "Diagnosis_Powertrain",  # 41_Diagnosis_Powertrain
            40: "Diagnosis_Energy",  # 40_Diagnosis_Energy
            39: "not definded",  #
            38: "not definded",  #
            37: "HighVoltage_WirelessChargingStation",  # 37_HighVoltage_WirelessChargingStation
            36: "PreHeater",  # 36_Preheater
            35: "ExteriorSound",  # 35_ExteriorSound
            34: "GPS_Localization",  # 34_GPS_Localization
            33: "ExternalWirelessCommunication",  # 33_ExternalWirelessCommunication
            32: "OnlineAccess",  # 32_OnlineAccess
            31: "MultifunctionalSteeringWheel",  # 31_MultifunctionalSteeringWheel
            30: "EnergyManagement",  # 30_EnergyManagement
            29: "SteeringColumnLock",  # 29_SteeringColumnLock
            28: "OnboardTester_DataCollector",  # 28_OnboardTester_DataCollector
            27: "Timemaster_Timer",  # 27_Timemaster_Timer
            26: "HighVoltage_Charging",  # 26_HighVoltage_Charging
            25: "AccessSystemSensors",  # 25_AccessSystemSensors
            24: "ThermoManagement",  # 24_ThermoManagement
            23: "Climate",  # 23_Climate
            22: "ExteriorLights",  # 22_ExteriorLights
            21: "AirSuspension",  # 21_AirSuspension
            20: "OptionalComfort",  # 20_OptionalComfort
            19: "Doors_Hatches",  # 19_Doors_Hatches
            18: "VirtualSideMirrors",  # 18_VirtualSideMirrors
            17: "Audio",  # 17_Audio
            16: "InfotainmentDisplay",  # 16_InfotainmentDisplay
            15: "InstrumentclusterDisplay",  # 15_InstrumentclusterDisplay
            14: "InfotainmentExtensions",  # 14_InfotainmentExtensions
            13: "Airbag",  # 13_Airbag
            12: "GearSelector",  # 12_GearSelector
            11: "Chassis",  # 11_Chassis
            10: "Powertrain",  # 10_Powertrain
            9: "<reserved>",  # 09_<reserved>
            8: "Basefunction_Connectivity",  # 08_Basefunction_Connectivity
            7: "Basefunction_CrossSection",  # 07_Basefunction_CrossSection
            6: "Basefunction_ComfortLight",  # 06_Basefunction_ComfortLight
            5: "Basefunction_Infotainment",  # 05_Basefunction_Infotainment
            4: "Basefunction_DrivingAssistance",  # 04_Basefunction_DrivingAssistance
            3: "Basefunction_Chassis",  # 03_Basefunction_Chassis
            2: "Basefunction_Powertrain",  # 02_Basefunction_Powertrain
            1: "CarWakeUp",  # 01_CarWakeUp
        }

    def anylysisCycletime_start_stop(self, start_time, stop_time, daq_data):
        
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)

        # analyse_signal_data.markEvalRangeStart()
        analyse_signal_data.setEvalRange(start_time, stop_time)

        cycle_times = []
        sleep_start = analyse_signal_data.findChanged()
        sleep_time = None
        t_start = analyse_signal_data.getData()
        while t_start:
            analyse_signal_data.findChanged()
            t_next = analyse_signal_data.getData()
            if t_next:
                sleep_start = analyse_signal_data.getTime()
                cycle_times.append((t_next - t_start) / 1000)
            else:
                sleep_time = sleep_start - start_time
            t_start = t_next

        return cycle_times, sleep_time

    def analyseCycleSleepTimes(self, start_time, daq_data):
        """
        Parameter:
            start_time:         time where analyse start (e.g. cl 15 off)
            daq_data:           daq data of the signal
        Info:
            read all cycle times and create a list
            last measure timestamp is the sleep time
        Returns:
            cyle_times, sleep_time
        """
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)

        cycle_times = []
        sleep_start = analyse_signal_data.findChanged()
        sleep_time = None
        t_start = analyse_signal_data.getData()
        while t_start:
            analyse_signal_data.findChanged()
            t_next = analyse_signal_data.getData()
            if t_next:
                sleep_start = analyse_signal_data.getTime()
                cycle_times.append((t_next - t_start) / 1000)
            else:
                sleep_time = sleep_start - start_time
            t_start = t_next

        return cycle_times, sleep_time

    def analyseCycleWakeupTimes(self, start_time, daq_data):
        """
        Parameter:
            start_time:         time where analyse start (e.g. cl 15 on)
            daq_data:           daq data of the signal
        Info:
            read all cycle times and create a list
            last measure timestamp is the wakeup time
        Returns:
            cyle_times, wakeup_time
        """
        cycle_times = []
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)

        wakeup_start = analyse_signal_data.findChanged()
        wakeup_time = wakeup_start - start_time

        t_start = analyse_signal_data.getData()
        while t_start:
            analyse_signal_data.findChanged()
            t_next = analyse_signal_data.getData()
            if t_next:
                cycle_times.append((t_next - t_start) / 1000)

            t_start = t_next

        return cycle_times, wakeup_time

    def analysisCycleTime(self, start_time, daq_data):
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)

        cycle_times = []
        sleep_start = analyse_signal_data.findChanged()
        t_start = analyse_signal_data.getData()
        while t_start:
            analyse_signal_data.findChanged()
            t_next = analyse_signal_data.getData()
            if t_next:
                sleep_start = analyse_signal_data.getTime()
                cycle_times.append((t_next - t_start) / 1000)
            t_start = t_next

        return cycle_times

    def analysisSigWithinTime(self, start_time, end_time, daq_data):
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)
        analyse_signal_data.setEvalRange(start_time, end_time)
        # analyse_signal_data.getEvalRangeData()

        cycle_times = []
        sleep_start = analyse_signal_data.findChanged()
        sleep_time = None
        t_start = analyse_signal_data.getData()
        while t_start:
            analyse_signal_data.findChanged()
            t_next = analyse_signal_data.getData()
            if t_next:
                sleep_start = analyse_signal_data.getTime()
                cycle_times.append((t_next - t_start) / 1000)
            else:
                sleep_time = sleep_start - start_time
            t_start = t_next

        return cycle_times, sleep_time

    def analysisNmMessageSent(self, start_time, daq_data, name=None,NMAreSending=False):
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)

        change = analyse_signal_data.findChanged()

        if NMAreSending:
            if change is not None:
                verdict_nm = "PASSED"
                description_nm = "\xa0 %s Botschaft sendet noch" %name
            else:
                verdict_nm = "FAILED"
                description_nm = "\xa0 %s Botschaft sendet nicht mehr " %name
        else:
            if change is not None:
                verdict_nm = "FAILED"
                description_nm = "\xa0 %s Botschaft sendet noch" %name
            else:
                verdict_nm = "PASSED"
                description_nm = "\xa0 %s Botschaft sendet nicht mehr" %name
        return verdict_nm, description_nm

    def analysisApplicationMessageSent(self, start_time, daq_data, name=None, ApplicationsAreSending=False):
        signal_data = daq_data
        analyse_signal_data = eval_signal.EvalSignal(signal_data)
        analyse_signal_data.clearAll()
        analyse_signal_data.seek(start_time)

        change = analyse_signal_data.findChanged()

        if ApplicationsAreSending:
            if change is not None:
                verdict_application_message = "PASSED"
                description_aapl = "\xa0 %s Botschaft sendet noch" %name
            else:
                verdict_application_message = "FAILED"
                description_aapl = "\xa0 %s Botschaft sendet nicht mehr" %name
        else:
            if change is not None:
                verdict_application_message = "FAILED"
                description_aapl = "\xa0 %s Botschaft sendet noch" %name
            else:
                verdict_application_message = "PASSED"
                description_aapl = "\xa0 %s Botschaft sendet nicht mehr" %name

        return verdict_application_message, description_aapl

    def checkFcabBitwise(self, fcab_value, bit_exp_one, bit_exp_zero, descr="", dont_care_info=False):
        """
        Args:
            fcab_value: read out value of fcab variable
            bit_exp_one: list with all bit, which shall be 1
            bit_exp_zero:  list with all bit, which shall be 0
            descr: (optional)
            dont_care_info: if True also "don't care bits are in result"

        Info:
            check that all exp one are one, all zero are zero... all other don't care

        Returns:
            description, verdict
        """
        exp_value = ""
        for bit in range(1, len(self.fcab_bit_mapping) + 1):

            if bit in bit_exp_one:
                exp_value = "1" + exp_value
            elif bit in bit_exp_zero:
                exp_value = "0" + exp_value
            else:
                exp_value = "X" + exp_value

        return self.checkFCABValue(fcab_value=fcab_value, exp_value=exp_value, descr=descr, dont_care_info=dont_care_info)

    def checkFCABValue(self, fcab_value, exp_value, descr="", dont_care_info=False):
        """
        Args:
            fcab_value: read out value of fcab variable
            exp_value: expected value of fcab
            descr: (optional)
            dont_care_info: if True also "don't care bits are in result"

        Returns:
            description, verdict
        """

        bit_value = bin(int(fcab_value))[2:] if isinstance(fcab_value, (int, float, long)) else fcab_value
        exp_bit_value = bin(int(exp_value))[2:] if isinstance(exp_value, int) else exp_value

        i = len(self.fcab_bit_mapping)
        while len(bit_value) < i:
            bit_value = "0" + bit_value
        while len(exp_bit_value) < i:
            exp_bit_value = "0" + exp_bit_value

        verdict = "PASSED"
        info = "%s\nAusgelesen: %s (%s), \nErwartet: %s\n" % (descr, bit_value, int(bit_value, 2), exp_bit_value)

        for bit, e_bit in zip(bit_value, exp_bit_value):
            if e_bit != "X":
                if self.fcab_bit_mapping[i] != "not definded":
                    if bit == e_bit:
                        if bit == "1":
                            info += "Bit %s ist wie erwartet aktiviert = 1 (%s)\n" % (i, self.fcab_bit_mapping[i])
                        else:
                            info += "Bit %s ist wie erwartet deaktiviert = 0 (%s)\n" % (i, self.fcab_bit_mapping[i])
                    else:
                        verdict = "FAILED"
                        if e_bit == "0":
                            info += ">> Bit %s sollte deaktiviert = 0 sein (%s)\n" % (i, self.fcab_bit_mapping[i])
                        else:
                            info += ">> Bit %s sollte aktiviert = 1  sein (%s)\n" % (i, self.fcab_bit_mapping[i])
            else:
                if dont_care_info:
                    info += "Bit %s wird nicht ausgewertet - don't care (%s)\n" % (i, self.fcab_bit_mapping[i])
            i -= 1

        return [info, verdict]

    def waitTillChangeIntoRS(self, timeout_s=3, nm_cycletime_s=0.200):
        '''
        Parameter:
            timeout        - timeout in seconds if no change will done
            nm_cycletime_s - cycletime of NM Message in seconds

        Info:
            read out timestamp of NM message. if timestamp didn't change for
            time = 1.5*cycletime sending stopped and NM State should change
            to Ready Sleep. Return PASSED if this happend before timeout come

        Return:
            verdict
        '''
        nm_sending_message = self.hil.NM_Waehlhebel__timestamp
        start_time = time.time()
        time_old = time.time()
        timestamp_old = 0
        verdict = 'FAILED'
        while timeout_s > (time.time() - start_time):
            time.sleep(0.01)
            timestamp_new = nm_sending_message.get()
            time_new = time.time()
            if timestamp_new == timestamp_old:
                if (time_new - time_old) > nm_cycletime_s * 1.5:
                    verdict = 'PASSED'
                    break
            else:
                time_old = time_new
                timestamp_old = timestamp_new

        return verdict

    def waitTillTimerEnds(self, timer, wait_time=None, switch_rx_signals=True):
        """

        Args:
            timer:          - 1, 2, 3, 4, "ende"
            wait_time:      - max. wait time in seconds
                                if None, max times are:
                                timer 1 = 25min = 1500s
                                timer 2 = 1min = 60s
                                timer 3 = 3min = 180s
                                timer 4 = 1min = 60s
            switch_rx_signals: if True RX signals from HiL to ECU will switched off/on
                                Timer 1 Passed - switch on
                                After Timer 2 - switch off
                                Timer 4 Passed - switch on

        Info:
            Diese Abl�ufe und Analyse erfolgt nach dem Dokument LAH_WH_N-Haltephase, Version 0.0, vom 22.02.2021
            Siehe Ablauf Seite 10 von 10
        Returns:
                description, verdict
        """

        waiting_times_timer = {1: 1500, 2: 60, 3: 180, 4: 60, "ende": 0}
        wait_time = wait_time if wait_time else waiting_times_timer[timer]
        # timer parameter
        wait_intervall = 0.1 # 1/2 Cycletime to check changes
        number_loops = int(float(wait_time) / wait_intervall)
        nm_timestamp = self.hil.NM_Waehlhebel__timestamp
        fcab_signal = self.hil.NM_Waehlhebel__NM_Waehlhebel_FCAB__value
        zustand_signal = self.hil.Waehlhebel_04__WH_Zustand_N_Haltephase_2__value
        tmin_signal = self.hil.NM_Waehlhebel__NM_Waehlhebel_NM_aktiv_Tmin__value
        cbv_awb_signal = self.hil.NM_Waehlhebel__NM_Waehlhebel_CBV_AWB__value
        nm_aktiv_signal = self.hil.NM_Waehlhebel__NM_Aktiv_N_Haltephase_abgelaufen__value

        change_time = None
        verdict = None

        def checkSignalValues(carwakeup, t_min, cbv_awb, zustand, n_haltephase_abgelaufen):
            info = ''
            verdict = 'PASSED'
            if carwakeup is not None:
                read_value = fcab_signal.get()
                if carwakeup == 1:
                    _, verdict = self.checkFcabBitwise(fcab_value=read_value, bit_exp_one=[1], bit_exp_zero=[])
                else:
                    _, verdict = self.checkFcabBitwise(fcab_value=read_value, bit_exp_one=[], bit_exp_zero=[1])
                info += "CarWakeUp ist korrekt (erw/akt: %s)"%read_value if verdict == "PASSED" else "> CarWakeUp ist falsch (erw: %s / akt: %s)"%(carwakeup, read_value)
            if t_min is not None:
                read_value = tmin_signal.get()
                if read_value != t_min:
                    verdict = "FAILED"
                    info += "\n> NM_aktiv_Tmin ist falsch (erw: %s / akt: %s)"%(t_min, read_value)
                else:
                    info += "\nNM_aktiv_Tmin ist korrekt (erw/akt: %s)"%read_value
            if cbv_awb is not None:
                read_value = cbv_awb_signal.get()
                if read_value != cbv_awb:
                    verdict = "FAILED"
                    info += "\n> CBV_AWB ist falsch (erw: %s / akt: %s)"%(cbv_awb, read_value)
                else:
                    info += "\nCBV_AWB ist korrekt (erw/akt: %s)"%read_value
            if zustand is not None:
                read_value = zustand_signal.get()
                if read_value != zustand:
                    verdict = "FAILED"
                    info += "\n> WH_Zustand_N_Haltephase_2 ist falsch (erw: %s / akt: %s)"%(zustand, read_value)
                else:
                    info += "\nWH_Zustand_N_Haltephase_2 ist korrekt (erw/akt: %s)"%read_value
            if n_haltephase_abgelaufen is not None:
                read_value = nm_aktiv_signal.get()
                if read_value != n_haltephase_abgelaufen:
                    verdict = "FAILED"
                    info += "\n> NM_Aktiv_N_Haltephase_abgelaufen ist falsch (erw: %s / akt: %s)"%(n_haltephase_abgelaufen, read_value)
                else:
                    info += "\nNM_Aktiv_N_Haltephase_abgelaufen ist korrekt (erw/akt: %s)"%read_value

            return verdict, info

        # timer 1
        car_wakeup_t1 = 1
        t_min_t1 = cbv_awb_t1 = 1
        zustand_t1 = 1 ## Added zustand_t1
        n_haltephase_abgelaufen_1 = 0 ## Added n_haltephase_abgelaufen_1

        # timer 2
        cbv_awb_t2 = 1
        zustand_t2 = 1  ## Added zustand_t2
        t_min_t2 = 0  ## Added  t_min_t2
        n_haltephase_abgelaufen_2 = 0 ##  Added n_haltephase_abgelaufen_2

        # timer 3
        car_wakeup_t3 = 1   ## replace 0 to 1
        zustand_t3 = 5      ##  replace 1 to 5
        t_min_t3 = cbv_awb_t3 = 1
        n_haltephase_abgelaufen_3 = 0  ##  Added n_haltephase_abgelaufen_2

        # timer 4
        car_wakeup_t4 = 1
        zustand_t4 = 2     ##  replace 5 to 2
        cbv_awb_t4 = 1     ##  Added cbv_awb_t4
        n_haltephase_abgelaufen_4 = 0  ##  Added n_haltephase_abgelaufen_4

        # timer ende
        zustand_tende = 2
        sishift_tende = 'P' # 8
        car_wakeup_tende = 0
        t_min_tende = cbv_awb_tende = 1
        n_haltephase_abgelaufen_tende = 1

        if timer == 1:
            # Pr�fe, dass in der vorgegebenen wait time eine Botschaft gesendet wird:
            # - timestamp muss ich �ndern --> timestamp_change wird auf True ge�ndert
            # wenn timestamp sich �ndert, wird CarWakeUp gepr�ft_
            # - CarWakeUp == 1, CBV_AWB = 1, NM_aktiv_Tmin = 1 --> verdict wird auf 'PASSED' ge�ndert und change_time wird eingetragen
            # wenn timestamp_change == True, verdict == 'PASSED' und switch_rx_signals == True:
            # - Senden von RX Signalen (Botschaften von HiL -> ECU) wird angeschaltet
            # Wenn verdict == 'PASSED':
            # - wird timestamp und CarWakeUp nicht mehr gepr�ft, Wartezeit l�uft noch zuende ab
            # Wenn nach Ablauf des Timers change_time == None, wird verdict auf 'FAILED' ge�ndert
            # In der description wird unterschieden zwischen:
            # - Es wurde keine Botschaft gesendet (timestamp_change == False)
            # - Es wurde eine Botschaft gesendet (timestamp_change == True), aber CarWakeUp Bit ist nicht 1
            timestamp_change = False
            start_timestamp = nm_timestamp.get()
            for i in range(1,number_loops+1):
                time.sleep(wait_intervall)
                if verdict != "PASSED":
                    curr_timestamp = nm_timestamp.get()
                    if start_timestamp != curr_timestamp:
                        timestamp_change = True
                        verdict, info = checkSignalValues(car_wakeup_t1, t_min_t1, cbv_awb_t1, zustand_t1, n_haltephase_abgelaufen_1) ## Added zustand_t1 and n_haltephase_abgelaufen_1
                        if verdict == "PASSED":
                            change_time = i*wait_time
                            descr = "NM_Waehlhaebel Botschaft wurde nach %ss empfangen und Werte sind korrekt %s"%(change_time/1000.0, info)
                            if switch_rx_signals:
                                # start sending of hil signals
                                self.func_gs.switchAllRXMessagesOn()
                                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde gestartet"
                            else:
                                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde nicht gestartet"
            if change_time is None:
                verdict = "FAILED"
                if timestamp_change:
                    _, info = checkSignalValues(car_wakeup_t1, t_min_t1, cbv_awb_t1, zustand_t1, n_haltephase_abgelaufen_1)  ## Added zustand_t1 and n_haltephase_abgelaufen_1
                    descr = "Signale wurden w�hrend Timer 1 Zeit nicht korrekt gesetzt %s"%(info)
                else:
                    descr = "NM_Waehlhaebel Botschaft hat nichts gesendet (Keine �nderung des Timestamps)"
                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde NICHT gestartet"

        elif timer == 2:
            # Es wird gepr�ft, dass nach Ablauf der wait_time das Signal WH_Zustand_N_Haltephase_2 == 1 ist
            # Ist WH_Zustand_N_Haltephase_2 == 1 wird verdict auf "PASSED" gesetzt (sonst "FAILED")
            # Wenn switch_rx_signals == True:
            # - Senden von RX Signalen (Botschaften von HiL -> ECU) wird ausgeschaltet
            self.func_com.waitSecondsWithResponse(wait_time)
            _, info = checkSignalValues(cbv_awb_t2, zustand_t2, None, t_min_t2, n_haltephase_abgelaufen_2) ### ## Added zustand_t2, n_haltephase_abgelaufen_2
            descr = "Warte bis Timer %s abgelaufen ist - %ss"%(timer, wait_time)
            descr += "\n" + info
            if switch_rx_signals:
                self.func_gs.switchAllRXMessagesOff()
                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde gestoppt"
            else:
                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde nicht gestoppt"

        elif timer == 3:
            # Es wird gepr�ft, dass in der vorgegebenen wait_time eine Botschaft empfangen wird
            # - timestamp muss ich �ndern --> timestamp_change wird auf True ge�ndert
            # wenn timestamp sich �ndert, wird CarWakeUp gepr�ft_
            # - CarWakeUp == 1, CBV_AWB = 1, NM_aktiv_Tmin = 1 WH_Zustand_N_Haltephase_2 muss 1 sein
            #  --> verdict wird auf 'PASSED' ge�ndert und change_time wird eingetragen
            # Wenn verdict == 'PASSED':
            # - wird timestamp und CarWakeUp nicht mehr gepr�ft, Wartezeit l�uft noch zuende ab
            # Wenn nach Ablauf des Timers change_time == None, wird verdict auf 'FAILED' ge�ndert
            # In der description wird unterschieden zwischen:
            # - Es wurde keine Botschaft gesendet (timestamp_change == False)
            # - Es wurde eine Botschaft gesendet (timestamp_change == True), aber einer oder beide gepr�ften Werte falsch
            timestamp_change = False
            start_timestamp = nm_timestamp.get()
            for i in range(1, number_loops + 1):
                time.sleep(wait_intervall)
                if verdict != "PASSED":
                    curr_timestamp = nm_timestamp.get()
                    if start_timestamp != curr_timestamp:
                        timestamp_change = True
                        verdict, info = checkSignalValues(car_wakeup_t3, t_min_t3, cbv_awb_t3, zustand_t3, n_haltephase_abgelaufen_3) ### Added n_haltephase_abgelaufen_3
                        if verdict == 'PASSED':
                            # start sending of hil signals
                            change_time = i * wait_time
                            descr = "NM_Waehlhaebel Botschaft wurde nach %ss empfangen und Werte sind korrekt %s"%(change_time/1000.0, info)

            if change_time is None:
                verdict = "FAILED"
                if timestamp_change:
                    _, info = checkSignalValues(car_wakeup_t3, t_min_t3, cbv_awb_t3, zustand_t3, None)
                    descr = "Werte wurden nicht wie erwartet gesetzt. \n%s"%(info)
                else:
                    descr = "NM_Waehlhaebel Botschaft hat nichts gesendet (Keine �nderung des Timestamps)"

        elif timer == 4:
            # Es wird gepr�ft, dass in der vorgegebenen wait_time eine Botschaft empfangen wird
            # - timestamp muss ich �ndern --> timestamp_change wird auf True ge�ndert
            # wenn timestamp sich �ndert, wird CarWakeUp gepr�ft_
            # - CarWakeUp muss auf 1 sein und WH_Zustand_N_Haltephase_2 muss 5 sein
            #  --> verdict wird auf 'PASSED' ge�ndert und change_time wird eingetragen
            # sobald verdict == 'PASSED' ist und change_time existiert, werden Werte nicht mehr gepr�ft
            # und der timer 4 wird gestartet:
            # - wenn switch_rx_signals == True wird Senden von RX Signalen (Botschaften von HiL -> ECU) gestartet
            # Wenn nach Ablauf der wait_time die change_time == None, wird verdict auf 'FAILED' ge�ndert
            # In der description wird unterschieden zwischen:
            # - Es wurde keine Botschaft gesendet (timestamp_change == False)
            # - Es wurde eine Botschaft gesendet (timestamp_change == True), aber einer oder beide gepr�ften Werte falsch
            timestamp_change = False
            # first loop to check that values are changing
            start_timestamp = nm_timestamp.get()
            for i in range(1, number_loops + 1):
                time.sleep(wait_intervall)
                if verdict != "PASSED":
                    curr_timestamp = nm_timestamp.get()
                    if start_timestamp != curr_timestamp:
                        timestamp_change = True
                        verdict, info = checkSignalValues(car_wakeup_t4, cbv_awb_t4, None, zustand_t4, n_haltephase_abgelaufen_4) ## Added cbv_awb_t4 and n_haltephase_abgelaufen_4
                        if verdict == 'PASSED':
                            # start sending of hil signals
                            change_time = i * wait_time
                            descr = "NM_Waehlhaebel Botschaft wurde nach %ss empfangen und Werte sind korrekt %s"%(change_time/1000.0, info)
                            if switch_rx_signals:
                                self.func_gs.switchAllRXMessagesOn()
                                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde gestartet"
                            else:
                                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde nicht gestartet"
                            break
                        else:
                            verdict = "FAILED"

            if change_time is None:
                verdict = "FAILED"
                if timestamp_change:
                    _, info = checkSignalValues(car_wakeup_t4, None, cbv_awb_t4, zustand_t4, n_haltephase_abgelaufen_4) ## Todo: Added cbv_awb_t4 and n_haltephase_abgelaufen_4
                    descr = "Werte wurden nicht wie erwartet gesetzt. \n%s \nTimer 4 nicht gestartet" % (info)
                else:
                    descr = "NM_Waehlhaebel Botschaft hat nichts gesendet (Keine �nderung des Timestamps)"
                descr += "\nSenden von RX Signalen (HiL --> ECU) wurde NICHT gestartet"
            else:
                descr += "\nStarte Timer 4 - warte %ss"%wait_time
                self.func_com.waitSecondsWithResponse(wait_time)

        elif timer == "ende":
            # Es wird gepr�ft, das nach Ende der Timer (nach Timer 4) folgende Werte gesetzt sind:
            # - CarWakeUp muss auf 0 sein und WH_Zustand_N_Haltephase_2 muss 2 sein
            # - SiShift_StLghtDrvPosn muss auf P gesetzt werden
            # --> verdict wird auf 'PASSED' ge�ndert (sonst 'FAILED') und change_time wird eingetragen
            verdict, descr = checkSignalValues(car_wakeup_tende, t_min_tende, cbv_awb_tende, zustand_tende, n_haltephase_abgelaufen_tende)
            descr += "\nSIShift_StLghtDrvPosn auf %s gesetzt"%sishift_tende
            self.func_gs.changeDrivePosition(sishift_tende)

        return descr, verdict

    def hil_ecu_tx_off(self, period_sec):
        period_sec = period_sec * 1000

        self.hil.SiShift_01__period.set(period_sec)
        self.hil.OTAMC_01__period.set(period_sec)
        self.hil.VDSO_05__period.set(period_sec)
        self.hil.DPM_01__period.set(period_sec)
        self.hil.Diagnose_01__period.set(period_sec)
        self.hil.ClampControl_01__period.set(period_sec)
        self.hil.NVEM_12__period.set(period_sec)
        self.hil.Dimmung_01__period.set(period_sec)
        # self.hil.DIA_SAAM_Req__period.set(period_sec)
        # self.hil.ISOx_Funkt_Req_All_FD__period.set(period_sec)
        # self.hil.ISOx_Waehlhebel_Req_FD__period.set(period_sec)
        self.hil.NM_Airbag__period.set(period_sec)
        self.hil.OBDC_Funktionaler_Req_All_FD__period.set(period_sec)
        # self.hil.OBDC_Waehlhebel_Req_FD__period.set(period_sec)
        self.hil.OBD_03__period.set(period_sec)
        self.hil.OBD_04__period.set(period_sec)
        self.hil.ORU_Control_A_01__period.set(period_sec)
        self.hil.ORU_Control_D_01__period.set(period_sec)
        self.hil.OTAMC_01__period.set(period_sec)
        self.hil.OTAMC_D_01__period.set(period_sec)
        self.hil.Systeminfo_01__period.set(period_sec)
        self.hil.NM_HCP1__period.set(period_sec)

    def hil_ecu_tx_off_state(self, state):
        self.hil.SiShift_01__period.setState(state)
        self.hil.OTAMC_01__period.setState(state)
        self.hil.VDSO_05__period.setState(state)
        self.hil.DPM_01__period.setState(state)
        self.hil.Diagnose_01__period.setState(state)
        self.hil.ClampControl_01__period.setState(state)
        self.hil.NVEM_12__period.setState(state)
        self.hil.Dimmung_01__period.setState(state)
        # self.hil.DIA_SAAM_Req__period.setState(state)
        # self.hil.ISOx_Funkt_Req_All_FD__period.setState(state)
        # self.hil.ISOx_Waehlhebel_Req_FD__period.setState(state)
        self.hil.NM_Airbag__period.setState(state)
        self.hil.OBDC_Funktionaler_Req_All_FD__period.setState(state)
        # self.hil.OBDC_Waehlhebel_Req_FD__period.setState(state)
        self.hil.OBD_03__period.setState(state)
        self.hil.OBD_04__period.setState(state)
        self.hil.ORU_Control_A_01__period.setState(state)
        self.hil.ORU_Control_D_01__period.setState(state)
        self.hil.OTAMC_01__period.setState(state)
        self.hil.OTAMC_D_01__period.setState(state)
        self.hil.Systeminfo_01__period.setState(state)
        self.hil.NM_HCP1__period.setState(state)
        self.hil.ORU_01__period.setState(state)


def _checkStatus(current_status, nominal_status, equal=True, descr="", format=None, ticket_id=None):
    result = checkStatus(current_status, nominal_status, equal=equal, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0],"[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _checkRange(value, min_value, max_value, descr="", format=None, ticket_id=None):
    result = checkRange(value, min_value, max_value, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _compare(left_value, operator, right_value, abs_tol=0, descr="", format=None, ticket_id=None):
    result= compare(left_value, operator, right_value, abs_tol=abs_tol, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _checkBitMask(value, mask, operator="AND", bit_length=CHECKBITMASK_DEFAULT_BIT_LENGTH,pass_on_true=True,descr="", format=None, ticket_id=None):
    result = checkBitMask(value, mask, operator=operator, bit_length=bit_length, pass_on_true=pass_on_true, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _checkBitPattern(value, pattern, descr="", format=None, ticket_id=None):  # @ReservedAssignment: format
    result = checkBitPattern(value, pattern, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


# #############################################################################
def _checkBit(value, offset, status=1, descr="", format=None, ticket_id=None):
    result = checkBit(value, offset, status=status, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _checkTolerance(current_value, rated_value, rel_pos=0, abs_pos=0, rel_neg=None, abs_neg=None, descr="", format=None, ticket_id=None):
    result = checkTolerance(current_value, rated_value, rel_pos=rel_pos, abs_pos=abs_pos, rel_neg=rel_neg, abs_neg=abs_neg, descr=descr, format=format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _compareCE(current_value, operator, expected_value, abs_tol=0, descr="", ticket_id=None):
    result = compareCE(current_value, operator, expected_value, abs_tol=abs_tol, descr=descr)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


def _contains(defined_values, current_value, mode="all", descr="", format=None, ticket_id=None):
    result = contains(defined_values, current_value, mode=mode, descr=descr, format= format)
    if ticket_id is None:
        for i in range(len(result)):
            return [result[0], result[-1]]
    else:
        return [(result)[0], "[[COMMENT]] %s" % ticket_id, (result)[-1]]


